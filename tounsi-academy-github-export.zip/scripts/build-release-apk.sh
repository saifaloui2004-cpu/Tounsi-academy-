#!/usr/bin/env bash
set -euo pipefail

echo "=== TOUNSI ACADEMY (com.saifaloui.tounsiacademy) Standalone APK Builder ==="
command -v java >/dev/null 2>&1 || { echo "ERROR: JDK 17/21 (java) is required on host."; exit 1; }
command -v keytool >/dev/null 2>&1 || { echo "ERROR: keytool is required on host."; exit 1; }

if [ ! -f android/keystore.properties ]; then
  echo "INFO: android/keystore.properties not found."
  echo "1. Generate an independent key once:"
  echo "   keytool -genkeypair -v -keystore android/tounsi-academy-release.jks -alias tounsiacademy -keyalg RSA -keysize 2048 -validity 10000"
  echo "2. Copy android-keystore.properties.example to android/keystore.properties and fill in passwords."
fi

npm run build
npx cap sync android

cd android
chmod +x gradlew
./gradlew assembleRelease

echo "=== Release APK output directory: android/app/build/outputs/apk/release ==="
ls -lh app/build/outputs/apk/release/
