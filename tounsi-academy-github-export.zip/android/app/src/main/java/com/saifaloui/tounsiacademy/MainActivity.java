package com.saifaloui.tounsiacademy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
