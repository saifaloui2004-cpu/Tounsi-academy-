/**
 * NEXUS TOUNSI — Complete Master Edition 2026 Types & Interfaces
 * ACADEMY • TECH • LAB • WORKSHOP
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

export type Language = 'ar' | 'fr' | 'en';

export interface MultiLang {
  ar: string;
  fr: string;
  en: string;
}

export interface MultiLangArr {
  ar: string[];
  fr: string[];
  en: string[];
}

export type EngineeringLabId =
  | 'electrical'
  | 'mechanical'
  | 'plc'
  | 'thermal'
  | 'hydraulics'
  | 'pneumatics'
  | 'automotive'
  | 'electronics'
  | 'maintenance'
  | 'faults'
  | 'sim3d';

export interface LabInfo {
  id: EngineeringLabId;
  name: MultiLang;
  subtitle: MultiLang;
  icon: string;
  category: 'electrical' | 'mechanical' | 'automation' | 'thermal' | 'fluids' | 'diagnostics';
  xpReward: number;
  description: MultiLang;
  keyTopics: MultiLangArr;
}

// ==================== NEXUS ACADEMY TYPES ====================
export type AcademyCategoryId =
  | 'tech_edu'
  | 'vocational'
  | 'maintenance'
  | 'engineering'
  | 'math'
  | 'physics'
  | 'cs'
  | 'ai'
  | 'languages'
  | 'general_science';

export interface AcademyCategory {
  id: AcademyCategoryId;
  name: MultiLang;
  icon: string;
  courseCount: number;
}

export interface AcademyLessonSection {
  heading: MultiLang;
  body: MultiLang;
  formulas?: string[];
  keyRules?: MultiLangArr;
}

export interface AcademyLesson {
  id: string;
  courseId: string;
  title: MultiLang;
  durationMin: number;
  summary: MultiLang;
  sections: AcademyLessonSection[];
  practicalExercise?: MultiLang;
  quizQuestion?: QuizQuestion;
}

export interface AcademyCourse {
  id: string;
  categoryId: AcademyCategoryId;
  title: MultiLang;
  description: MultiLang;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
  durationHours: number;
  xpReward: number;
  lessons: AcademyLesson[];
}

// ==================== 2D SCHEMATIC SIMULATOR ====================
export type ComponentType =
  | 'power_source'
  | 'power_source_single'
  | 'circuit_breaker'
  | 'differential_breaker'
  | 'contactor'
  | 'thermal_relay'
  | 'motor_3phase'
  | 'motor_single'
  | 'push_button_no'
  | 'push_button_nc'
  | 'indicator_lamp'
  | 'plc_relay'
  | 'solenoid_valve'
  | 'pump_unit'
  | 'sensor_proximity';

export interface Terminal {
  id: string;
  name: string;
  x: number; // relative to component 0-100%
  y: number;
  type: 'in' | 'out' | 'phase' | 'neutral' | 'earth' | 'coil' | 'aux';
}

export interface CircuitComponent {
  id: string;
  type: ComponentType;
  label: string;
  x: number;
  y: number;
  state: {
    closed?: boolean;
    energized?: boolean;
    tripped?: boolean;
    running?: boolean;
    fault?: boolean;
    value?: number;
    rotation?: number;
  };
  terminals: Terminal[];
}

export interface CircuitWire {
  id: string;
  fromCompId: string;
  fromTermId: string;
  toCompId: string;
  toTermId: string;
  color: string;
  isLive: boolean;
  current: number; // Amperes
}

// ==================== 3D EQUIPMENT VIEWER ====================
export type Model3DType =
  | 'centrifugal_pump'
  | 'induction_motor'
  | 'thermal_boiler'
  | 'industrial_valve'
  | 'gearbox'
  | 'air_compressor'
  | 'heat_exchanger';

export interface Component3DInfo {
  id: string;
  name: MultiLang;
  material: string;
  function: MultiLang;
  inspectionCriteria: MultiLang;
  commonFaults: MultiLang;
}

// ==================== THERMAL OIL SIMULATOR ====================
export interface ThermalOilState {
  boilerPower: number; // 0 - 100%
  pumpSpeed: number; // 0 - 100% (0 - 2900 RPM)
  systemPressure: number; // bar
  boilerTempOut: number; // °C
  boilerTempIn: number; // °C
  expansionTankTemp: number; // °C
  expansionTankLevel: number; // %
  flowRate: number; // m3/h
  bypassValveOpen: number; // %
  heatDemandKW: number;
  heatTransferredKW: number;
  oilDegradation: number; // %
  activeFault: 'none' | 'overheat' | 'low_level' | 'cavitation' | 'leak' | 'vapor_lock' | 'exchanger_blockage' | 'sensor_drift';
  alarmActive: boolean;
  alarmMessage: string;
}

// ==================== FAULT DIAGNOSIS CENTER ====================
export interface FaultScenario {
  id: string;
  title: MultiLang;
  system: MultiLang;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
  xpPoints: number;
  initialReport: MultiLang;
  symptoms: {
    visual: MultiLang;
    auditory: MultiLang;
    thermal: MultiLang;
    vibration: MultiLang;
  };
  virtualMeasurements: {
    tool: 'multimeter' | 'vibration' | 'thermal_camera' | 'pressure_gauge';
    testPoint: string;
    reading: string;
    normalRange: string;
    unit: string;
  }[];
  possibleCauses: {
    id: string;
    text: MultiLang;
    isCorrect: boolean;
    explanation: MultiLang;
  }[];
  diagnosticSteps: MultiLang[];
  recommendedSolution: MultiLang;
  safetyRule: MultiLang;
}

// ==================== TRAINING & QUIZZES ====================
export interface QuizQuestion {
  id: string;
  labId: EngineeringLabId;
  question: MultiLang;
  options: MultiLangArr;
  correctIndex: number;
  explanation: MultiLang;
  xpReward: number;
}

export interface TrainingLesson {
  id: string;
  labId: EngineeringLabId;
  title: MultiLang;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
  durationMin: number;
  xp: number;
  summary: MultiLang;
  content: MultiLangArr;
  formulas?: string[];
  keyRules: MultiLangArr;
}

// ==================== NEXUS AI TECHNICIAN ====================
export interface AITechnicianMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  confidence?: 'fact' | 'hypothesis';
  safetyWarning?: string;
  diagnosticSteps?: string[];
}

// ==================== USER PROGRESS & PERSISTENCE ====================
export interface UserProgress {
  xp: number;
  level: number;
  completedLabs: EngineeringLabId[];
  completedLessons: string[];
  solvedFaults: string[];
  answeredQuizzes: string[];
  bookmarkedCourses: string[];
  completedCourses: string[];
  userName: string;
  language: Language;
  dialect?: string;
  soundEnabled: boolean;
  liteMode: boolean;
  joinedAt: string;
}
