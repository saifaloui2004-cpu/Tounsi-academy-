/**
 * TOUNSI ACADEMY — Local Storage & User Progress Management
 * Preserves backward-compatibility with NEXUS WORKSHOP progress data.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import { UserProgress } from '../types';

const STORAGE_KEY = 'tounsi_academy_user_progress_v1';
const LEGACY_NEXUS_KEY = 'nexus_workshop_user_progress_v1';

export const DEFAULT_USER_PROGRESS: UserProgress = {
  xp: 120,
  level: 1,
  completedLabs: ['electrical'],
  completedLessons: ['elec_101'],
  solvedFaults: [],
  answeredQuizzes: [],
  bookmarkedCourses: ['math_101', 'eng_201'],
  completedCourses: [],
  userName: 'المهندس المتدرب / Student Engineer',
  language: 'ar',
  soundEnabled: true,
  liteMode: false,
  joinedAt: new Date().toISOString(),
};

export function loadUserProgress(): UserProgress {
  if (typeof window === 'undefined') return DEFAULT_USER_PROGRESS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_NEXUS_KEY);
    if (!raw) return DEFAULT_USER_PROGRESS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_USER_PROGRESS, ...parsed };
  } catch {
    return DEFAULT_USER_PROGRESS;
  }
}

export function saveUserProgress(progress: UserProgress): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Ignore quota errors
  }
}

export function calculateLevel(xp: number): { level: number; title: { ar: string; fr: string; en: string }; nextLevelXp: number; progressPercent: number } {
  if (xp < 250) {
    return {
      level: 1,
      title: { ar: 'متدرب صناعي مبتدئ', fr: 'Apprenti Industriel', en: 'Junior Industrial Apprentice' },
      nextLevelXp: 250,
      progressPercent: Math.min(100, Math.round((xp / 250) * 100)),
    };
  } else if (xp < 600) {
    return {
      level: 2,
      title: { ar: 'فني تشغيل وصيانة', fr: 'Technicien Maintenance', en: 'Operations & Maintenance Tech' },
      nextLevelXp: 600,
      progressPercent: Math.min(100, Math.round(((xp - 250) / 350) * 100)),
    };
  } else if (xp < 1200) {
    return {
      level: 3,
      title: { ar: 'مهندس محاكاة وأنظمة', fr: 'Ingénieur Simulation & Systèmes', en: 'Systems & Simulation Engineer' },
      nextLevelXp: 1200,
      progressPercent: Math.min(100, Math.round(((xp - 600) / 600) * 100)),
    };
  } else if (xp < 2000) {
    return {
      level: 4,
      title: { ar: 'كبير مهندسي الصيانة والأتمتة', fr: 'Expert Maintenance & Automatisme', en: 'Senior Automation & Reliability Engineer' },
      nextLevelXp: 2000,
      progressPercent: Math.min(100, Math.round(((xp - 1200) / 800) * 100)),
    };
  } else {
    return {
      level: 5,
      title: { ar: 'مستشار هندسي أول — Academy Master', fr: 'Consultant Industriel Senior', en: 'Principal Industrial Master' },
      nextLevelXp: 3000,
      progressPercent: 100,
    };
  }
}
