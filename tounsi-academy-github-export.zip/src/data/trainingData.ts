/**
 * NEXUS WORKSHOP — Training Curriculum, Technical Lessons & Quizzes
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import { TrainingLesson, QuizQuestion, LabInfo } from '../types';

export const LABS_LIST: LabInfo[] = [
  {
    id: 'electrical',
    name: { ar: 'المختبر الكهربائي ومحركات الحث', fr: 'Génie Électrique & Moteurs', en: 'Electrical Engineering & Motors' },
    subtitle: { ar: 'دوائر القوى والتحكم وإقلاع المحركات', fr: 'Circuits de puissance et moteurs', en: 'Power, control & motor drives' },
    icon: 'Zap',
    category: 'electrical',
    xpReward: 250,
    description: {
      ar: 'دراسة الدوائر الكهربائية الصناعية، توصيل المحركات ثلاثية الأطوار، مفاتيح التلامس (Contactors)، المرحلات الحرارية (Overload Relays)، وقواطع الدوائر (Circuit Breakers).',
      fr: 'Étude des schémas industriels, démarrage étoile-triangle, protection thermique et sélectivité.',
      en: 'Study of industrial electrical circuits, 3-phase induction motor starters, thermal overloads, and protection.',
    },
    keyTopics: {
      ar: ['بدء التشغيل المباشر والنجمي-المثلثي', 'معامل القدرة وتحسين الاستهلاك', 'حسابات هبوط الجهد والتيارات', 'التأريض والحماية التفاضلية'],
      fr: ['Démarrage Direct & Étoile-Triangle', 'Facteur de Puissance cos φ', 'Chutes de Tension et Section Câble', 'Régimes de Neutre TT/TN'],
      en: ['Direct-on-Line & Star-Delta Starters', 'Power Factor & Reactive Compensation', 'Voltage Drop & Cable Sizing', 'Grounding & Selective Protection'],
    },
  },
  {
    id: 'mechanical',
    name: { ar: 'مختبر الهندسة الميكانيكية ونقل الحركة', fr: 'Génie Mécanique & Transmission', en: 'Mechanical Transmission Lab' },
    subtitle: { ar: 'التروس والعلب المخفضة ومحاذاة الأعمدة', fr: 'Engrenages, réducteurs et lignage', en: 'Gears, reducers & shaft alignment' },
    icon: 'Cog',
    category: 'mechanical',
    xpReward: 250,
    description: {
      ar: 'تحليل أنظمة نقل الحركة الميكانيكية، حساب نسب التخفيض، العزم وسرعات الدوران، فحص كراسي التحميل وعمر الخدمة L10.',
      fr: 'Cinématique des réducteurs, calcul de couple, analyse d’usure des roulements et équilibrage.',
      en: 'Mechanical drive kinematics, gear reduction ratios, torque calculations, bearing L10 life, and balancing.',
    },
    keyTopics: {
      ar: ['نسب التخفيض والعزم الدوراني', 'أنواع كراسي التحميل وخلوص C3', 'محاذاة الأعمدة الميكانيكية بالليزر', 'التشحيم والتزييت وفق ISO VG'],
      fr: ['Rapports de Réduction & Couple', 'Sélection Roulements & Jeu C3', 'Lignage d’Arbre Laser', 'Lubrification selon ISO VG'],
      en: ['Gear Ratios & Output Torque', 'Bearing Types & C3 Clearance', 'Laser Shaft Alignment', 'Lubrication Viscosity ISO VG'],
    },
  },
  {
    id: 'plc',
    name: { ar: 'الأتمتة الصناعية ومتحكمات الـ PLC', fr: 'Automatisme Industriel & API', en: 'Industrial Automation & PLC' },
    subtitle: { ar: 'مخططات السلم (Ladder) وحلقات التحكم', fr: 'Langage Ladder et asservissements', en: 'Ladder logic & control loops' },
    icon: 'Cpu',
    category: 'automation',
    xpReward: 280,
    description: {
      ar: 'برمجة ومحاكاة المتحكمات المنطقية القابلة للبرمجة PLC، المداخل والمخارج الرقمية والتناظرية، المؤقتات والعدادات، وتصميم سكادا.',
      fr: 'Programmation d’automates programmables, entrées/sorties tout-ou-rien et analogiques, supervision.',
      en: 'PLC programming and simulation, digital and analog I/O, timers, counters, interlocks, and SCADA.',
    },
    keyTopics: {
      ar: ['منطق السلم ومخططات التتابع', 'مؤقتات TON و TOF والعدادات', 'إشارات الحلقات التماثلية 4-20mA', 'بروتوكولات Modbus و Profinet'],
      fr: ['Logique à Contacts (Ladder)', 'Temporisateurs TON/TOF', 'Signaux Analogiques 4-20mA', 'Réseaux Modbus & Profinet'],
      en: ['Ladder Diagrams & Boolean Logic', 'TON/TOF Timers & Counters', 'Analog 4-20mA Signals', 'Industrial Buses (Modbus, Profinet)'],
    },
  },
  {
    id: 'thermal',
    name: { ar: 'محاكاة الأنظمة والمراجل الحرارية', fr: 'Simulation Systèmes Thermiques', en: 'Thermal Systems Simulation' },
    subtitle: { ar: 'المراجل ومبادلات الحرارة ودورات الطاقة', fr: 'Chaudières et échangeurs thermiques', en: 'Boilers, heat exchangers & circuits' },
    icon: 'Flame',
    category: 'thermal',
    xpReward: 270,
    description: {
      ar: 'محاكاة غلايات البخار والزيت الحراري، حسابات انتقال الحرارة، فاقد الضغط، كفاءة الاحتراق، وحماية شبكات الطاقة.',
      fr: 'Modélisation thermodynamique, échangeurs à plaques et tubulaires, combustion et efficacité énergétique.',
      en: 'Thermodynamic modeling, tubular and plate heat exchangers, combustion efficiency, and piping networks.',
    },
    keyTopics: {
      ar: ['معادلات انتقال الحرارة $Q = \\dot{m} C_p \\Delta T$', 'مبادلات الحرارة اللوحية والأنبوبية', 'كفاءة الاحتراق والتحكم في الهواء', 'تمدد السوائل وحسابات خزان التمدد'],
      fr: ['Équation de Transfert de Chaleur', 'Échangeurs Tubulaires et Plaques', 'Rendement de Combustion', 'Dimensionnement Vases d’Expansion'],
      en: ['Heat Transfer $Q = \\dot{m} C_p \\Delta T$', 'Shell & Tube and Plate Exchangers', 'Combustion & Air-Fuel Ratio', 'Thermal Expansion Calculations'],
    },
  },
  {
    id: 'hydraulics',
    name: { ar: 'مختبر الهيدروليك والنيوماتيك الصناعي', fr: 'Hydraulique & Pneumatique', en: 'Hydraulics & Pneumatics Lab' },
    subtitle: { ar: 'الدوائر الزيتية وضغط الهواء المشغل', fr: 'Circuits d’huile et air comprimé', en: 'Oil power & pneumatic circuits' },
    icon: 'Gauge',
    category: 'fluids',
    xpReward: 260,
    description: {
      ar: 'محاكاة الدوائر الهيدروليكية عالية الضغط، الصمامات التوجيهية 4/3 و 5/2، الأسطوانات مزدوجة المفعول، وحسابات القوة والسرعة.',
      fr: 'Circuits hydrauliques haute pression, distributeurs, vérins et accumulateurs oléopneumatiques.',
      en: 'High pressure hydraulic circuits, 4/3 and 5/2 directional valves, double-acting cylinders, and accumulators.',
    },
    keyTopics: {
      ar: ['قوانين باسكال وحسابات القوة $F = P \\times A$', 'الصمامات التوجيهية وصمامات التنفيس', 'الأسطوانات الهيدروليكية والمحركات', 'دوائر النيوماتيك وتجفيف الهواء'],
      fr: ['Loi de Pascal $F = P \\times A$', 'Distributeurs & Clapets Pilotés', 'Vérins & Pompes à Pistons', 'Unités FRL et Air Comprimé'],
      en: ['Pascal Law $F = P \\times A$', 'Directional & Pilot Check Valves', 'Cylinders & Piston Pumps', 'Pneumatic FRL Conditioning'],
    },
  },
  {
    id: 'automotive',
    name: { ar: 'مختبر تشخيص هندسة ومحركات السيارات', fr: 'Diagnostic Automobile & Moteurs', en: 'Automotive Diagnostics Lab' },
    subtitle: { ar: 'بروتوكول OBD-II وحساسات المحرك', fr: 'Codes OBD-II et capteurs injection', en: 'OBD-II DTCs & engine sensors' },
    icon: 'Car',
    category: 'diagnostics',
    xpReward: 240,
    description: {
      ar: 'قراءة وفهم إشارات الحساسات في المركبات الحديثة، شبكات CAN-Bus، حساسات الأكسجين وتدفق الهواء MAF، ونظام الشحن بالدينامو.',
      fr: 'Diagnostic embarqué OBD-II, bus CAN multiplexé, débitmètres d’air, sondes lambda et injection.',
      en: 'Automotive electronic diagnosis, multiplexed CAN-Bus waveforms, MAF airflow, oxygen sensors, and alternator testing.',
    },
    keyTopics: {
      ar: ['رموز الأعطال التشخيصية DTC OBD-II', 'إشارات شبكة CAN-H و CAN-L', 'حساسات الكرنك والعمود المرفقي', 'أنظمة الحقن الإلكتروني والشحن'],
      fr: ['Codes DTC OBD-II P0xxx', 'Signaux Oscilloscope CAN-Bus', 'Capteurs PMH et Arbre à Cames', 'Circuits Alternateur et Démarreur'],
      en: ['OBD-II DTC Fault Codes', 'CAN-High & CAN-Low Waveforms', 'Crank & Camshaft Position Sensors', 'Charging Systems & Alternator'],
    },
  },
  {
    id: 'electronics',
    name: { ar: 'مختبر صيانة وتصليح اللوحات الإلكترونية', fr: 'Réparation Cartes Électroniques', en: 'Electronics & PCB Repair Lab' },
    subtitle: { ar: 'فحص المكونات والدوائر المطبوعة', fr: 'Composants CMS, test et dépannage', en: 'SMD components, testing & repair' },
    icon: 'Radio',
    category: 'electrical',
    xpReward: 250,
    description: {
      ar: 'تقنيات فحص وتتبع المسارات في اللوحات الصناعية PCB، فحص مكثفات الترشيح ESR، الثنائيات والترانزستورات، واستكشاف القصر الكهربائي.',
      fr: 'Dépannage de circuits imprimés PCB, mesure ESR des condensateurs, transistors MOSFET et soudure.',
      en: 'Industrial PCB tracing and repair, capacitor ESR testing, MOSFET switching, diode testing, and short-circuit localization.',
    },
    keyTopics: {
      ar: ['فحص المكثفات بجهاز ESR Meter', 'اختبار الترانزستورات MOSFET و IGBT', 'استكشاف القصر الحراري بالكاميرا', 'تقنيات اللحام والفك السطحي SMD'],
      fr: ['Contrôle ESR Condensateurs', 'Test Diodes et MOSFETs', 'Localisation de Court-Circuit Thermique', 'Soudure et Dessoudure CMS'],
      en: ['Capacitor ESR Diagnostic Testing', 'Power MOSFET & IGBT Testing', 'Thermal Short-Circuit Tracing', 'SMD Soldering & Desoldering'],
    },
  },
  {
    id: 'maintenance',
    name: { ar: 'مختبر الصيانة الوقائية والتنبؤية', fr: 'Maintenance Prédictive & Fiabilité', en: 'Industrial Maintenance Lab' },
    subtitle: { ar: 'مؤشرات الموثوقية وتحليل الاهتزازات', fr: 'Indicateurs MTBF, MTTR et vibrations', en: 'MTBF, MTTR & vibration analysis' },
    icon: 'Wrench',
    category: 'mechanical',
    xpReward: 260,
    description: {
      ar: 'استراتيجيات الصيانة الشاملة TPM، حسابات متوسط الوقت بين الأعطال MTBF وزمن الإصلاح MTTR، ومعايير تقييم الاهتزازات ISO 10816.',
      fr: 'Stratégies de maintenance TPM, indicateurs de fiabilité MTBF/MTTR et analyse spectrale des vibrations.',
      en: 'Total Productive Maintenance (TPM), MTBF and MTTR reliability indicators, and ISO 10816 vibration severity standards.',
    },
    keyTopics: {
      ar: ['مؤشرات الأداء MTBF و MTTR و OEE', 'تحليل الاهتزازات الميكانيكية ISO 10816', 'تحليل زيوت التشحيم والمخلفات', 'خطط التفتيش والفحص الدوري'],
      fr: ['Indicateurs MTBF, MTTR et TRS', 'Norme Vibratoire ISO 10816-3', 'Analyses Physico-Chimiques d’Huile', 'Gammes de Visites Systématiques'],
      en: ['Reliability KPIs (MTBF, MTTR, OEE)', 'ISO 10816-3 Vibration Standards', 'Lube Oil Condition Monitoring', 'Preventive Maintenance Routes'],
    },
  },
  {
    id: 'faults',
    name: { ar: 'مركز التشخيص الميداني للأعطال', fr: 'Centre Diagnostic de Pannes', en: 'Fault Diagnosis Center' },
    subtitle: { ar: 'حالات واقعية وفحوصات بالأجهزة', fr: 'Cas réels d’investigation et tests', en: 'Real-world breakdown cases & tools' },
    icon: 'AlertTriangle',
    category: 'diagnostics',
    xpReward: 320,
    description: {
      ar: 'بيئة تدريبية تفاعلية للتحقيق في الأعطال الصناعية الغامضة؛ استخدام أجهزة القياس الافتراضية، تحليل الأسباب الجذرية، واقتراح الحلول.',
      fr: 'Missions immersives de dépannage industriel: mesures virtuelles, recherche de cause racine et évaluation.',
      en: 'Interactive industrial troubleshooting missions: take virtual measurements, isolate root causes, and submit repair plans.',
    },
    keyTopics: {
      ar: ['تكهف المضخات الصناعية', 'سخونة المحركات الكهربائية', 'الالتصاق الحراري للملامسات', 'زحف وتسريب الأسطوانات'],
      fr: ['Cavitation de Pompe', 'Surchauffe Moteur Statorique', 'Collage Pôles Contacteurs', 'Fuites Internes Vérin'],
      en: ['Centrifugal Pump Cavitation', 'Motor Stator Overheating', 'Contactor Contact Welding', 'Hydraulic Internal Cylinder Drift'],
    },
  },
  {
    id: 'sim3d',
    name: { ar: 'مركز المحاكاة ثلاثية الأبعاد التفاعلية', fr: 'Centre Simulation 3D', en: '3D Simulation Center' },
    subtitle: { ar: 'تفكيك وفحص المعدات 3D في الوقت الحقيقي', fr: 'Modèles 3D éclatés et inspection', en: 'Interactive 3D exploded & cutaway models' },
    icon: 'Box',
    category: 'mechanical',
    xpReward: 300,
    description: {
      ar: 'استعراض مجسمات ثلاثية الأبعاد تفاعلية لمضخات الطرد المركزي، المحركات الكهربائية، مراجل الزيت الحراري، والصمامات مع ميزة العرض المفكك (Exploded View).',
      fr: 'Inspection 3D temps réel: pompes, moteurs, chaudières et vannes avec vue éclatée et inspection des pièces.',
      en: 'Real-time interactive 3D mechanical exploration of pumps, motors, thermal boilers, and valves with exploded view slider.',
    },
    keyTopics: {
      ar: ['العرض المفكك وتجميع الأجزاء', 'المقطع الشفاف والتدفق الداخلي', 'فحص مكونات المضخة والمحرك', 'دراسة مسارات الموائع والحرارة'],
      fr: ['Vue Éclatée Progressive', 'Mode Transparence et Coupe', 'Nomenclature des Composants 3D', 'Lignes de Flux et Cinématique'],
      en: ['Interactive Exploded Assembly', 'Cutaway Casing & Fluid Flow', 'Component Nomenclature & Specs', 'Kinematic & Thermal Pathways'],
    },
  },
];

export const TECHNICAL_QUIZZES: QuizQuestion[] = [
  {
    id: 'q_elec_1',
    labId: 'electrical',
    question: {
      ar: 'ما هي النسبة المئوية التقريبية لانخفاض تيار بدء التشغيل عند استخدام الإقلاع النجمي-المثلثي (Star-Delta) مقارنة بالإقلاع المباشر (DOL)؟',
      fr: 'Quelle est la réduction approximative du courant de démarrage en étoile-triangle par rapport au démarrage direct ?',
      en: 'What is the approximate reduction in starting current when using Star-Delta starting compared to Direct-on-Line (DOL)?',
    },
    options: {
      ar: ['ينخفض التيار إلى الثلث (حوالي 33% من تيار البدء المباشر)', 'ينخفض التيار إلى النصف (50%)', 'ينخفض التيار بنسبة 10% فقط', 'لا يتغير التيار بل يتغير الجهد فقط'],
      fr: ['Le courant est réduit au tiers (~33% du courant direct)', 'Le courant est réduit de moitié (50%)', 'Le courant diminue de 10% seulement', 'Le courant reste identique'],
      en: ['Current is reduced to one-third (~33% of DOL starting current)', 'Current is halved (50%)', 'Current drops by only 10%', 'Current remains identical while torque doubles'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'في التوصيل النجمي (Star)، يكون الجهد المطبق على كل طور مقسوماً على جذر 3 ($V / \\sqrt{3}$)، مما يجعل تيار الطور ثلث التيار الاسمي، وعزم البدء ينخفض أيضاً للثلث.',
      fr: 'En couplage étoile, la tension aux bornes de chaque enroulement est divisée par racine de 3, réduisant courant et couple à 1/3 de leur valeur en triangle.',
      en: 'In star connection, phase voltage is $V / \\sqrt{3}$, reducing both starting current and starting torque to one-third (33%) of the delta values.',
    },
    xpReward: 35,
  },
  {
    id: 'q_mech_1',
    labId: 'mechanical',
    question: {
      ar: 'في علبة تروس ذات مرحلة واحدة، إذا كان عدد أسنان الترس القائد 20 سناً، والترس المقاد 80 سناً، وعزم الدخول 50 Nm، فكم يكون عزم الخرج النظري؟',
      fr: 'Dans un réducteur avec pignon menant 20 dents et roue menée 80 dents, pour un couple d’entrée de 50 Nm, quel est le couple de sortie théorique ?',
      en: 'In a single-stage gearbox, with a 20-tooth driver gear and an 80-tooth driven gear, with 50 Nm input torque, what is the theoretical output torque?',
    },
    options: {
      ar: ['200 Nm (السرعة تقل إلى الربع والعزم يتضاعف 4 مرات)', '12.5 Nm (العزم يقل)', '50 Nm (لا يتغير العزم)', '1000 Nm'],
      fr: ['200 Nm (Vitesse divisée par 4, couple multiplié par 4)', '12.5 Nm', '50 Nm', '1000 Nm'],
      en: ['200 Nm (Speed is quartered, torque is multiplied by 4)', '12.5 Nm', '50 Nm', '1000 Nm'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'نسبة التخفيض $i = 80 / 20 = 4$. وبإهمال الاحتكاك، فإن العزم يتضاعف بنفس نسبة التخفيض: $T_{out} = 50 \\times 4 = 200\\text{ Nm}$.',
      fr: 'Le rapport de réduction est $i = 80 / 20 = 4$. Le couple de sortie théorique est donc $50 \\times 4 = 200\\text{ Nm}$.',
      en: 'Gear ratio is $i = 80 / 20 = 4$. Neglecting friction, output torque scales proportionally: $T_{out} = 50 \\times 4 = 200\\text{ Nm}$.',
    },
    xpReward: 35,
  },
  {
    id: 'q_plc_1',
    labId: 'plc',
    question: {
      ar: 'لماذا يُفضل استخدام إشارة التيار 4-20mA بدلاً من إشارة الجهد 0-10V في المنشآت الصناعية البعيدة؟',
      fr: 'Pourquoi préfère-t-on la boucle de courant 4-20mA au signal de tension 0-10V en milieu industriel distant ?',
      en: 'Why is a 4-20mA current loop preferred over 0-10V voltage signals for long-distance industrial instrumentation?',
    },
    options: {
      ar: ['لأن التيار لا يتأثر بهبوط جهد مقاومة الأسلاك الطويلة ويتيح كشف انقطاع السلك (Live Zero عند 4mA)', 'لأن إشارة الجهد تستهلك طاقة أكبر بكثير', 'لأن أجهزة الـ PLC لا تدعم إشارات الجهد مطلقاً', 'لأسباب تجارية فقط'],
      fr: ['Insensible à la résistance des câbles et détection de coupure de fil (zéro vivant à 4mA)', 'Moins de consommation électrique', 'Les automates ne lisent pas la tension', 'Simple convention commerciale'],
      en: ['Immune to cable resistance voltage drops and provides built-in wire-break detection (4mA live zero)', 'Consumes vastly less power', 'PLCs cannot process voltages', 'Purely historical convention'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'التيار ثابت عبر الدائرة التسلسلية مهما كان طول الكابل، ووجود حد أدنى 4mA (الصفر الحي) يسمح للـ PLC بالتمييز فوراً بين القيمة الصفرية وانقطاع الكابل الحقيقي (0mA).',
      fr: 'L’intensité reste constante le long de la boucle quelle que soit la résistance du conducteur, et le zéro vivant à 4mA garantit la détection d’une coupure physique.',
      en: 'Current is invariant in a series loop regardless of line resistance, and the 4mA live zero allows instant distinction between a zero process reading and a severed cable.',
    },
    xpReward: 40,
  },
  {
    id: 'q_therm_1',
    labId: 'thermal',
    question: {
      ar: 'ما هي الوظيفة الأساسية لخزان التمدد (Expansion Tank) في منظومات الزيت الحراري (Huile Thermique)؟',
      fr: 'Quel est le rôle primordial du vase d’expansion dans les installations à huile thermique ?',
      en: 'What is the primary engineering role of the expansion tank in thermal oil heating systems?',
    },
    options: {
      ar: ['استيعاب الزيادة الحجمية للزيت الناتج عن التمدد الحراري وتوفير حاجز بارد لمنع أكسدة الزيت الساخن مع الهواء', 'تسخين الزيت قبل دخوله للمرجل', 'زيادة سرعة ضخ السائل داخل الأنابيب', 'تنقية الزيت من الرواسب والشوائب الصلبة فقط'],
      fr: ['Absorber la dilatation thermique du fluide et former un joint froid anti-oxydation avec l’air', 'Réchauffer l’huile avant la chaudière', 'Accélérer la circulation', 'Filtrer les résidus métalliques'],
      en: ['Absorb fluid volumetric expansion and maintain a cold seal blanket to prevent thermal oil atmospheric oxidation', 'Preheat fluid before firing', 'Boost pump circulation velocity', 'Act exclusively as a dirt separator'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'الزيت الحراري يتمدد بحوالي 20% عند تسخينه من 20°C إلى 300°C، ويقوم خزان التمدد باستيعاب هذا الحجم مع الحفاظ على حرارة السطح أقل من 60°C لمنع تأكسد الزيت وتفحمه.',
      fr: 'L’huile se dilate d’environ 20% entre l’ambiance et 300°C. Le vase absorbe ce volume tout en restant froid (< 60°C) pour éviter l’oxydation au contact de l’air.',
      en: 'Thermal fluid expands by roughly 20% between ambient and 300°C. The expansion tank buffers this surge and keeps surface oil cool (< 60°C) to avert degradation.',
    },
    xpReward: 40,
  },
  {
    id: 'q_hydr_1',
    labId: 'hydraulics',
    question: {
      ar: 'إذا كان قطر مكبس أسطوانة هيدروليكية 100 mm وضغط الزيت 160 bar، فما هي قوة الدفع التقريبية المتولدة؟',
      fr: 'Pour un vérin hydraulique d’alésage 100 mm sous 160 bar, quelle est la force de poussée théorique développée ?',
      en: 'For a hydraulic cylinder with a 100 mm bore operating at 160 bar, what is the approximate theoretical thrust force?',
    },
    options: {
      ar: ['حوالي 125.6 kN (حوالي 12.8 طن)', 'حوالي 16 kN فقط', 'حوالي 1600 kN', 'حوالي 1.6 kN'],
      fr: ['Environ 125.6 kN (~12.8 tonnes)', 'Environ 16 kN', 'Environ 1600 kN', 'Environ 1.6 kN'],
      en: ['Approximately 125.6 kN (~12.8 metric tons)', 'Approximately 16 kN', 'Approximately 1600 kN', 'Approximately 1.6 kN'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'المساحة $A = \\pi \\times (0.05)^2 = 0.007854\\text{ m}^2$. القوة $F = P \\times A = (160 \\times 10^5\\text{ Pa}) \\times 0.007854 = 125,663\\text{ N} \\approx 125.6\\text{ kN}$.',
      fr: 'Section $A = \\pi \\times 0.05^2 = 0.007854\\text{ m}^2$. Force $F = 160 \\times 10^5 \\times 0.007854 = 125.6\\text{ kN}$.',
      en: 'Piston area $A = \\pi \\times (0.05)^2 = 0.007854\\text{ m}^2$. Force $F = P \\times A = 160 \\times 10^5\\text{ Pa} \\times 0.007854\\text{ m}^2 \\approx 125.6\\text{ kN}$.',
    },
    xpReward: 40,
  },
  {
    id: 'q_pneu_1',
    labId: 'pneumatics',
    question: {
      ar: 'ما هي الوظيفة الأساسية لوحدة الخدمة FRL (Filter-Regulator-Lubricator) في شبكات الهواء المضغوط؟',
      fr: 'Quel est le rôle principal du bloc FRL (Filtre-Régulateur-Lubrificateur) sur un réseau pneumatique ?',
      en: 'What is the primary purpose of an FRL (Filter-Regulator-Lubricator) unit in compressed air circuits?',
    },
    options: {
      ar: ['تنقية الهواء من الماء والشوائب وتثبيت الضغط وتشحيم الصمامات والأسطوانات', 'تسخين الهواء المضغوط فوق 200°C', 'تحويل الهواء إلى زيت هيدروليكي', 'رفع الجهد الكهربائي للصمامات'],
      fr: ['Filtrer l’eau/impuretés, stabiliser la pression et lubrifier les composants', 'Chauffer l’air au-delà de 200°C', 'Convertir l’air en huile hydraulique', 'Élever la tension électrique'],
      en: ['Filter moisture/particles, regulate pressure stability, and lubricate valves/cylinders', 'Heat compressed air above 200°C', 'Convert air into hydraulic oil', 'Boost solenoid coil voltage'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'وحدة FRL تحمي الصمامات 5/2 والأسطوانات الهوائية من التآكل والصدأ الناتج عن رطوبة وتكثف الهواء المضغوط.',
      fr: 'Le bloc FRL protège les distributeurs 5/2 et vérins contre l’humidité, l’usure et les pics de pression.',
      en: 'The FRL conditioning assembly removes condensate/debris, holds steady bar pressure, and extends actuator seal life.',
    },
    xpReward: 35,
  },
  {
    id: 'q_auto_1',
    labId: 'automotive',
    question: {
      ar: 'ما قيمة مقاومة الإنهاء القياسية (Termination Resistance) بين خطي CAN-H و CAN-L عند فحص شبكة CAN-Bus مطفأة بالأوميتر؟',
      fr: 'Quelle résistance totale mesure-t-on entre CAN-H et CAN-L sur un bus CAN sain hors tension ?',
      en: 'What total termination resistance should be measured between CAN-H and CAN-L on a healthy powered-off CAN-Bus?',
    },
    options: {
      ar: ['حوالي 60 أوم (مقاومتان 120 أوم موصلتان على التوازي)', '0 أوم (قصر تام)', '1200 أوم', '12 فولت تيار مستمر'],
      fr: ['Environ 60 Ohms (deux résistances de 120 Ohms en parallèle)', '0 Ohm', '1200 Ohms', '12 Volts DC'],
      en: ['Approximately 60 Ohms (two 120-Ohm terminators in parallel)', '0 Ohms (dead short)', '1200 Ohms', '12V DC'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'تحتوي شبكة CAN على مقاومتين 120 أوم في طرفيها على التوازي، لذا فإن قياس 60 أوم يؤكد سلامة المسارين والإنهاء.',
      fr: 'Les deux résistances terminales de 120 Ω en parallèle donnent une résistance équivalente de 60 Ω.',
      en: 'Two 120-Ohm termination resistors sit in parallel at opposite bus ends, yielding 60 Ohms across CAN-H and CAN-L.',
    },
    xpReward: 40,
  },
  {
    id: 'q_elec_pcb_1',
    labId: 'electronics',
    question: {
      ar: 'لماذا نستخدم جهاز ESR Meter عند فحص مكثفات الترشيح الإلكتروليتية في لوحات القدرة الصناعية PCB؟',
      fr: 'Pourquoi utilise-t-on un ESR-mètre pour tester les condensateurs électrolytiques sur une carte de puissance ?',
      en: 'Why is an ESR meter essential when testing electrolytic filter capacitors on industrial power PCBs?',
    },
    options: {
      ar: ['لأن المكثف التالف أو الجاف يرتفع فيه المقاومة التسلسلية المكافئة ESR مما يسبب تموج الجهد وسخونته رغم بقاء سعته ظاهرة', 'لقياس سرعة دوران المحرك', 'لشحن المكثف بجهد 1000 فولت', 'لقياس استهلاك المصنع بالكيلوواط'],
      fr: ['Un condensateur sec voit son ESR augmenter fortement, créant de l’ondulation et de la surchauffe', 'Pour mesurer les RPM du moteur', 'Pour charger le condensateur à 1000V', 'Pour calculer le facteur de puissance réseau'],
      en: ['Dried electrolytic capacitors exhibit high Equivalent Series Resistance (ESR), causing ripple & thermal failure', 'To measure motor RPM', 'To charge capacitors to 1000V', 'To meter plant kWh'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'ارتفاع قيمة ESR يسبب عدم استقرار تغذية البطاقات المنطقية وظهور أعطال متقطعة أو انتفاخ المكثفات.',
      fr: 'Une ESR élevée dégrade le filtrage d’alimentation et provoque des pannes intermittentes ou un gonflement.',
      en: 'High ESR degrades DC bus filtering, leading to logic resets, overheating, and eventual capacitor bulging.',
    },
    xpReward: 35,
  },
  {
    id: 'q_maint_1',
    labId: 'maintenance',
    question: {
      ar: 'ما معنى أن تكون قيمة MTBF مرتفعة وقيمة MTTR منخفضة في مؤشرات الصيانة الصناعية؟',
      fr: 'Que signifie un MTBF élevé combiné à un MTTR faible en fiabilité industrielle ?',
      en: 'In industrial reliability metrics, what does a high MTBF combined with a low MTTR indicate?',
    },
    options: {
      ar: ['موثوقية عالية للآلة (فترات طويلة بدون أعطال) وسرعة كبيرة في الإصلاح وإعادة التشغيل', 'الأعطال تحدث كل ساعة وتستغرق أياماً للإصلاح', 'توقف المصنع عن الإنتاج تماماً', 'انخفاض جودة الزيوت فقط'],
      fr: ['Haute fiabilité (longs intervalles sans panne) et réparation rapide en cas d’incident', 'Pannes très fréquentes et réparations longues', 'Arrêt définitif de l’usine', 'Contamination des lubrifiants'],
      en: ['High equipment reliability (long failure-free intervals) and rapid repair turnaround time', 'Frequent breakdowns and slow repairs', 'Permanent factory shutdown', 'Degraded lubricant viscosity'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'MTBF تعني متوسط الزمن بين الأعطال (كلما زاد كان أفضل)، وMTTR تعني متوسط زمن الإصلاح (كلما قل ارتفعت التوافرية).',
      fr: 'MTBF = temps moyen entre pannes (à maximiser) ; MTTR = temps moyen de réparation (à minimiser).',
      en: 'MTBF is Mean Time Between Failures (higher is better); MTTR is Mean Time To Repair (lower boosts availability).',
    },
    xpReward: 40,
  },
  {
    id: 'q_fault_1',
    labId: 'faults',
    question: {
      ar: 'عند تشخيص عطل توقف محرك بسبب انطلاق المرحل الحراري F1، ما الخطوة المنطقية الأولى قبل إعادة التشغيل؟',
      fr: 'Lors du déclenchement d’un relais thermique F1, quelle étape diagnostique précède le réarmement ?',
      en: 'When investigating a motor trip caused by thermal overload F1, what is the proper first diagnostic step before resetting?',
    },
    options: {
      ar: ['فحص العزل والتيار المسحوب والتحقق من عدم وجود انحشار ميكانيكي في الحمل أو فقدان طور (Phase Loss)', 'الضغط الفوري والمتكرر على زر Reset حتى يحترق المحرك', 'رفع ضبط الأمبير لأقصى حد متاح وتجاوز الحماية', 'فك الأسلاك دون فصل القاطع الرئيسي'],
      fr: ['Contrôler les courants par phase, l’isolement et l’absence de blocage mécanique avant réarmement', 'Réarmer immédiatement en boucle', 'Régler le relais au maximum sans mesure', 'Débrancher sous tension'],
      en: ['Check per-phase current balance, insulation resistance, and mechanical binding/phase loss before resetting', 'Repeatedly hit Reset immediately', 'Turn overload dial to max and bypass safety', 'Disconnect motor leads live'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'إعادة ضبط المرحل الحراري دون إزالة السبب الجذري (فقدان طور أو ثقل ميكانيكي) قد تتسبب في احتراق ملفات الساكن.',
      fr: 'Réarmer sans éliminer la cause racine (manque de phase ou blocage) risque de brûler les enroulements.',
      en: 'Resetting an overload relay without resolving root causes like single-phasing or mechanical seizure risks stator burnout.',
    },
    xpReward: 45,
  },
  {
    id: 'q_sim3d_1',
    labId: 'sim3d',
    question: {
      ar: 'في المضخات الطاردة المركزية (Centrifugal Pumps)، ما وظيفة الحشوة الميكانيكية (Mechanical Seal)؟',
      fr: 'Dans une pompe centrifuge, quelle est la fonction de la garniture mécanique ?',
      en: 'Inside a centrifugal pump, what is the critical mechanical purpose of the Cartridge Mechanical Seal?',
    },
    options: {
      ar: ['منع تسرب السائل المضغوط على طول عمود الدوران ومنع تسرب الهواء إلى غرفة السحب', 'زيادة سرعة دوران المحرك', 'تغيير اتجاه الدوران العكسي', 'تقليل جهد التغذية الكهربائية'],
      fr: ['Assurer l’étanchéité le long de l’arbre rotatif sans fuite ni entrée d’air', 'Accélérer le rotor', 'Inverser le sens de rotation', 'Abaisser la tension d’alimentation'],
      en: ['Prevent pressurized fluid leakage along the rotating shaft and stop air ingress into suction', 'Increase motor shaft speed', 'Reverse rotation direction', 'Step down supply voltage'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'تلامس وجهين فائقي الاستواء (SiC / Carbon) داخل الحشوة يضمن إحكام الإغلاق حول العمود الدوار حتى مع الضغط والحرارة العاليين.',
      fr: 'La friction contrôlée entre faces SiC/Carbone assure une étanchéité dynamique fiable sous pression et chaleur.',
      en: 'Precision-lapped Silicon Carbide/Carbon seal faces contain process fluid cleanly along the spinning pump shaft.',
    },
    xpReward: 35,
  },
];
