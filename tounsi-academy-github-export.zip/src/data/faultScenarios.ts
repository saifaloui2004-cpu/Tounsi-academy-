/**
 * NEXUS WORKSHOP — Industrial Fault Diagnosis Scenarios
 * Real-world industrial mystery troubleshooting cases.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import { FaultScenario } from '../types';

export const FAULT_SCENARIOS: FaultScenario[] = [
  {
    id: 'cavitation_01',
    title: {
      ar: 'عطل تكهف مضخة التغذية الصناعية (Pump Cavitation)',
      fr: 'Phénomène de Cavitation sur Pompe de Gavage',
      en: 'Centrifugal Feed Pump Cavitation Incident',
    },
    system: {
      ar: 'منظومة الضخ وتغذية السوائل الحرارية',
      fr: 'Système de Pompage et Fluides Caloporteurs',
      en: 'Pumping & Thermal Fluid Circulation Circuit',
    },
    difficulty: 'Intermediate',
    xpPoints: 180,
    initialReport: {
      ar: 'المشغل يبلغ عن صدور صوت صاخب أشبه بطحن الحصى والرمال داخل جسم المضخة P-101، مع تذبذب مستمر في عداد تدفق السائل وانخفاض مفاجئ في الضغط الهيدروليكي بعد رفع درجة حرارة التشغيل.',
      fr: 'L’opérateur signale un bruit intense de gravillons concassés dans le corps de la pompe P-101, avec oscillation du débitmètre et chute de pression après montée en température.',
      en: 'Operator reports a loud crackling sound resembling gravel inside the casing of pump P-101, accompanied by oscillating flow rate and sudden pressure drop following thermal warm-up.',
    },
    symptoms: {
      visual: {
        ar: 'مؤشر مقياس ضغط السحب يهتز بعنف بين 0.2 و 0.8 bar، مؤشر التدفق يتأرجح بنسبة ±30%.',
        fr: 'L’aiguille du manomètre d’aspiration oscille violemment entre 0.2 et 0.8 bar, débit instable.',
        en: 'Suction pressure gauge needle violently fluctuating between 0.2 and 0.8 bar, flow fluctuating ±30%.',
      },
      auditory: {
        ar: 'صوت فرقعة وتكسير حاد عالي التردد متقطع يشبه قصف الحصى ضد المعدن.',
        fr: 'Bruit de crépitement métallique aigu et continu rappelant le broyage de billes.',
        en: 'Loud popping and snapping noises like gravel hitting inside the metallic casing.',
      },
      thermal: {
        ar: 'حرارة جسم المضخة طبيعية (85°C) وحرارة كراسي التحميل ضمن النطاق المقبول (62°C).',
        fr: 'Température du corps normale (85°C), paliers à 62°C.',
        en: 'Casing temperature normal (85°C), bearing housings steady at 62°C.',
      },
      vibration: {
        ar: 'طيف الاهتزاز يظهر قمم عشوائية غير متزامنة ذات ترددات عالية (> 2.5 kHz) على مستوى مروحة السحب (Impeller).',
        fr: 'Pic vibratoire aléatoire haute fréquence (> 2.5 kHz) sur la zone de volute.',
        en: 'High-frequency broadband random vibrations (> 2.5 kHz) concentrated around the impeller eye.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'pressure_gauge',
        testPoint: 'مقياس ضغط خط السحب (Suction Flange PT-01)',
        reading: '0.18 bar (موجب ضعيف جداً)',
        normalRange: '1.2 - 2.5 bar',
        unit: 'bar',
      },
      {
        tool: 'pressure_gauge',
        testPoint: 'مقياس ضغط الطرد (Discharge Flange PT-02)',
        reading: '3.1 bar (متذبذب)',
        normalRange: '5.5 - 6.0 bar',
        unit: 'bar',
      },
      {
        tool: 'vibration',
        testPoint: 'مستشعر الاهتزاز عند كرسي التحميل الأمامي DE',
        reading: '7.8 mm/s RMS (High frequency noise floor)',
        normalRange: '< 2.8 mm/s RMS',
        unit: 'mm/s',
      },
      {
        tool: 'thermal_camera',
        testPoint: 'فحص حراري لفلتر السحب Y-Strainer',
        reading: 'فرق حراري 12°C بين مدخل ومخرج الفلتر (انسداد جزئي)',
        normalRange: '< 2°C',
        unit: '°C',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'تلف كراسي التحميل وتآكل كريات البلي في المحرك',
          fr: 'Défaillance des roulements à billes du moteur électrique',
          en: 'Electric motor bearing failure and ball spalling',
        },
        isCorrect: false,
        explanation: {
          ar: 'حرارة كراسي التحميل طبيعية والاهتزازات عشوائية التردد وليست بتردد تدوير الكريات BPFO/BPFI.',
          fr: 'Les températures de palier sont stables et le spectre ne présente pas les fréquences de bague BPFO/BPFI.',
          en: 'Bearing temperatures are normal and the vibration spectrum lacks characteristic bearing pass frequencies.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'انسداد مصفاة السحب (Y-Strainer) مما خفّض ضغط السحب دون ضغط البخار (NPSHa < NPSHr)',
          fr: 'Colmatage du filtre d’aspiration Y entraînant une chute de pression sous la tension de vapeur (NPSHa < NPSHr)',
          en: 'Clogged suction Y-strainer causing suction pressure drop below vapor pressure (NPSHa < NPSHr)',
        },
        isCorrect: true,
        explanation: {
          ar: 'صحيح 100%! انخفاض ضغط السحب إلى 0.18 bar مع فرق حرارة 12°C على الفلتر يعني انسداده بشوائب، ما جعل الضغط يقل عن ضغط بخار السائل فتشكلت فقاعات بخارية انهارت على ريش المروحة مسببة التكهف.',
          fr: 'Exact ! Le filtre colmaté réduit le NPSH disponible en dessous du NPSH requis, créant des bulles de vapeur qui implosent contre la roue.',
          en: 'Correct! The clogged suction strainer choked the inlet line, dropping NPSHa below NPSHr and triggering vapor bubble formation and violent collapse against the impeller.',
        },
      },
      {
        id: 'cause_3',
        text: {
          ar: 'دوران المحرك الكهربائي في الاتجاه العكسي',
          fr: 'Inversion du sens de rotation du moteur triphasé',
          en: 'Reverse rotation of the three-phase electric motor',
        },
        isCorrect: false,
        explanation: {
          ar: 'الدوران العكسي يخفض الضغط والتدفق لكنه لا يسبب صوت حصى عالي التردد وتذبذب ضغط السحب.',
          fr: 'Un sens inversé réduit le débit mais ne crée pas de bruits de cavitation brutaux ni chute de NPSH.',
          en: 'Reverse rotation lowers head and flow, but does not generate gravel-like bubble implosion sounds.',
        },
      },
      {
        id: 'cause_4',
        text: {
          ar: 'كسر في عمود الإدارة (Shaft Shear)',
          fr: 'Rupture franche de l’arbre de transmission',
          en: 'Catastrophic mechanical shaft shear',
        },
        isCorrect: false,
        explanation: {
          ar: 'المضخة لا تزال تنتج ضغطاً جزئياً (3.1 bar) وتدفقاً، مما ينفي انكسار العمود بالكامل.',
          fr: 'La pompe génère encore 3.1 bar, ce qui exclut une rupture totale d’arbre.',
          en: 'The pump is still producing 3.1 bar discharge head, disproving complete shaft shearing.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'عزل المضخة كهربائياً وتطبيق إجراءات القفل والوسم (LOTO).',
        fr: 'Consigner électriquement le moteur (procédure LOTO).',
        en: 'Isolate the pump electrically and apply Lockout/Tagout (LOTO).',
      },
      {
        ar: 'إغلاق صمامات العزل على السحب والطرد وتصريف الضغط المتبقي.',
        fr: 'Isoler les vannes manuelles amont/aval et dépressuriser la ligne.',
        en: 'Close suction and discharge isolation valves and depressurize the chamber.',
      },
      {
        ar: 'فك غطاء مصفاة السحب Y-Strainer وسحب السلة الفولاذية.',
        fr: 'Démonter le chapeau du filtre Y et extraire le panier filtrant.',
        en: 'Unbolt suction Y-strainer bonnet and remove the mesh basket.',
      },
      {
        ar: 'تنظيف السلة من الرواسب والخبث وإعادة تركيبها مع حشية جديدة.',
        fr: 'Nettoyer les sédiments métalliques et remonter avec un joint neuf.',
        en: 'Clean debris from the stainless basket and reinstall with a fresh gasket.',
      },
      {
        ar: 'فتح صمامات السحب، تنفيس الهواء، ثم إعادة تشغيل المضخة ومراقبة الضغط.',
        fr: 'Ouvrir l’aspiration, purger l’air et redémarrer sous surveillance.',
        en: 'Open suction valve, vent trapped air, restart pump and verify pressure stability.',
      },
    ],
    recommendedSolution: {
      ar: 'تنظيف سلة المصفاة Y-Strainer واستبدال الحشية، وإجراء فحص دوري لفرق الضغط (ΔP) شهرياً لمنع تكرار حدوث التكهف وتآكل ريش المروحة.',
      fr: 'Nettoyage approfondi du tamis filtrant, remplacement du joint d’étanchéité, et mise en place d’un contrôle régulier de la pression différentielle.',
      en: 'Clean the Y-strainer mesh basket, renew sealing gasket, and implement monthly differential pressure checks to safeguard against recurrent cavitation pitting.',
    },
    safetyRule: {
      ar: 'خطر الحروق والسوائل الساخنة: لا تفتح غطاء الفلتر قبل التأكد من برودة المنظومة وتفريغ الضغط بالكامل عبر محبس التنفيس.',
      fr: 'Danger fluide chaud: Ne jamais dévisser le filtre sans contrôle de température (< 40°C) et mise à l’atmosphère préalable.',
      en: 'Thermal burn hazard: Never open strainer bonnet until fluid cools below 40°C and residual pressure is vented to atmospheric zero.',
    },
  },
  {
    id: 'bearing_02',
    title: {
      ar: 'تلف وانهيار كرسي التحميل في محرك 45kW (Bearing Failure)',
      fr: 'Défaillance de Roulement sur Moteur de Broyage 45kW',
      en: '45kW Electric Motor Bearing Seizure & Failure',
    },
    system: {
      ar: 'وحدة الدفع الميكانيكي وخط السير الناقل',
      fr: 'Ligne de Transmission et Convoyeur Principal',
      en: 'Mechanical Drive Unit & Primary Conveyor Belt',
    },
    difficulty: 'Intermediate',
    xpPoints: 170,
    initialReport: {
      ar: 'حرارة محرك السير الناقل ترتفع بشكل حاد عند الطرف المقابل لعلبة التروس (Drive End)، مع سماع صوت هدير واحتكاك مستمر وتصاعد رائحة شحم محترق.',
      fr: 'La température du palier avant du moteur grimpe anormalement avec un grondement métallique sourd et une odeur de graisse brûlée.',
      en: 'Motor drive-end bearing housing is extremely hot with a deep grinding rumble and faint smell of scorched lubricant.',
    },
    symptoms: {
      visual: {
        ar: 'تسرب شحم أسود متفحم من حلقة منع التسرب الزيتية على عمود المحرك.',
        fr: 'Fuite de graisse noircie et carbonisée autour de la bague d’étanchéité.',
        en: 'Carbonized black grease oozing past the shaft labyrinth seal.',
      },
      auditory: {
        ar: 'صوت خشونة واحتكاك مستمر يزداد صخبه بزيادة الحمل والسرعة.',
        fr: 'Grondement sourd et frottement continu s’intensifiant sous charge.',
        en: 'Continuous harsh metallic grinding noise amplifying under conveyor load.',
      },
      thermal: {
        ar: 'حرارة غطاء كرسي التحميل DE بلغت 98°C بينما الطرف الآخر NDE عند 45°C فقط.',
        fr: 'Le palier DE atteint 98°C contre 45°C pour le palier arrière NDE.',
        en: 'Drive End (DE) bearing measures 98°C while Non-Drive End (NDE) is only 45°C.',
      },
      vibration: {
        ar: 'اهتزاز عالي جداً 11.2 mm/s RMS مع وضوح تردد مسار الحلقة الخارجية BPFO.',
        fr: 'Vibration globale critique de 11.2 mm/s RMS avec harmoniques BPFO prédominantes.',
        en: 'Critical overall vibration of 11.2 mm/s RMS with distinct BPFO outer-race defect harmonics.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'thermal_camera',
        testPoint: 'غطاء كرسي التحميل الأمامي (DE Housing)',
        reading: '98.4°C (حرارة حرجة متجاوزة الحد 80°C)',
        normalRange: '50 - 70°C',
        unit: '°C',
      },
      {
        tool: 'vibration',
        testPoint: 'قياس الاهتزاز الشعاعي DE Radial',
        reading: '11.2 mm/s RMS (فئة ISO 10816 الحمراء)',
        normalRange: '< 2.3 mm/s RMS',
        unit: 'mm/s',
      },
      {
        tool: 'multimeter',
        testPoint: 'تيار سحب المحرك (Phase Current Phase L1/L2/L3)',
        reading: '82 A (أعلى من التيار الاسمي 76 A بسبب زيادة الاحتكاك)',
        normalRange: '74 - 76 A',
        unit: 'A',
      },
      {
        tool: 'pressure_gauge',
        testPoint: 'ضغط مضخة التشحيم اليدوية',
        reading: 'انسداد في مجرى نبلة التشحيم (Zerk fitting blocked)',
        normalRange: 'مجرى سالك',
        unit: 'bar',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'جفاف الشحم وانهيار كرات البلي وتآكل مجرى الحلقة الخارجية (Bearing Spalling / Starvation)',
          fr: 'Rupture du film lubrifiant et écaillage de la bague externe du roulement',
          en: 'Lubrication starvation and outer ring spalling on the ball bearing',
        },
        isCorrect: true,
        explanation: {
          ar: 'صحيح! جفاف الشحم أدى لاحتكاك جاف مباشر وارتفاع الحرارة لـ 98°C وتولد اهتزاز BPFO، مما يتطلب استبدال كرسي التحميل فوراً.',
          fr: 'Parfait ! Le manque de lubrification a détruit la piste externe (BPFO) et surchauffé le roulement.',
          en: 'Correct! Grease starvation led to metal-to-metal contact, overheating to 98°C, and outer race spalling.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'انخفاض جهد التغذية للشبكة الكهربائية',
          fr: 'Chute de tension du réseau électrique triphasé',
          en: 'Mains electrical undervoltage supply drop',
        },
        isCorrect: false,
        explanation: {
          ar: 'انخفاض الجهد يسخن ملفات المحرك كاملة بالتساوي ولا يسبب تسخين موضعي لكرسي واحد واهتزاز 11.2 mm/s.',
          fr: 'Une sous-tension chaufferait tout le stator, pas uniquement un palier mécanique localisé.',
          en: 'Undervoltage heats all windings evenly, it does not cause localized bearing overheating to 98°C.',
        },
      },
      {
        id: 'cause_3',
        text: {
          ar: 'انقطاع حزام نقل الحركة (Belt snapping)',
          fr: 'Rupture d’une courroie de transmission trapézoïdale',
          en: 'V-belt mechanical snapping or detachment',
        },
        isCorrect: false,
        explanation: {
          ar: 'انقطاع الحزام يلغي الحمل ويقلل التيار، بينما هنا المحرك يسحب 82A تحت إجهاد ميكانيكي متزايد.',
          fr: 'La rupture de courroie annulerait la charge et réduirait le courant.',
          en: 'A snapped belt unloads the motor and reduces current, whereas current here is elevated at 82A.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'إيقاف فوري للخط وتطبيق إجراء القفل والوسم LOTO.',
        fr: 'Arrêt d’urgence et consignation LOTO du démarreur moteur.',
        en: 'Immediate emergency shutdown and electrical LOTO isolation.',
      },
      {
        ar: 'فك وصلة الربط الميكانيكية (Coupling) وتدوير المحور باليد للتحقق من الخشونة.',
        fr: 'Désaccoupler l’arbre et tester la rotation manuelle.',
        en: 'Decouple motor shaft and rotate rotor manually to feel roughness and binding.',
      },
      {
        ar: 'سحب كرسي التحميل التالف باستخدام زرجينة هيدروليكية (Hydraulic Puller).',
        fr: 'Extraire le roulement endommagé avec un extracteur hydraulique.',
        en: 'Extract defective bearing using a professional hydraulic puller without scoring the shaft.',
      },
      {
        ar: 'فحص مقعد العمود بالميكروميتر للتأكد من عدم وجود خدوش أو تآكل.',
        fr: 'Contrôler la portée de l’arbre au micromètre.',
        en: 'Measure shaft seat tolerance with an outside micrometer to confirm zero ovality.',
      },
      {
        ar: 'تسخين كرسي التحميل الجديد بجهاز الحث الكهرومغناطيسي لـ 110°C وتركيبه وملئه بشحم الليثيوم المخصص.',
        fr: 'Monter le roulement neuf chauffé par induction à 110°C et graisser au lithium.',
        en: 'Heat new C3 clearance bearing to 110°C with an induction heater, mount flush, and apply fresh grease.',
      },
    ],
    recommendedSolution: {
      ar: 'استبدال كرسي التحميل DE بكرسي جديد ذو خلوص C3، وإعادة محاذاة العمود بجهاز الليزر بدقة أقل من 0.05 mm، وإصلاح نبلة التشحيم المسدودة.',
      fr: 'Remplacement du roulement par un modèle neuf jeu C3, lignage laser < 0.05 mm et désobstruction du graisseur.',
      en: 'Install new C3 clearance bearing, perform laser shaft realignment to < 0.05 mm tolerance, and purge blocked grease line.',
    },
    safetyRule: {
      ar: 'ممنوع منعاً باتاً تسخين كرسي التحميل باستخدام اللهب المباشر (الشعلة) لأن ذلك يتلف المعالجة الحرارية للمعدن ويسبب انفجاره.',
      fr: 'Interdiction formelle de chauffer un roulement au chalumeau à flamme nue.',
      en: 'Strict prohibition against heating bearings with an open flame torch; always use an induction heater to avoid metallurgical tempering damage.',
    },
  },
  {
    id: 'overheat_motor_03',
    title: {
      ar: 'سخونة مفرطة وانطلاق المرحل الحراري لمضخة التبريد (Motor Overheating)',
      fr: 'Surchauffe Moteur et Déclenchement Relais Thermique',
      en: 'Cooling Pump Motor Overheating & Thermal Trip',
    },
    system: {
      ar: 'دائرة التحكم والقوى لمحرك مضخة التبريد 15kW',
      fr: 'Circuit de Puissance et Commande Pompe de Refroidissement 15kW',
      en: '15kW Cooling Tower Circulation Pump Drive',
    },
    difficulty: 'Beginner',
    xpPoints: 140,
    initialReport: {
      ar: 'محرك مضخة التبريد يفصل تلقائياً بعد 12 دقيقة من كل تشغيل مع إضاءة لمبة العطل الحراري Overload F1 في لوحة التحكم، وحرارة غلاف المحرك ساخنة جداً للمس.',
      fr: 'Le moteur déclenche après 12 minutes de service avec voyant thermique F1 allumé, carcasse brûlante.',
      en: 'Motor trips consistently after 12 minutes of run time with the F1 Overload pilot lamp glowing; casing is scorching hot.',
    },
    symptoms: {
      visual: {
        ar: 'ريش مروحة تبريد المحرك مغطاة بطبقة سميكة من الألياف والغبار، وشبكة التهوية مسدودة بالكامل.',
        fr: 'Capot de ventilation et ailettes colmatés par une épaisse couche de poussières.',
        en: 'Cooling fan cowl and motor heatsink ribs completely blanketed by heavy industrial textile lint and dust.',
      },
      auditory: {
        ar: 'صوت هواء التبريد ضعيف ومكتوم جداً، والمحرك يصدر طنيناً كهرومغناطيسياً ثقيلاً.',
        fr: 'Flux d’air ventilé quasi inexistant, bourdonnement magnétique.',
        en: 'Very faint airflow from the fan cowl; heavy 50Hz electromagnetic buzz.',
      },
      thermal: {
        ar: 'حرارة غلاف المحرك الخارجي بلغت 114°C متجاوزة حد عزل الصنف Class F.',
        fr: 'Température carcasse mesurée à 114°C (dépassement classe d’isolation F).',
        en: 'Motor stator frame temperature reached 114°C, breaching thermal insulation Class F safe limits.',
      },
      vibration: {
        ar: 'الاهتزاز طبيعي ومنخفض (1.4 mm/s RMS).',
        fr: 'Niveau vibratoire normal (1.4 mm/s RMS).',
        en: 'Vibration normal at 1.4 mm/s RMS.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'thermal_camera',
        testPoint: 'هيكل زعانف المحرك الخارجي (Stator Frame Ribs)',
        reading: '114.2°C (خطر احتراق العازل الورنيشي)',
        normalRange: '< 80°C',
        unit: '°C',
      },
      {
        tool: 'multimeter',
        testPoint: 'قياس التيار للأطوار الثلاثة L1 / L2 / L3',
        reading: 'L1: 29.5A, L2: 29.8A, L3: 29.4A (تيار متوازن وقريب من الاسمي 29A)',
        normalRange: '28 - 30 A',
        unit: 'A',
      },
      {
        tool: 'multimeter',
        testPoint: 'مقاومة عزل الملفات ضد الأرضي (Megohmmeter 500V)',
        reading: '48 MΩ (العزل سليم لم يتعرض للانهيار بعد)',
        normalRange: '> 10 MΩ',
        unit: 'MΩ',
      },
      {
        tool: 'pressure_gauge',
        testPoint: 'سرعة تدفق هواء المروحة (Anemometer)',
        reading: '0.4 m/s (شبه منعدم بسبب انسداد الكابوت)',
        normalRange: '4.5 - 7.0 m/s',
        unit: 'm/s',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'انسداد شبكة غطاء مروحة التبريد وتراكم الغبار على زعانف تبديد الحرارة الخارجية',
          fr: 'Obstruction totale de la grille de ventilation et encrassement des ailettes de refroidissement',
          en: 'Complete blockage of the fan cowl cowl and severe fouling of motor heat-sink cooling ribs',
        },
        isCorrect: true,
        explanation: {
          ar: 'صحيح! التيارات متوازنة (29A) ومقاومة العزل ممتازة، مما يثبت أن الخلل ليس كهربائياً بل انعدام التبديد الحراري بسبب تراكم الألياف على المروحة.',
          fr: 'Exactement ! Le moteur n’est pas en surcharge électrique (29A équilibré), c’est un étouffement thermique par manque de flux d’air.',
          en: 'Spot on! The balanced 29A phase currents and healthy 48 MΩ insulation confirm zero electrical fault; the stator simply overheated due to blocked convective airflow.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'سقوط أحد أطوار التغذية الكهربائية (Single Phasing Loss)',
          fr: 'Perte d’une phase d’alimentation triphasée',
          en: 'Loss of one phase in the 3-phase supply (Single-phasing)',
        },
        isCorrect: false,
        explanation: {
          ar: 'القياسات بالمقياس أظهرت تياراً متساوياً على الأطوار الثلاثة L1/L2/L3، وبالتالي الأطوار جميعها موصولة وسليمة.',
          fr: 'Le relevé au multimètre montre 29A sur chaque phase, les 3 phases sont donc bien présentes.',
          en: 'Multimeter showed ~29.5A balanced across all 3 phases, confirming all phases are healthy.',
        },
      },
      {
        id: 'cause_3',
        text: {
          ar: 'عطل في مفتاح تشغيل اللوحة Start Button',
          fr: 'Défaut du bouton poussoir Marche de l’armoire',
          en: 'Defective control panel start push button',
        },
        isCorrect: false,
        explanation: {
          ar: 'المحرك يعمل لـ 12 دقيقة كاملة قبل الفصل، مما يعني أن دائرة التحكم تبدأ التشغيل بنجاح تام.',
          fr: 'Le moteur tourne pendant 12 minutes, le bouton de commande fonctionne parfaitement.',
          en: 'The motor runs for 12 continuous minutes, verifying the start button circuit is fully operational.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'فصل القاطع الرئيسي Q1 وعزل لوحة التحكم وتطبيق LOTO.',
        fr: 'Consigner le départ moteur Q1.',
        en: 'Lockout/tagout the circuit breaker Q1.',
      },
      {
        ar: 'فك غطاء مروحة التبريد البلاستيكي/المعدني (Fan Cowl).',
        fr: 'Dévisser le capot de ventilation.',
        en: 'Unfasten and remove the rear fan cowl shroud.',
      },
      {
        ar: 'تنظيف ريش مروحة التبريد وزعانف المحرك بضغط الهواء الجاف وفرشاة غير معدنية.',
        fr: 'Souffler à l’air comprimé sec et brosser les ailettes de la carcasse.',
        en: 'Blow compressed dry air and brush all lint and debris from ribs and fan blades.',
      },
      {
        ar: 'إعادة تركيب الغطاء وضبط عيار المرحل الحراري F1 بدقة على 1.05 من التيار الاسمي.',
        fr: 'Remonter le capot et vérifier le réglage thermique F1 à In.',
        en: 'Reassemble cowl securely and verify thermal relay F1 dial is calibrated to motor rated full-load current.',
      },
    ],
    recommendedSolution: {
      ar: 'تنظيف شامل لغطاء المروحة وزعانف التبريد، وإدراج المحرك ضمن جدول التنظيف الوقائي الشهري للبيئات كثيفة الغبار.',
      fr: 'Nettoyage complet du circuit d’aération et intégration du dépoussiérage dans la gamme préventive mensuelle.',
      en: 'Perform thorough convective duct cleaning and incorporate bi-weekly compressed air blowing into plant PM routines.',
    },
    safetyRule: {
      ar: 'لا تلمس غلاف المحرك بيدك المجردة عندما تتجاوز حرارته 70°C تجنباً للحروق الجلدية المباشرة.',
      fr: 'Ne jamais toucher une carcasse moteur à plus de 70°C sans gants de protection thermique.',
      en: 'Never place bare hands on motor casings exceeding 70°C; always use thermal imaging or non-contact pyrometers.',
    },
  },
  {
    id: 'thermal_oil_low_press_04',
    title: {
      ar: 'هبوط ضغط منظومة الزيت الحراري وتشكل غازات التبخير (Thermal Oil Vapor Lock)',
      fr: 'Chute de Pression et Vaporisation dans le Circuit d’Huile Thermique',
      en: 'Thermal Oil Pressure Drop & Light-Ends Vapor Locking',
    },
    system: {
      ar: 'غلاية وشبكة الزيت الحراري (Huile Thermique) 1.2 MW',
      fr: 'Chaudière et Réseau Fluide Caloporteur 1.2 MW',
      en: '1.2 MW Industrial Thermal Fluid Heating Plant',
    },
    difficulty: 'Advanced',
    xpPoints: 210,
    initialReport: {
      ar: 'انطلاق إنذار هبوط الضغط المنخفض (Low Differential Pressure Switch) لمرجل الزيت الحراري مع توقف آلي للمشعل لمنع تفحم الأنابيب الحلزونية، وتذبذب كبير في مستوى خزان التمدد العلوي.',
      fr: 'Alarme pressostat différentiel bas avec coupure sécurité brûleur et niveau instable au vase d’expansion.',
      en: 'Boiler safety shutdown triggered by low differential pressure switch; burner locked out to prevent coil tube burn-out.',
    },
    symptoms: {
      visual: {
        ar: 'مؤشر منسوب خزان التمدد (Expansion Tank Sight Glass) يظهر خروج فقاعات غازية مستمرة مع زيت رغوي.',
        fr: 'Mousse et bulles de gaz visibles dans le tube de niveau du vase d’expansion.',
        en: 'Foaming and intermittent vapor gas bubbling visible in the expansion tank sight glass.',
      },
      auditory: {
        ar: 'أصوات خفقان وارتطام هيدروليكي داخل الأنابيب قرب المبدل الحراري.',
        fr: 'Coups de bélier et claquements hydrauliques dans la tuyauterie.',
        en: 'Hydraulic hammer and burping noises echoing inside process heat exchanger piping.',
      },
      thermal: {
        ar: 'حرارة خزان التمدد وصلت لـ 95°C (أعلى بكثير من الحد الأقصى الآمن 60°C للخزانات الباردة المفتوحة).',
        fr: 'Vase d’expansion surchauffé à 95°C (seuil max admissible: 60°C).',
        en: 'Expansion tank temperature elevated to 95°C (far above normal 60°C cold-seal blanket limit).',
      },
      vibration: {
        ar: 'اهتزاز عشوائي ناتج عن مرور سدادات غازية (Vapor Pockets) في مسار الضخ.',
        fr: 'Chocs vibratoires intermittents causés par le passage de poches de vapeur.',
        en: 'Intermittent shock vibrations caused by slugs of vapor pocketing in the pump volute.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'pressure_gauge',
        testPoint: 'فرق الضغط على المرجل (Differential Pressure ΔP)',
        reading: '0.6 bar (أقل من الحد الأدنى للأمان 1.4 bar)',
        normalRange: '1.8 - 2.4 bar',
        unit: 'bar',
      },
      {
        tool: 'thermal_camera',
        testPoint: 'أنبوب التمدد المتصل بالخزان العلوي (Expansion Pipe)',
        reading: '185°C (تدفق حراري عكسي بسبب عدم إغلاق صمام الغاز أو تلف حلقة الفصل)',
        normalRange: '< 60°C',
        unit: '°C',
      },
      {
        tool: 'pressure_gauge',
        testPoint: 'ضغط مضخة التدوير P-01',
        reading: '1.2 bar (انخفاض حاد عن القيمة الاسمية 4.8 bar)',
        normalRange: '4.5 - 5.0 bar',
        unit: 'bar',
      },
      {
        tool: 'thermal_camera',
        testPoint: 'حرارة الزيت في قلب المرجل (Coil Exit Temp)',
        reading: '282°C (قريب من نقطة التحلل الحراري للزيت)',
        normalRange: '220 - 250°C',
        unit: '°C',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'تلوث الزيت الحراري بالماء وتفكك السلاسل الهيدروكربونية الخفيفة (Light Ends) مما ولد ضغط بخار مرتفع',
          fr: 'Présence d’humidité/eau et dégradation thermique générant des fractions volatiles (Light Ends)',
          en: 'Moisture/water contamination and cracked light-end hydrocarbons generating excessive vapor pressure',
        },
        isCorrect: true,
        explanation: {
          ar: 'ممتاز! الماء عند 280°C يتبخر ويتمدد بأكثر من 1600 ضعف حجمه، مما يخلق فقاعات بخارية تدفع الزيت الساخن لخزان التمدد وتسقط ضغط الضخ.',
          fr: 'Exact ! Une trace d’eau se vaporise violemment à haute température, provoquant une désamorçage de pompe et moussage au vase.',
          en: 'Correct! Even minute moisture expands over 1600x as steam at 280°C, causing vapor lock, cavitation, and pushing hot oil into the expansion tank.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'انفصال وصلة القابض الميكانيكي للمضخة',
          fr: 'Rupture de l’accouplement de pompe',
          en: 'Mechanical pump coupling shear',
        },
        isCorrect: false,
        explanation: {
          ar: 'المضخة ما تزال تدور وتولد 1.2 bar مع وجود أصوات خفقان وفقاعات، ما ينفي انقطاع الوصلة كلياً.',
          fr: 'La pompe débite encore 1.2 bar, l’accouplement n’est pas rompu.',
          en: 'The pump continues to spin and build 1.2 bar partial pressure, disproving total coupling shear.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'إبقاء مضخة التدوير قيد العمل مع إيقاف المشعل لتبريد المنظومة تدريجياً وتجنب تفحم الأنابيب.',
        fr: 'Maintenir la circulation sans brûleur pour refroidir l’huile sans cokéfaction.',
        en: 'Keep main circulation pump running while holding burner off to safely cool fluid below 150°C.',
      },
      {
        ar: 'فتح محابس التنفيس (Degassing Valves) أعلى خزان التمدد لتصريف البخار والغازات الخفيفة.',
        fr: 'Ouvrir la ligne de dégazage au sommet du vase d’expansion.',
        en: 'Open manual degassing vent lines on top of the expansion tank to exhaust light ends and moisture.',
      },
      {
        ar: 'أخذ عينة من الزيت الحراري وإرسالها للتحليل المخبري (فحص نقطة الوميض Flash Point واللزوجة).',
        fr: 'Prélever un échantillon d’huile pour analyse du point éclair et de la viscosité.',
        en: 'Extract fluid sample from sampling cooler to test flash point, acid number (TAN), and viscosity.',
      },
      {
        ar: 'تطبيق دورة تجفيف وبخار بطيئة (Boiling-out procedure) عند 105°C - 120°C لطرد بقايا الرطوبة.',
        fr: 'Effectuer un palier de séchage et dégazage prolongé entre 105°C et 120°C.',
        en: 'Execute a controlled dehydration boil-out protocol between 105°C and 120°C before resuming full duty.',
      },
    ],
    recommendedSolution: {
      ar: 'تنفيذ برنامج التخلص من الغازات الخفيفة (Degassing) وتثبيت بطانية نيتروجين جاف (Nitrogen Blanketing) على خزان التمدد لمنع أكسدة الزيت وتكثف الرطوبة الجوية.',
      fr: 'Procédure complète de dégazage et installation d’un inertage à l’azote sur le vase d’expansion.',
      en: 'Perform complete thermal degassing and install dry nitrogen blanketing on the expansion vessel to prevent future atmospheric oxidation and water ingress.',
    },
    safetyRule: {
      ar: 'خطر الانفجار والحريق: لا تصرف بخار الزيت الساخن في بيئة مغلقة، ويجب توجيهه إلى خزان التكثيف أو مدخنة آمنة.',
      fr: 'Risque d’incendie: Les évents de dégazage doivent déboucher vers une zone sécurisée extérieure.',
      en: 'Fire & explosion hazard: Never vent hot hydrocarbon vapors into an enclosed workspace; vent to a safe condensing blowdown vessel.',
    },
  },
  {
    id: 'short_circuit_05',
    title: {
      ar: 'التماس كهربائي مباشر والتصاق ملامسات الكونتاكتور (Contactor Contact Welding)',
      fr: 'Court-Circuit Franc et Soudure des Pôles du Contacteur',
      en: 'Severe Phase Short-Circuit & Contactor Contact Welding',
    },
    system: {
      ar: 'لوحة التحكم الكهربائية المركزية (MCC Cabinet)',
      fr: 'Armoire de Commande Moteur MCC',
      en: 'Central Motor Control Center (MCC)',
    },
    difficulty: 'Advanced',
    xpPoints: 190,
    initialReport: {
      ar: 'عند الضغط على زر الإيقاف S0، لم يتوقف محرك الضاغط وظل يدور بشكل خطير! القاطع المغناطيسي الفرعي لم يفصل وأصبح جسم الكونتاكتور KM1 شديد السخونة مع رائحة تفحم.',
      fr: 'À l’appui sur l’arrêt S0, le moteur compresseur ne s’arrête pas ! Le contacteur KM1 reste collé mécaniquement.',
      en: 'Pressing Stop button S0 fails to halt the 30kW air compressor! Contactor KM1 remains locked in the pulled-in state with heavy ozone/arcing odor.',
    },
    symptoms: {
      visual: {
        ar: 'ملامسات الكونتاكتور الرئيسية ملتحمة ببعضها بذوبان نحاسي وفحم أسود على غرفة إطفاء القوس.',
        fr: 'Pôles de puissance soudés par fusion de cuivre et traces de noir d’arc.',
        en: 'Main power contact pads physically melted and welded together with soot in arc chutes.',
      },
      auditory: {
        ar: 'صوت فرقعة شرارة قوية سابقة لحظة محاولة الفصل.',
        fr: 'Claquement d’arc électrique violent entendu précédemment.',
        en: 'Loud explosive arc snap reported prior to the failure.',
      },
      thermal: {
        ar: 'حرارة عالية جداً على أقطاب الكونتاكتور KM1 (> 130°C).',
        fr: 'Température extrême mesurée sur les pôles du contacteur.',
        en: 'Extreme localized heat (> 130°C) radiating from KM1 terminal screws.',
      },
      vibration: {
        ar: 'طنين اهتزازي من ملف الكونتاكتور المغناطيسي.',
        fr: 'Vibration acoustique de la bobine 50Hz.',
        en: '50Hz electromagnetic core chatter.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'multimeter',
        testPoint: 'جهد ملف التحكم للكونتاكتور A1 - A2',
        reading: '0.0 V (الملف مفصول كهربائياً ولكن الملامسات عالقة ميكانيكياً بفعل اللحام)',
        normalRange: '230 V أثناء التشغيل / 0 V عند الإيقاف',
        unit: 'V',
      },
      {
        tool: 'multimeter',
        testPoint: 'مقاومة الاستمرارية بين مدخل ومخرج القطب L1-T1 (مع فصل التغذية)',
        reading: '0.02 Ω (دائرة مغلقة وملحومة رغم إيقاف الأمر)',
        normalRange: '∞ (دائرة مفتوحة عند الإيقاف)',
        unit: 'Ω',
      },
      {
        tool: 'multimeter',
        testPoint: 'مقاومة العزل بين الطورين L1 و L2 عند علبة المحرك',
        reading: '0.1 Ω (قصر كهربائي ناتج عن تآكل عازل الكابل الميكانيكي)',
        normalRange: '> 10 MΩ',
        unit: 'MΩ',
      },
      {
        tool: 'thermal_camera',
        testPoint: 'فحص حراري لأقطاب KM1',
        reading: '138°C (حرارة انصهار سبيكة الفضة والنحاس)',
        normalRange: '< 55°C',
        unit: '°C',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'حدوث التماس قصر بين الأطوار نتيجة اهتراء كابل المحرك، مما ولد تيار قصر هائل لحم ملامسات الكونتاكتور',
          fr: 'Court-circuit franc câble moteur ayant engendré un arc thermique qui a soudé les contacts',
          en: 'Inter-phase short circuit from cable chafing generating high prospective arc current that welded contacts',
        },
        isCorrect: true,
        explanation: {
          ar: 'بالضبط! تيار القصر العالي جداً يولد حرارة تتجاوز 1000°C في أجزاء من الثانية فتذيب سبائك الفضة بالملامسات وتلحمها، مما يمنع فصلها رغم انقطاع جهد الملف A1-A2.',
          fr: 'Exact ! L’énergie de court-circuit a fondu les pastilles d’argent, les soudant de façon permanente.',
          en: 'Exactly! Extreme short-circuit I²t energy melted silver-alloy contact tips, permanently fusing them together even with zero coil voltage.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'انخفاض سعة مكثف تحسين معامل القدرة',
          fr: 'Baisse de capacité des condensateurs cos phi',
          en: 'Power factor correction capacitor degradation',
        },
        isCorrect: false,
        explanation: {
          ar: 'مكثف معامل القدرة لا يسبب التصاق ملامسات الكونتاكتور بتيار قصر مباشر وقراءة 0.1 Ω بين الأطوار.',
          fr: 'Un défaut de condensateur ne soude pas les contacts de cette manière.',
          en: 'Capacitor bank drift does not cause 0.1 Ω dead phase-to-phase shorts or welded poles.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'فصل القاطع التفاضلي الرئيسي المغذي للوحة كلياً وقطع التيار عن المصدر (Upstream Disconnect).',
        fr: 'Couper l’interrupteur général en amont de l’armoire.',
        en: 'Open the upstream main molded-case circuit breaker (MCCB) supplying the panel.',
      },
      {
        ar: 'التحقق من غياب الجهد بواسطة جهاز فحص الجهد المعتمد (VAT).',
        fr: 'Effectuer la Vérification d’Absence de Tension (VAT).',
        en: 'Verify zero voltage on all 3 incoming phases using a certified two-pole voltage tester.',
      },
      {
        ar: 'استبدال كابل المحرك المتآكل وإصلاح مسار التمديد في القنوات الواقية.',
        fr: 'Remplacer le câble moteur détérioré.',
        en: 'Replace severed motor cable and install protective conduit grommets.',
      },
      {
        ar: 'استبدال الكونتاكتور KM1 التالف بآخر جديد بنفس فئة الاستخدام (AC-3) مع فحص القاطع Q1.',
        fr: 'Remplacer le contacteur KM1 par un composant neuf catégorie AC-3.',
        en: 'Replace damaged KM1 with a new industrial AC-3 rated contactor and verify trip curve on Q1.',
      },
    ],
    recommendedSolution: {
      ar: 'استبدال الكونتاكتور والكابل المعطوب، والتأكد من ضبط القاطع المغناطيسي على تيار قصر يقطع الدائرة في زمن أقل من 0.02 ثانية لحماية المكونات.',
      fr: 'Remplacement du contacteur et du câble, ajustement du seuil magnétique du disjoncteur.',
      en: 'Replace contactor KM1, install new shielded motor feeder cable, and recalibrate upstream magnetic trip curve for fast arc clearing (< 20 ms).',
    },
    safetyRule: {
      ar: 'قوس التفريغ الكهربائي (Arc Flash): لا تفتح باب لوحة التوزيع أثناء التماس المباشر دون ارتداء واقي الوجه والقفازات العازلة 1000V.',
      fr: 'Risque d’Arc Flash: Port obligatoire de l’écran facial et des gants isolants 1000V.',
      en: 'Arc Flash Hazard: Always don 1000V rated insulated gloves and an arc-rated face shield prior to opening damaged live panels.',
    },
  },
  {
    id: 'hydraulic_creep_06',
    title: {
      ar: 'هبوط وزحف الأسطوانة الهيدروليكية وتسريب الحشوات الداخلية (Cylinder Seal Leakage)',
      fr: 'Dérive et Chute Spontanée de Vérin Hydraulique Sous Charge',
      en: 'Hydraulic Press Cylinder Drift & Piston Seal Bypass',
    },
    system: {
      ar: 'مكبس هيدروليكي صناعي 200 طن (Hydraulic Press)',
      fr: 'Presse Hydraulique d’Emboutissage 200 Tonnes',
      en: '200-Ton Industrial Deep Drawing Hydraulic Press',
    },
    difficulty: 'Advanced',
    xpPoints: 200,
    initialReport: {
      ar: 'أسطوانة المكبس الهيدروليكي تهبط وتنزلق ببطء (Creep) بمعدل 4 سم في الدقيقة عندما تكون في وضع التوقف والاحتفاظ بالضغط (Pressure Holding Mode)، دون أي تسريب خارجي للزيت على الأرض.',
      fr: 'Le coulisseau de la presse redescend lentement de 4 cm/min en maintien de pression, sans aucune fuite externe visible.',
      en: 'Hydraulic press platen slowly drifts downward at 4 cm/min during pressure-holding cycles, with zero external oil leakage on the shop floor.',
    },
    symptoms: {
      visual: {
        ar: 'قضيب الأسطوانة ينزلق ببطء إلى الأسفل، وعدم وجود أي قطرة زيت على الحشية الخارجية للجلند.',
        fr: 'Tige de vérin qui descend sous charge, aucune goutte d’huile au presse-étoupe.',
        en: 'Piston rod visibly creeps downward under payload; rod gland seal remains totally dry.',
      },
      auditory: {
        ar: 'صوت هسهسة ناعم ومستمر يشبه تسريب سائل مضغوط داخل جسم الأسطوانة.',
        fr: 'Sifflement continu étouffé à l’intérieur du corps du vérin.',
        en: 'Faint continuous hissing sound echoing from within the heavy cylinder barrel.',
      },
      thermal: {
        ar: 'ارتفاع موضعي في حرارة أنبوب خط العودة المتصل بالأسطوانة.',
        fr: 'Échauffement localisé sur la tuyauterie de retour chambre opposée.',
        en: 'Localized thermal hotspot on the cylinder opposite-chamber return line.',
      },
      vibration: {
        ar: 'اهتزاز طفيف مصاحب لدوامات التدفق الداخلي.',
        fr: 'Vibration de fluide laminaire.',
        en: 'Very low amplitude hydraulic fluid vortex murmur.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'pressure_gauge',
        testPoint: 'مقياس ضغط حجرة الدفع (Piston Bore Chamber PT-01)',
        reading: 'يهبط من 210 bar إلى 130 bar خلال 90 ثانية',
        normalRange: 'ثابت عند 210 bar',
        unit: 'bar',
      },
      {
        tool: 'thermal_camera',
        testPoint: 'غلاف الأسطوانة في منتصف الشوط (Barrel Mid-Stroke)',
        reading: 'حرارة مرتفعة موضعياً 54°C ناتجة عن الاحتكاك الهيدروليكي للتسريب الداخلي',
        normalRange: '36 - 38°C',
        unit: '°C',
      },
      {
        tool: 'pressure_gauge',
        testPoint: 'صمام عدم الرجوع الموجه (Pilot Operated Check Valve)',
        reading: 'الصمام مغلق ومحكم (0 bar على خط التحكم)',
        normalRange: 'مغلق تماماً',
        unit: 'bar',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'تلف وتآكل حلقات إحكام مكبس الأسطوانة الداخلي (Piston Seal Bypass) مما يسرب الزيت بين الحجرتين',
          fr: 'Usure des joints de piston internes permettant la dérivation d’huile entre les deux chambres',
          en: 'Internal piston seal degradation allowing fluid bypass between cap and rod chambers',
        },
        isCorrect: true,
        explanation: {
          ar: 'رائع! عدم وجود تسريب خارجي مع هبوط الضغط وارتفاع حرارة الأسطوانة يعني أن الزيت المضغوط يتسرب داخلياً عبر شفة المكبس التالفة إلى حجرة العودة.',
          fr: 'Exactement ! Le manque de fuite externe confirme un by-pass interne à travers les joints de piston usés.',
          en: 'Spot on! The lack of external puddle combined with the thermal hotspot confirms internal fluid laminar bypass across torn piston chevron packings.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'انفجار أنبوب السحب الرئيسي لمضخة الهيدروليك',
          fr: 'Éclatement du flexible d’aspiration pompe',
          en: 'Rupture of the main hydraulic suction hose',
        },
        isCorrect: false,
        explanation: {
          ar: 'انفجار الأنبوب يفرغ الزيت بغزارة على الأرض ويفقد المضخة ضغطها تماماً.',
          fr: 'Un flexible éclaté provoquerait un épandage massif d’huile.',
          en: 'A burst hose would catastrophically dump hundreds of liters of fluid onto the ground.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'تثبيت الأسطوانة ميكانيكياً باستخدام قفل الأمان (Safety Mechanical Rest prop).',
        fr: 'Mettre en place la béquille mécanique de sécurité sous le coulisseau.',
        en: 'Position and lock the mechanical safety prop under the platen.',
      },
      {
        ar: 'تفريغ الضغط الهيدروليكي المتبقي في المجمع (Accumulator) والدائرة بالكامل.',
        fr: 'Décharger l’accumulateur et mettre le circuit à zéro bar.',
        en: 'Depressurize accumulator bank and bleed circuit completely to 0 bar.',
      },
      {
        ar: 'فك غطاء رأس الأسطوانة وسحب المكبس مع العمود.',
        fr: 'Déposer la culasse et extraire l’ensemble tige-piston.',
        en: 'Unbolt cylinder head and carefully withdraw rod and piston assembly.',
      },
      {
        ar: 'فحص تجويف الأسطوانة (Honed Barrel ID) للتأكد من خلوه من الخدوش، واستبدال طقم الحشوات البوليمرية بالكامل.',
        fr: 'Inspecter l’alésage du cylindre et remplacer le kit complet de joints.',
        en: 'Inspect inner barrel micro-honing for scoring, replace full polyurethane piston seal kit.',
      },
    ],
    recommendedSolution: {
      ar: 'استبدال طقم حشوات المكبس بأخرى مقاومة للحرارة العالية والضغط العالي (PTFE + Bronze Energizer)، وتصفية زيت الهيدروليك لإزالة الشوائب المسببة للخدش.',
      fr: 'Remplacement du jeu de joints par des garnitures haute pression PTFE/Bronze et filtration d’huile.',
      en: 'Fit high-performance PTFE bronze-filled energized seal kit and polish barrel bore; flush and filter hydraulic fluid to ISO 4406 16/14/11.',
    },
    safetyRule: {
      ar: 'خطر السحق الميكانيكي: ممنوع العمل إطلاقاً تحت أسطوانة المكبس دون تثبيت قفل ميكانيكي صلب (Mechanical Safety Prop).',
      fr: 'Danger d’écrasement: Ne jamais intervenir sous le coulisseau sans blocage mécanique certifié.',
      en: 'Crush & Pinch Hazard: Never step under a suspended press ram without installing certified heavy-duty mechanical safety chocks.',
    },
  },
  {
    id: 'sensor_loop_07',
    title: {
      ar: 'انقطاع إشارة حلقة التحكم 4-20mA لمستشعر الضغط (Analog Sensor Loop Fault)',
      fr: 'Rupture de Boucle de Courant 4-20mA sur Transmetteur de Pression',
      en: '4-20mA Analog Current Loop Interruption & Sensor Drift',
    },
    system: {
      ar: 'نظام المراقبة والأتمتة في وحدة المعالجة الكيميائية',
      fr: 'Système d’Instrumentation et Contrôle-Commande API',
      en: 'PLC Process Instrumentation & Pressure Monitoring Loop',
    },
    difficulty: 'Intermediate',
    xpPoints: 160,
    initialReport: {
      ar: 'شاشة التحكم الصناعية SCADA تعرض قيمة ضغط ثابتة 0.0 bar باللون الأحمر مع إنذار Wire Break على المدخل التماثلي IW64 للـ PLC، رغم أن مقياس الضغط الميكانيكي الميداني يقرأ 4.2 bar.',
      fr: 'La supervision SCADA indique 0.0 bar avec alarme Rupture de Fil sur l’entrée API IW64, alors que le manomètre local affiche 4.2 bar.',
      en: 'Plant SCADA indicates 0.0 bar with a flashing "Loop Wire Break" alarm on PLC analog input IW64, yet local Bourdon gauge reads 4.2 bar.',
    },
    symptoms: {
      visual: {
        ar: 'مصباح LED الأحمر المعلم بـ SF/F يضيء على بطاقة المداخل التماثلية بالـ PLC.',
        fr: 'LED rouge défaut système SF allumée sur le module d’entrées analogiques API.',
        en: 'Red System Fault (SF) LED illuminated on the PLC analog input module rack.',
      },
      auditory: {
        ar: 'صفير إنذار مستمر من لوحة المراقبة المركزية.',
        fr: 'Bip sonore d’alarme process en salle de commande.',
        en: 'Pulsing audible alert tone on the central operator console.',
      },
      thermal: {
        ar: 'حرارة طبيعية في كافة المكونات.',
        fr: 'Températures normales.',
        en: 'Normal ambient operating temperatures.',
      },
      vibration: {
        ar: 'لا يوجد اهتزاز.',
        fr: 'Aucune vibration.',
        en: 'Zero vibration anomaly.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'multimeter',
        testPoint: 'تيار الحلقة التسلسلي (Current Loop mA in series)',
        reading: '0.00 mA (أقل من الحد الأدنى 3.6 mA للـ Live Zero)',
        normalRange: '4.00 - 20.00 mA',
        unit: 'mA',
      },
      {
        tool: 'multimeter',
        testPoint: 'جهد التغذية لمستشعر الضغط (+24VDC Terminal)',
        reading: '24.1 VDC (مصدر التغذية سليم تماماً)',
        normalRange: '23.5 - 24.5 VDC',
        unit: 'VDC',
      },
      {
        tool: 'multimeter',
        testPoint: 'فحص استمرارية السلك الراجع للمدخل التماثلي (Continuity Test)',
        reading: 'مقاومة لانهائية ∞ (سلك مقطوع داخل غدة علبة التوصيل الميدانية JB-04)',
        normalRange: '< 2.0 Ω',
        unit: 'Ω',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'انقطاع ميكانيكي في سلك إشارة الحلقة (4-20mA) داخل علبة التوصيل الميدانية بسبب الاهتزاز والشد',
          fr: 'Rupture physique du conducteur de boucle 4-20mA dans la boîte de jonction suite aux vibrations',
          en: 'Physical cable conductor rupture in field junction box due to vibration strain',
        },
        isCorrect: true,
        explanation: {
          ar: 'صحيح! حلقة 4-20mA مصممة لتكتشف انقطاع الأسلاك ذاتياً؛ فالتيار الطبيعي لا يقل عن 4mA، وعند هبوطه لـ 0.00mA فهذا يعني انقطاع الدائرة تماماً.',
          fr: 'Bravo ! Le principe du 4-20mA (zéro vivant) permet de détecter immédiatement la rupture lorsque le courant tombe à 0 mA.',
          en: 'Excellent! The classic 4-20mA live zero standard detects severed wire loops instantaneously when current plunges to 0.00 mA.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'تلف معالج الـ PLC بالكامل (CPU Failure)',
          fr: 'Panne complète de l’unité centrale automate (CPU)',
          en: 'Catastrophic PLC CPU module hardware failure',
        },
        isCorrect: false,
        explanation: {
          ar: 'الـ PLC يعمل طبيعياً وباقي الإشارات سليمة وتستجيب، والعطل محصور في مدخل الحلقة المتوقف.',
          fr: 'L’automate tourne et communique avec la supervision, seule cette voie est en défaut.',
          en: 'The PLC CPU is communicating actively and scanning other modules normally; failure is strictly isolated to loop channel IW64.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'عزل القناة التماثلية برموز السلامة وتفعيل وضع التشغيل اليدوي (Manual Mode) للوحدة.',
        fr: 'Bascule de la régulation en mode manuel pour sécuriser le procédé.',
        en: 'Switch PID controller loop to Manual mode to freeze actuator output safely.',
      },
      {
        ar: 'تتبع كابل الإشارة المحمي من مدخل الـ PLC وصولاً إلى علبة التوصيل JB-04.',
        fr: 'Inspecter le câble blindé jusqu’à la boîte de dérivation JB-04.',
        en: 'Trace instrument twisted-shielded cable from PLC Marshalling rack to field junction box JB-04.',
      },
      {
        ar: 'إعادة تقشير السلك النحاسي وتركيب طرفية معزولة (Ferrule) وربطها بإحكام في الروزيتة.',
        fr: 'Sertir un nouvel embout de câblage et resserrer le bornier.',
        en: 'Strip fresh copper conductor, crimp a calibrated bootlace ferrule, and torque down the terminal strip clamp.',
      },
      {
        ar: 'التحقق بجهاز حقن الإشارة (mA Calibrator) من استجابة شاشة الـ SCADA لقراءات 4mA, 12mA, 20mA.',
        fr: 'Valider l’échelle 4-20mA avec un générateur de courant étalon.',
        en: 'Inject calibrated 4mA, 12mA, and 20mA signals with a loop simulator to verify linearity on the SCADA display.',
      },
    ],
    recommendedSolution: {
      ar: 'إعادة ربط طرفية السلك المقطوع، واستخدام مرابط تثبيت مانعة للاهتزاز (Cable Cleats) لمنع إجهاد الأسلاك مستقبلاً.',
      fr: 'Raccordement de la borne et ajout d’un presse-étoupe anti-traction.',
      en: 'Re-terminate loop wiring with crimped ferrules and install strain-relief cable cord grips inside junction box JB-04.',
    },
    safetyRule: {
      ar: 'تأكد من تأريض درع الكابل (Shield) عند طرف واحد فقط (لوحة التحكم) لتجنب التيارات الدوامية الأرضية (Ground Loops).',
      fr: 'Raccorder le blindage du câble à la terre à une seule extrémité (côté armoire).',
      en: 'Ground cable drain wire/shield at one end only (the PLC control panel) to prevent ground loop noise interference.',
    },
  },
  {
    id: 'plc_estop_08',
    title: {
      ar: 'عطل حلقة إيقاف الطوارئ المزدوجة في الأتمتة (PLC Safety Relay E-Stop Fault)',
      fr: 'Défaut de Cohérence sur Boucle d’Arrêt d’Urgence Double Canal',
      en: 'Dual-Channel Safety Relay E-Stop Discrepancy Fault',
    },
    system: {
      ar: 'نظام السلامة الصناعية والأتمتة لخط التعبئة والتغليف',
      fr: 'Système de Sécurité Machine et Ligne de Conditionnement',
      en: 'Packaging Machinery Dual-Channel Safety PLC Subsystem',
    },
    difficulty: 'Advanced',
    xpPoints: 190,
    initialReport: {
      ar: 'خط التعبئة متوقف كلياً عن العمل ومرحل الأمان الصناعي (Safety Relay K1) يومض بمؤشر خطأ عدم التزامن (Discrepancy Error)، والخط يرفض إعادة الضبط (Reset) رغم تحرير زر إيقاف الطوارئ المشروم.',
      fr: 'La ligne est verrouillée, le relais de sécurité K1 clignote en défaut de discordance entre canaux, réarmement impossible.',
      en: 'Packaging line is locked out; industrial safety relay K1 flashes a discrepancy fault code, refusing system reset despite releasing the mushroom head E-Stop button.',
    },
    symptoms: {
      visual: {
        ar: 'مصباح مرحل الأمان K1 للقناة Channel 1 مضيء، بينما مصباح Channel 2 مطفأ، ومصباح Fault يومض مرتين.',
        fr: 'LED Canal 1 allumée, Canal 2 éteinte sur le relais de sécurité PILZ/SICK.',
        en: 'Channel 1 LED lit green; Channel 2 LED dark; Safety Relay FAULT LED flashing 2 blinks (channel mismatch).',
      },
      auditory: {
        ar: 'صوت تكتكة متكررة عند الضغط على زر إعادة الضبط Reset دون التقاط الملامس.',
        fr: 'Clic de tentative de réarmement sans maintien.',
        en: 'Click-clack attempt sound when pressing blue Reset button without holding latch.',
      },
      thermal: {
        ar: 'جميع اللوحات في درجة حرارة الغرفة (24°C).',
        fr: 'Température normale.',
        en: 'Normal ambient operating temperature.',
      },
      vibration: {
        ar: 'لا يوجد.',
        fr: 'Néant.',
        en: 'Zero vibration.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'multimeter',
        testPoint: 'جهد القناة الأولى بمرحل الأمان (Terminal S11 - S12)',
        reading: '24.0 VDC (الدائرة الأولى مغلقة وموصلة سليمة)',
        normalRange: '24.0 VDC عند التحرير',
        unit: 'VDC',
      },
      {
        tool: 'multimeter',
        testPoint: 'جهد القناة الثانية بمرحل الأمان (Terminal S21 - S22)',
        reading: '0.0 VDC (الدائرة الثانية مفتوحة رغم تحرير الزر)',
        normalRange: '24.0 VDC عند التحرير',
        unit: 'VDC',
      },
      {
        tool: 'multimeter',
        testPoint: 'فحص ملامس الكتلة الثانية بزر الطوارئ (Contact Block NC 21-22)',
        reading: 'مقاومة لانهائية ∞ (الملامس الميكانيكي مكسور داخلياً ومرتخي)',
        normalRange: '< 0.5 Ω عند تحرير الزر',
        unit: 'Ω',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'كسر أو انفصال ميكانيكي في كتلة الملامس الثاني (NC Block 2) لزر الطوارئ مما سبب اختلافاً بين القناتين (Discrepancy)',
          fr: 'Casse mécanique du second bloc de contact NF du bouton coup de poing créant une discordance temporelle',
          en: 'Mechanical detachment/breakage of the second NC contact block on the E-stop mushroom switch causing channel discrepancy',
        },
        isCorrect: true,
        explanation: {
          ar: 'صحيح ممتاز! معايير السلامة ISO 13849-1 تتطلب قناتين متطابقتين؛ إذا فتحت قناة وظلت الأخرى مغلقة، فإن مرحل الأمان يدخل في وضع القفل (Lockout) لمنع تشغيل خطير.',
          fr: 'Exact ! Selon la norme ISO 13849-1 (Catégorie 4 / PLe), une discordance entre canaux bloque tout réarmement pour des raisons de sécurité.',
          en: 'Correct! Under ISO 13849-1 Cat 4 / PL e, safety relays detect contact welding and channel discrepancies; if one contact stays open while the other closes, it locks out.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'احتراق محرك خط التعبئة الرئيسي',
          fr: 'Grillage du moteur de convoyeur',
          en: 'Packaging conveyor drive motor burnout',
        },
        isCorrect: false,
        explanation: {
          ar: 'المحرك لم تصله الكهرباء أصلاً لأن دائرة الأمان ترفض تفعيل قاطع القدرة.',
          fr: 'Le moteur n’est même pas alimenté car la boucle de sécurité bloque l’enclenchement.',
          en: 'The motor never received power because the safety relay refused to energize the main safety contactors.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'تطبيق إجراء LOTO على لوحة التغذية والتحكم.',
        fr: 'Consigner la cellule de distribution.',
        en: 'Lockout/tagout the control power disconnect.',
      },
      {
        ar: 'فك غطاء زر إيقاف الطوارئ الميداني وفحص كتل الملامسات (Contact Blocks).',
        fr: 'Ouvrir le boîtier du bouton d’arrêt d’urgence et inspecter les blocs de contacts.',
        en: 'Unscrew E-Stop operator housing and inspect mechanical clips of contact blocks.',
      },
      {
        ar: 'استبدال كتلة الملامسات المزدوجة التالفة بكتلة معتمدة مع ميزة الفصل الإيجابي (Positive Break contacts).',
        fr: 'Remplacer le bloc par un élément certifié à ouverture positive obligatoire.',
        en: 'Replace the broken contact block with a certified positive-opening NC safety block.',
      },
      {
        ar: 'إعادة فحص استمرارية القناتين بالملتيميتر، ثم الضغط على زر Reset ومراقبة التقاط المرحل K1.',
        fr: 'Tester la continuité sur S12 et S22 puis réarmer.',
        en: 'Verify 0 Ω continuity simultaneously on both S11-S12 and S21-S22, then test Reset relay pickup.',
      },
    ],
    recommendedSolution: {
      ar: 'استبدال كتلة الملامسات بزر الطوارئ واختبار تزامن القناتين المزدوجتين، وتدوين الفحص الدوري لمعدات الأمان في سجل الصيانة الصناعية.',
      fr: 'Remplacement du bloc de contact et test de concordance des canaux de sécurité.',
      en: 'Install heavy-duty positive opening contact blocks, calibrate discrepancy monitoring timer, and validate under simulated safety proof test.',
    },
    safetyRule: {
      ar: 'ممنوع منعاً باتاً جسر (Bypass) أو إلغاء أي من قنوات مرحل الأمان تحت أي ظرف تجنباً للحوادث المميتة للمشغلين.',
      fr: 'Interdiction absolue de ponter ou contourner une boucle de sécurité industrielle.',
      en: 'Absolute safety mandate: NEVER bridge, jumper, or bypass safety relays or emergency stop channels under any operational pretext.',
    },
  },
  {
    id: 'oil_leakage_09',
    title: {
      ar: 'تسريب زيت هيدروليكي حاد من فلنجة الضغط العالي (High-Pressure Flange Oil Leakage)',
      fr: 'Fuite d’Huile Haute Pression sur Bride de Bloc Foré',
      en: 'High-Pressure Hydraulic Manifold Flange Oil Leakage',
    },
    system: {
      ar: 'وحدة التوليد الهيدروليكية المركزية HPU (280 bar)',
      fr: 'Centrale Hydraulique Principale HPU (280 bar)',
      en: 'Central Hydraulic Power Unit HPU (280 bar)',
    },
    difficulty: 'Intermediate',
    xpPoints: 175,
    initialReport: {
      ar: 'بركة زيت هيدروليكي كبيرة على أرضية الورشة أسفل بلوك الصمامات الرئيسي، مع انخفاض سريع في مؤشر منسوب الخزان، ورائحة رذاذ زيت مضغوط في الهواء.',
      fr: 'Flaque d’huile importante sous le bloc foré, baisse rapide du niveau de bâche et brouillard d’huile pulvérisée.',
      en: 'Large pool of hydraulic fluid pooling under the main manifold block with rapid reservoir drop and airborne atomized oil mist.',
    },
    symptoms: {
      visual: {
        ar: 'خروج رذاذ ناعم وتدفق زيت متواصل حول حافة الفلنجة الرابطة لصمام التنفيس النسبي.',
        fr: 'Jet d’huile continu et pulvérisation fine autour du plan de joint de bride.',
        en: 'Continuous oil dripping and fine micro-jet escaping around proportional relief valve flange joint.',
      },
      auditory: {
        ar: 'صوت هسهسة عالي النبرة يشبه خروج غاز مضغوط من شق دقيق.',
        fr: 'Sifflement aigu caractéristique d’un laminage sous 200 bar.',
        en: 'High-pitched piercing hiss caused by 200 bar fluid throttling through a damaged seal.',
      },
      thermal: {
        ar: 'حرارة الزيت في الخزان 42°C (طبيعية)، ولكن موضع التسريب ساخن موضعياً 68°C بسبب الاحتكاك النفاث.',
        fr: 'Point chaud à 68°C localisé sur la fuite par cisaillement visqueux.',
        en: 'Hotspot of 68°C localized at the leak orifice due to extreme viscous shear friction.',
      },
      vibration: {
        ar: 'اهتزاز عالي التردد ناتج عن الدوامات النفاثة.',
        fr: 'Vibration acoustique de jet.',
        en: 'Acoustic jet turbulence vibration.',
      },
    },
    virtualMeasurements: [
      {
        tool: 'pressure_gauge',
        testPoint: 'مقياس ضغط خط التغذية الرئيسي (Pressure Gauge HP-01)',
        reading: 'يهبط من 280 bar إلى 220 bar عند تفعيل الشوط',
        normalRange: '280 bar ثابت',
        unit: 'bar',
      },
      {
        tool: 'thermal_camera',
        testPoint: 'فحص حراري لوصلة الفلنجة المسربة',
        reading: 'نقطة ساخنة 68.5°C عند الحافة السفلية',
        normalRange: '< 45°C',
        unit: '°C',
      },
    ],
    possibleCauses: [
      {
        id: 'cause_1',
        text: {
          ar: 'تمزق حلقة الإحكام الدائرية O-Ring وبثقها (Extrusion) نتيجة فقدان حلقة الدعم الاحتياطية (Back-up Ring)',
          fr: 'Extrusion et cisaillement du joint torique O-Ring par absence de bague anti-extrusion',
          en: 'O-ring seal blow-out and extrusion due to missing or degraded PTFE anti-extrusion back-up ring',
        },
        isCorrect: true,
        explanation: {
          ar: 'صحيح تماماً! عند ضغط يفوق 200 bar، ينبثق المطاط الصناعي في خلوص الفلنجة ويتمزق ما لم تدعمه حلقة PTFE صلبة (Back-up ring).',
          fr: 'Exact ! Au-delà de 200 bar, le joint torique flue dans l’interstice et se détruit sans bague anti-extrusion.',
          en: 'Correct! Above 200 bar, high hydraulic impulse forces extrude nitrile rubber through flange clearances without a rigid back-up ring.',
        },
      },
      {
        id: 'cause_2',
        text: {
          ar: 'تلف شمعات الإشعال في المحرك',
          fr: 'Défaut de bougies d’allumage',
          en: 'Spark plug failure',
        },
        isCorrect: false,
        explanation: {
          ar: 'هذه وحدة هيدروليكية صناعية تعمل بمحرك كهربائي، ولا علاقة لها بنظام إشعال السيارات.',
          fr: 'Système hydraulique sans rapport avec un moteur thermique.',
          en: 'This is an industrial hydraulic HPU powered by an electric induction motor.',
        },
      },
    ],
    diagnosticSteps: [
      {
        ar: 'إيقاف فوري لمضخة الهيدروليك وتفريغ ضغط المجمع الهيدروليكي (Accumulator Bleed).',
        fr: 'Arrêt immédiat du groupe HPU et décharge de l’accumulateur.',
        en: 'Immediate emergency pump stop and hydraulic accumulator pressure bleed.',
      },
      {
        ar: 'تطبيق إجراء LOTO على القاطع الكهربائي وإغلاق محابس الخزان.',
        fr: 'Consignation LOTO de l’armoire de puissance.',
        en: 'Lockout/tagout the main HPU breaker and isolate tank suction ball valves.',
      },
      {
        ar: 'فك مسامير الفلنجة واستبدال طقم الـ O-Ring مع حلقة Back-up ring جديدة 90 Shore A.',
        fr: 'Dépose de la bride et remplacement du joint torique et bague anti-extrusion.',
        en: 'Unbolt flange, clean O-ring groove, and install 90 Shore A elastomer with backup ring.',
      },
    ],
    recommendedSolution: {
      ar: 'تركيب طقم حشوات مقاوم للضغط العالي (Viton 90 Shore A + PTFE Back-up Ring)، وشّد المسامير بالعزم الموصى به من المصنع.',
      fr: 'Remplacement par joint FKM/Viton 90 Shore A avec bague PTFE et serrage dynamométrique en croix.',
      en: 'Install 90 Shore A Viton O-ring with dual contoured PTFE anti-extrusion rings and torque bolts diagonally to specification.',
    },
    safetyRule: {
      ar: 'خطر الحقن تحت الجلد (Hydraulic Injection Injury): ممنوع لمس أو محاولة سد تسريب الزيت باليد؛ رذاذ الزيت عند 200 bar يخترق الجلد كالإبرة ويسبب تسمماً قاتلاً.',
      fr: 'Danger mortel d’injection sous-cutanée: Ne jamais inspecter une fuite d’huile haute pression à la main nue.',
      en: 'Fluid Injection Hazard: NEVER use hands or fingers to check for hydraulic leaks; high-pressure micro-jets penetrate skin instantaneously causing catastrophic tissue necrosis.',
    },
  },
];
