/**
 * NEXUS TOUNSI — ACADEMY DATA
 * 10 Comprehensive Educational Categories, Courses, Lessons & Practical Exercises
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import { AcademyCategory, AcademyCourse } from '../types';

export const ACADEMY_CATEGORIES: AcademyCategory[] = [
  {
    id: 'tech_edu',
    name: { ar: 'التعليم التقني والتكنولوجي', fr: 'Enseignement Technique', en: 'Technical Education' },
    icon: 'Cpu',
    courseCount: 4,
  },
  {
    id: 'vocational',
    name: { ar: 'التدريب والتأهيل المهني', fr: 'Formation Professionnelle', en: 'Vocational Training' },
    icon: 'Wrench',
    courseCount: 3,
  },
  {
    id: 'maintenance',
    name: { ar: 'الصيانة الصناعية وإدارة الأصول', fr: 'Maintenance Industrielle', en: 'Industrial Maintenance' },
    icon: 'ShieldCheck',
    courseCount: 4,
  },
  {
    id: 'engineering',
    name: { ar: 'العلوم الهندسية والكهرباء', fr: 'Sciences de l’Ingénieur', en: 'Engineering Sciences' },
    icon: 'Zap',
    courseCount: 5,
  },
  {
    id: 'math',
    name: { ar: 'الرياضيات التطبيقية للمهندسين', fr: 'Mathématiques Appliquées', en: 'Applied Mathematics' },
    icon: 'Sigma',
    courseCount: 3,
  },
  {
    id: 'physics',
    name: { ar: 'الفيزياء التطبيقية والميكانيكا', fr: 'Physique & Mécanique', en: 'Applied Physics & Mechanics' },
    icon: 'Atom',
    courseCount: 3,
  },
  {
    id: 'cs',
    name: { ar: 'علوم الحاسوب وهندسة البرمجيات', fr: 'Informatique & Algorithmes', en: 'Computer Science' },
    icon: 'Terminal',
    courseCount: 4,
  },
  {
    id: 'ai',
    name: { ar: 'الذكاء الاصطناعي والأنظمة الذكية', fr: 'Intelligence Artificielle', en: 'Artificial Intelligence' },
    icon: 'Bot',
    courseCount: 3,
  },
  {
    id: 'languages',
    name: { ar: 'المصطلحات الفنية واللغات المهنية', fr: 'Langues & Terminologie Technique', en: 'Technical Languages' },
    icon: 'Languages',
    courseCount: 3,
  },
  {
    id: 'general_science',
    name: { ar: 'العلوم العامة والسلامة الصناعية (HSE)', fr: 'Sciences Générales & Sécurité HSE', en: 'General Sciences & HSE' },
    icon: 'Flame',
    courseCount: 3,
  },
];

export const ACADEMY_COURSES: AcademyCourse[] = [
  // 1. Engineering Sciences
  {
    id: 'eng_201',
    categoryId: 'engineering',
    title: {
      ar: 'دوائر التحكم الآلي والقوى للمحركات الصناعية',
      fr: 'Circuits de Commande et Puissance pour Moteurs Triphasés',
      en: 'Motor Control & Industrial Power Circuits',
    },
    description: {
      ar: 'دورة شاملة في تصميم وقراءة مخططات القوى والتحكم، الإقلاع النجمي-المثلثي، مفاتيح التلامس وحسابات تيار القصر.',
      fr: 'Conception de schémas de puissance et commande, démarrage étoile-triangle et sélectivité thermique.',
      en: 'Complete guide to industrial power schematics, star-delta starting, contactor sizing, and circuit protection.',
    },
    level: 'Intermediate',
    durationHours: 12,
    xpReward: 220,
    lessons: [
      {
        id: 'eng_201_l1',
        courseId: 'eng_201',
        title: {
          ar: 'مخططات القوى ومفاتيح التلامس (Contactors)',
          fr: 'Schémas de Puissance et Contacteurs Industriels',
          en: 'Power Schematics & Industrial Contactors',
        },
        durationMin: 25,
        summary: {
          ar: 'فهم وظيفة ملامسات القوى والملامسات المساعدة NO و NC وملفات التحكم A1-A2.',
          fr: 'Rôle des pôles de puissance, contacts auxiliaires NO/NC et bobine d’excitation.',
          en: 'Understanding power poles, auxiliary NO/NC contacts, and electromagnetic coil terminals.',
        },
        sections: [
          {
            heading: {
              ar: 'مبدأ عمل مفتاح التلامس الكهرومغناطيسي',
              fr: 'Principe de Fonctionnement du Contacteur',
              en: 'Operating Principle of Electromagnetic Contactors',
            },
            body: {
              ar: 'يعمل الكونتاكتور عند تطبيق جهد كهربائي على طرفي الملف A1-A2، حيث يجذب القلب الحديدي المتحرك ليغلق الملامسات الرئيسية الثلاثة (1-2, 3-4, 5-6) مغذياً المحرك.',
              fr: 'Sous tension sur la bobine A1-A2, le champ magnétique attire l’armature mobile fermant simultanément les trois pôles de puissance.',
              en: 'Energizing coil terminals A1-A2 pulls the mobile iron armature, instantly closing the three primary power contacts to feed the motor.',
            },
            formulas: ['I_{nominal} = \\frac{P_{kW} \\times 1000}{\\sqrt{3} \\times V_L \\times \\cos\\phi \\times \\eta}'],
            keyRules: {
              ar: ['يجب اختيار الكونتاكتور وفق فئة الاستخدام AC-3 لمحركات الحث قفص السنجاب', 'احرص على تركيب غرف إطفاء القوس الكهربائي (Arc Chutes) لمنع تطاير الشرر'],
              fr: ['Sélection obligatoire en catégorie d’emploi AC-3 pour moteurs asynchrones', 'Vérification du verrouillage mécanique lors des inverseurs de sens'],
              en: ['Select AC-3 utilization category for squirrel-cage motors', 'Enforce mechanical interlocks on reversing starter assemblies'],
            },
          },
        ],
        practicalExercise: {
          ar: 'قم بفتح مختبر الدوائر 2D وشبك دائرة إقلاع مباشر DOL مع زر Stop NC وزر Start NO ولمبة بيان خضراء.',
          fr: 'Ouvrez le simulateur 2D et câblez un départ moteur DOL complet avec voyant marche.',
          en: 'Launch the 2D Circuit Studio and wire a complete DOL motor starter circuit with status lamp.',
        },
        quizQuestion: {
          id: 'aq_eng_201_l1',
          labId: 'electrical',
          question: {
            ar: 'أي فئة استخدام قياسية يجب اختيارها عند تحديد الكونتاكتور لمحرك حث ثلاثي الأطوار قفص السنجاب؟',
            fr: 'Quelle catégorie d’emploi normalisée faut-il choisir pour un contacteur commandant un moteur asynchrone à cage ?',
            en: 'Which IEC utilization category applies to a contactor switching a squirrel-cage 3-phase induction motor?',
          },
          options: {
            ar: ['AC-3 (فصل وتشغيل محركات قفص السنجاب)', 'AC-1 (أحمال مقاومة غير حثية)', 'DC-13 (ملفات التيار المستمر)', 'AC-15 (دوائر التحكم فقط)'],
            fr: ['AC-3 (moteurs asynchrones à cage)', 'AC-1 (charges purement résistives)', 'DC-13 (électroaimants DC)', 'AC-15 (circuits de commande)'],
            en: ['AC-3 (squirrel-cage motor starting and running cutoff)', 'AC-1 (non-inductive resistive loads)', 'DC-13 (DC electromagnets)', 'AC-15 (control circuits only)'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'الفئة AC-3 مخصصة لإغلاق تيار الإقلاع العالي وفصل المحرك أثناء الدوران، أما AC-1 فللأحمال المقاومة كالسخانات.',
            fr: 'La catégorie AC-3 est conçue pour le démarrage des moteurs à cage et leur coupure en rotation.',
            en: 'AC-3 is engineered for closing high motor starting currents and breaking normal running current.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 2. Industrial Maintenance
  {
    id: 'maint_301',
    categoryId: 'maintenance',
    title: {
      ar: 'الصيانة التنبؤية واهتزازات المعدات الدوارة (ISO 10816)',
      fr: 'Maintenance Prédictive et Analyse Vibratoire ISO 10816',
      en: 'Predictive Maintenance & Vibration Analysis (ISO 10816)',
    },
    description: {
      ar: 'استراتيجيات الصيانة المعتمدة على الحالة CBM، قياس سرعة الاهتزاز RMS، واكتشاف عدم الاتزان وعدم المحاذاة.',
      fr: 'Surveillance d’état vibratoire, seuils d’alarme ISO 10816 et détection précoce des balourds et lignages.',
      en: 'Condition-Based Maintenance (CBM), overall vibration velocity RMS, and early identification of unbalance and misalignment.',
    },
    level: 'Advanced',
    durationHours: 16,
    xpReward: 260,
    lessons: [
      {
        id: 'maint_301_l1',
        courseId: 'maint_301',
        title: {
          ar: 'معايير تقييم شدة الاهتزاز ISO 10816-3',
          fr: 'Norme de Sévérité Vibratoire ISO 10816-3',
          en: 'ISO 10816-3 Vibration Severity Classification',
        },
        durationMin: 30,
        summary: {
          ar: 'تصنيف الآلات الصناعية إلى أربع فئات حرجة بناءً على سرعة الاهتزاز الفعالة (mm/s RMS).',
          fr: 'Classification des machines industrielles et zones A (bon), B (acceptable), C (alerte) et D (danger).',
          en: 'Machine classification into zones A (good), B (allowable), C (just tolerable), and D (dangerous).',
        },
        sections: [
          {
            heading: {
              ar: 'المناطق الأربعة لتقييم الاهتزاز',
              fr: 'Les 4 Zones d’Évaluation ISO',
              en: 'The 4 ISO Evaluation Zones',
            },
            body: {
              ar: 'المنطقة الخضراء A تدل على معدة جديدة ممتازة (< 1.4 mm/s)، والمنطقة B صالحة للتشغيل طويل الأمد (< 2.8 mm/s)، والمنطقة C تتطلب صيانة قريبة (< 4.5 mm/s)، والمنطقة D خطر داهم يسبب الانهيار الفوري (> 4.5 mm/s للآلات المتوسطة).',
              fr: 'Zone A: machine neuve; Zone B: fonctionnement sans restriction; Zone C: intervention planifiée; Zone D: arrêt immédiat.',
              en: 'Zone A: newly commissioned equipment; Zone B: unlimited long-term operation; Zone C: planned corrective action; Zone D: severe damage imminent.',
            },
            formulas: ['V_{RMS} = \\sqrt{\\frac{1}{T}\\int_0^T v(t)^2 dt}'],
          },
        ],
        practicalExercise: {
          ar: 'انتقل لمركز تشخيص الأعطال وابدأ سيناريو تلف كراسي التحميل Bearing Failure واستخدم قلم قياس الاهتزاز للتحقق من منطقة الخطورة.',
          fr: 'Accédez au centre de diagnostic et examinez le cas de roulement avec le capteur vibratoire.',
          en: 'Go to the Fault Diagnosis Center, open the Bearing Failure scenario, and use the vibration probe.',
        },
        quizQuestion: {
          id: 'aq_maint_301_l1',
          labId: 'maintenance',
          question: {
            ar: 'عند قياس سرعة الاهتزاز لمحرك متوسط وبلوغها المنطقة D في معيار ISO 10816، ما الإجراء الواجب؟',
            fr: 'Lorsqu’une mesure vibratoire atteint la Zone D de la norme ISO 10816, quelle action s’impose ?',
            en: 'When vibration velocity on an industrial motor enters ISO 10816 Zone D, what is the required action?',
          },
          options: {
            ar: ['إيقاف المعدة فوراً وفحصها لأن الضرر الميكانيكي وشيك', 'تجاهل القراءة حتى الصيانة السنوية', 'زيادة سرعة الدوران لتجاوز الرنين فقط', 'تقليل جهد التغذية للنصف'],
            fr: ['Arrêt immédiat et inspection car un dommage sévère est imminent', 'Attendre la révision annuelle', 'Augmenter la vitesse nominale', 'Réduire la tension réseau de moitié'],
            en: ['Immediate shutdown and inspection as severe mechanical damage is imminent', 'Ignore until annual overhaul', 'Increase nominal RPM', 'Halve supply voltage'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'المنطقة D تعني شدة اهتزاز حرجة قد تدمر كراسي التحميل أو العمود فوراً وتتطلب الإيقاف الآمن.',
            fr: 'La Zone D indique un niveau vibratoire critique capable d’endommager la machine rapidement.',
            en: 'Zone D designates unacceptable vibration severity capable of causing immediate structural or bearing failure.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 3. Applied Mathematics
  {
    id: 'math_101',
    categoryId: 'math',
    title: {
      ar: 'الجبر الخطي وحساب التفاضل والتكامل للمهندسين',
      fr: 'Algèbre Linéaire et Calcul Différentiel pour Ingénieurs',
      en: 'Linear Algebra & Calculus for Engineering Systems',
    },
    description: {
      ar: 'المتجهات والمصفوفات، المعادلات التفاضلية للأنظمة الديناميكية، وتحويلات فورييه لتحليل الإشارات الصناعية.',
      fr: 'Vecteurs, matrices d’état, équations différentielles et transformée de Fourier appliquée.',
      en: 'Vectors, state-space matrices, differential equations for dynamic systems, and Fourier transforms.',
    },
    level: 'Intermediate',
    durationHours: 14,
    xpReward: 200,
    lessons: [
      {
        id: 'math_101_l1',
        courseId: 'math_101',
        title: {
          ar: 'المعادلات التفاضلية للأنظمة الميكانيكية الرنانة',
          fr: 'Équations Différentielles des Systèmes Masse-Ressort-Amortisseur',
          en: 'Mass-Spring-Damper Second-Order Systems',
        },
        durationMin: 35,
        summary: {
          ar: 'نمذجة الحركة الاهتزازية والتخميد اللزج والتردد الطبيعي للآلات الصناعية.',
          fr: 'Modélisation des oscillations mécaniques amorties et pulsation propre.',
          en: 'Modeling damped mechanical oscillations and resonance natural frequency.',
        },
        sections: [
          {
            heading: {
              ar: 'معادلة الحركة الرنانة',
              fr: 'Équation du Mouvement',
              en: 'Equation of Motion',
            },
            body: {
              ar: 'تخضع الآلات الدوارة لمعادلة نيوتن الحركية: القوة الكلية تساوي مجموع قوة القصور الذاتي وقوة التخميد وقوة المرونة.',
              fr: 'Loi fondamentale de la dynamique appliquée aux corps vibrants en rotation.',
              en: 'Newtonian motion equation balancing inertial, viscous damping, and elastic restoring forces.',
            },
            formulas: ['m \\ddot{x} + c \\dot{x} + k x = F(t)', '\\omega_n = \\sqrt{\\frac{k}{m}}'],
          },
        ],
        quizQuestion: {
          id: 'aq_math_101_l1',
          labId: 'mechanical',
          question: {
            ar: 'ماذا يحدث للتردد الطبيعي للنظام الرنان ωn = √(k/m) عند مضاعفة صلابة النابض k أربع مرات مع ثبات الكتلة m؟',
            fr: 'Que devient la pulsation propre ωn = √(k/m) si la raideur k est multipliée par 4 à masse constante ?',
            en: 'What happens to natural frequency ωn = √(k/m) if stiffness k is quadrupled at constant mass m?',
          },
          options: {
            ar: ['يتضاعف التردد الطبيعي (×2)', 'ينخفض التردد للنصف (÷2)', 'يتضاعف أربع مرات (×4)', 'يبقى ثابتاً'],
            fr: ['Elle est multipliée par 2', 'Elle est divisée par 2', 'Elle est multipliée par 4', 'Elle reste constante'],
            en: ['Natural frequency doubles (×2)', 'Natural frequency halves (÷2)', 'Quadruples (×4)', 'Remains unchanged'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'بما أن ωn يتناسب طردياً مع الجذر التربيعي لـ k، فإن √4 = 2، أي يتضاعف التردد الطبيعي مرتين.',
            fr: 'Comme ωn dépend de √k, √4 = 2 donc la fréquence naturelle double.',
            en: 'Since ωn scales with √k, √4 = 2, doubling the system natural frequency.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 4. Artificial Intelligence
  {
    id: 'ai_401',
    categoryId: 'ai',
    title: {
      ar: 'الذكاء الاصطناعي في الصيانة التنبؤية والأنظمة الذكية',
      fr: 'IA et Machine Learning pour la Maintenance Prédictive',
      en: 'AI & Machine Learning for Industrial Maintenance',
    },
    description: {
      ar: 'اكتشاف الشذوذ Anomaly Detection، التنبؤ بالعمر المتبقي RUL، وتطبيق خوارزميات التعلم الآلي على بيانات الحساسات الصناعية.',
      fr: 'Détection d’anomalies temporelles, prédiction de durée de vie résiduelle (RUL) et modèles de classification.',
      en: 'Time-series anomaly detection, Remaining Useful Life (RUL) prediction, and supervised learning on sensor telemetry.',
    },
    level: 'Advanced',
    durationHours: 18,
    xpReward: 280,
    lessons: [
      {
        id: 'ai_401_l1',
        courseId: 'ai_401',
        title: {
          ar: 'خوارزميات التنبؤ بالعمر المتبقي (Remaining Useful Life - RUL)',
          fr: 'Estimation du Temps Avant Défaillance (RUL)',
          en: 'Remaining Useful Life (RUL) Prognostics',
        },
        durationMin: 40,
        summary: {
          ar: 'كيف تستخدم الشبكات العصبية لتحليل التدهور التدريجي للمعدات قبل حدوث التوقف الكارثي.',
          fr: 'Utilisation des réseaux récurrents pour tracer la courbe de dégradation thermique et mécanique.',
          en: 'Deploying neural regression models to track progressive component wear before catastrophic stoppage.',
        },
        sections: [
          {
            heading: {
              ar: 'منحنى التدهور الفعلي P-F Interval',
              fr: 'Intervalle P-F de Dégradation',
              en: 'The P-F Degradation Interval',
            },
            body: {
              ar: 'الفاصل الزمني P-F يمثل الوقت المتبقي بين رصد العطل المحتمل (Potential Failure) والانهيار الوظيفي الكامل (Functional Failure). الذكاء الاصطناعي يوسع هذا الفاصل لمنح فرق الصيانة متسعاً للتصرف.',
              fr: 'L’intervalle P-F mesure le délai entre la détection précoce et l’arrêt fonctionnel.',
              en: 'The P-F curve maps the crucial window between early symptom detection and functional shutdown.',
            },
            formulas: ['RUL(t) = T_{failure} - t'],
          },
        ],
        quizQuestion: {
          id: 'aq_ai_401_l1',
          labId: 'maintenance',
          question: {
            ar: 'ما هو الهدف الأساسي من حساب الفاصل الزمني P-F في الصيانة التنبؤية المدعومة بالذكاء الاصطناعي؟',
            fr: 'Quel est l’objectif principal de l’intervalle P-F en maintenance prédictive assistée par IA ?',
            en: 'What is the main operational purpose of the P-F interval in AI-assisted predictive maintenance?',
          },
          options: {
            ar: ['اكتشاف العطل المحتمل P مبكراً بما يكفي للتدخل قبل الانهيار الوظيفي F', 'زيادة سرعة الإنتاج فقط', 'إلغاء جميع الحساسات من المصنع', 'قياس الجهد الكهربائي'],
            fr: ['Détecter la défaillance potentielle P assez tôt pour intervenir avant la panne F', 'Supprimer les capteurs industriels', 'Augmenter la tension moteur', 'Remplacer la lubrification'],
            en: ['Detect potential failure P early enough to intervene before functional failure F', 'Remove factory sensors', 'Boost motor voltage', 'Skip lubrication intervals'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'كلما اكتشفنا نقطة P مبكراً عبر الاهتزازات أو الموجات فوق الصوتية، توفر وقت أطول لتنفيذ الصيانة دون توقف مفاجئ.',
            fr: 'Plus le point P est détecté tôt, plus la marge d’intervention planifiée avant la panne totale F est grande.',
            en: 'Earlier P detection yields a wider maintenance planning window before catastrophic functional failure F.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 5. Applied Physics & Mechanics
  {
    id: 'phys_201',
    categoryId: 'physics',
    title: {
      ar: 'ديناميكا الموائع والديناميكا الحرارية الصناعية',
      fr: 'Mécanique des Fluides et Thermodynamique Industrielle',
      en: 'Industrial Fluid Dynamics & Thermodynamics',
    },
    description: {
      ar: 'معادلة برنولي، خسائر الاحتكاك في الأنابيب، دورات رانكين، وقوانين باسكال في المنظومات الهيدروليكية.',
      fr: 'Équation de Bernoulli, pertes de charge régulières et singulières, et cycles thermiques.',
      en: 'Bernoulli principle, Moody friction factor, thermodynamic cycles, and fluid transport networks.',
    },
    level: 'Intermediate',
    durationHours: 15,
    xpReward: 240,
    lessons: [
      {
        id: 'phys_201_l1',
        courseId: 'phys_201',
        title: {
          ar: 'ظاهرة التكهف ورأس السحب الإيجابي الصافي (NPSH)',
          fr: 'Phénomène de Cavitation et Calcul du NPSH',
          en: 'Cavitation Physics & Net Positive Suction Head (NPSH)',
        },
        durationMin: 30,
        summary: {
          ar: 'الفيزياء الكامنة وراء تكون فقاعات البخار عند انخفاض الضغط الموضعي دون ضغط البخار المشبع.',
          fr: 'Mécanisme d’implosion des bulles de vapeur et impact sur les aubes de pompe.',
          en: 'Thermodynamics of vapor bubble formation and micro-jet implosion against pump blades.',
        },
        sections: [
          {
            heading: {
              ar: 'شرط تجنب التكهف الصارم',
              fr: 'Condition de Non-Cavitation',
              en: 'Non-Cavitation Safety Margin Criterion',
            },
            body: {
              ar: 'لمنع التكهف يجب أن يكون رأس السحب المتوفر NPSHa أكبر من رأس السحب المطلوب NPSHr بهامش أمان لا يقل عن 0.6 إلى 1.0 متر.',
              fr: 'NPSH disponible doit strictement excéder le NPSH requis fourni par le fabricant.',
              en: 'Available NPSH (NPSHa) must exceed manufacturer required NPSH (NPSHr) by at least 0.6m to 1.0m safety head.',
            },
            formulas: ['NPSH_a = \\frac{P_{suction} - P_{vapor}}{\\rho \\cdot g} + \\frac{v^2}{2g} \\ge NPSH_r + \\Delta H_{margin}'],
          },
        ],
        quizQuestion: {
          id: 'aq_phys_201_l1',
          labId: 'thermal',
          question: {
            ar: 'ما الشرط الفيزيائي الأساسي لمنع حدوث التكهف (Cavitation) في مضخة الطرد المركزي؟',
            fr: 'Quelle condition physique garantit l’absence de cavitation sur une pompe centrifuge ?',
            en: 'Which hydraulic condition prevents cavitation inside a centrifugal pump?',
          },
          options: {
            ar: ['أن يكون NPSHa أكبر من NPSHr مع هامش أمان', 'أن يكون NPSHa أصغر من NPSHr', 'إغلاق صمام السحب كلياً', 'رفع حرارة السائل لنقطة الغليان'],
            fr: ['NPSH disponible supérieur au NPSH requis avec marge', 'NPSHa inférieur au NPSHr', 'Fermer la vanne d’aspiration', 'Porter le fluide à ébullition'],
            en: ['NPSHa strictly greater than NPSHr with safety margin', 'NPSHa less than NPSHr', 'Close suction isolation valve', 'Heat fluid past boiling point'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'إذا انخفض NPSHa عن NPSHr يتبخر السائل عند عين المروحة وتنهار الفقاعات مسببة نقراً معدنياً وصوت حصى.',
            fr: 'Si NPSHa descend sous NPSHr, le fluide se vaporise à l’entrée de la roue et provoque une érosion rapide.',
            en: 'When NPSHa falls below NPSHr, localized pressure drops below vapor pressure causing damaging implosion.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 6. Technical Education (tech_edu)
  {
    id: 'tech_101',
    categoryId: 'tech_edu',
    title: {
      ar: 'أساسيات الأنظمة التقنية والحساسات الصناعية الذكية',
      fr: 'Systèmes Techniques & Capteurs Industriels',
      en: 'Foundations of Technical Systems & Smart Sensors',
    },
    description: {
      ar: 'مقدمة مبسطة وسريعة الفهم للحساسات التقاربية، المفاتيح الحدية، التغذية المستمرة 24V DC، وقراءة اللوحات الاسمية.',
      fr: 'Introduction claire aux capteurs inductifs, optiques, alimentations 24V DC et plaques signalétiques.',
      en: 'Beginner-friendly mastery of inductive/capacitive proximity sensors, 24V DC supplies, and motor nameplates.',
    },
    level: 'Beginner',
    durationHours: 10,
    xpReward: 180,
    lessons: [
      {
        id: 'tech_101_l1',
        courseId: 'tech_101',
        title: {
          ar: 'الفرق بين حساس NPN وحساس PNP وتوصيلهما مع 24V DC',
          fr: 'Capteurs NPN vs PNP et Câblage 24V DC',
          en: 'NPN vs PNP Proximity Sensors & 24V DC Wiring',
        },
        durationMin: 20,
        summary: {
          ar: 'قاعدة سريعة لا تُنسى للتمييز بين PNP (المصدر الموجب) وNPN (المصرف السالب) في خطوط الإنتاج.',
          fr: 'Astuce mnémotechnique simple pour différencier PNP (sortie +) et NPN (sortie -) sur site.',
          en: 'Simple memory trick to distinguish PNP (sourcing +24V) and NPN (sinking 0V) industrial sensors.',
        },
        sections: [
          {
            heading: {
              ar: 'قاعدة التذكّر السريع (P = Positive)',
              fr: 'Règle Mémo Rapide (P = Positif)',
              en: 'Quick Memory Rule (P = Positive Sourcing)',
            },
            body: {
              ar: 'في حساس PNP يبدأ الحرف بـ P أي Positive، لذلك يخرج من السلك الأسود إشارة موجبة (+24V) عند استشعار القطعة المعدنية. أما NPN فيخرج منه إشارة سالبة (0V). السلك البني دائماً +24V والأزرق 0V وفق معيار IEC.',
              fr: 'PNP commence par P comme Positif (+24V sur le fil noir). NPN fournit le 0V. Marron = +24V, Bleu = 0V selon IEC.',
              en: 'PNP starts with P (Positive): the black signal wire outputs +24V when triggered. NPN sinks 0V. Brown is +24V and Blue is 0V per IEC.',
            },
            formulas: ['I_{load} = \\frac{24V}{R_{input}} \\le 200\\text{ mA}'],
            keyRules: {
              ar: ['تأكد دائماً من توافق نوع بطاقة الـ PLC (Sink أو Source) قبل توصيل الحساس', 'ألوان الأسلاك القياسية: البني (+24V)، الأزرق (0V)، الأسود (إشارة الخرج)'],
              fr: ['Vérifier la compatibilité entrée API (Sink/Source)', 'Couleurs normalisées: Marron (+24V), Bleu (0V), Noir (Signal)'],
              en: ['Match PLC input card type (Sink vs Source) before wiring', 'Standard IEC colors: Brown (+24V), Blue (0V), Black (Output Signal)'],
            },
          },
        ],
        practicalExercise: {
          ar: 'افتح محاكي PLC ولاحظ كيف تتفاعل المداخل الرقمية 24V DC مع منطق السلم Ladder Logic.',
          fr: 'Ouvrez le simulateur API (PLC) et testez les entrées numériques 24V DC.',
          en: 'Open the PLC Studio simulator and observe how 24V DC digital inputs drive Ladder rungs.',
        },
        quizQuestion: {
          id: 'aq_tech_101_l1',
          labId: 'plc',
          question: {
            ar: 'وفق المعيار الصناعي IEC لحساس تقاربي ذو 3 أسلاك من نوع PNP، ماذا يخرج على السلك الأسود عند تفعيله؟',
            fr: 'Selon la norme IEC pour un capteur 3 fils PNP, quel signal sort sur le fil noir lors de la détection ?',
            en: 'In an IEC 3-wire PNP proximity sensor, what signal appears on the black wire when activated?',
          },
          options: {
            ar: ['إشارة موجبة +24V DC (PNP = Positive)', 'إشارة سالبة 0V دائماً', 'تيار متردد 400V', 'اتصال أرضي PE'],
            fr: ['Signal positif +24V DC', 'Signal 0V uniquement', 'Tension 400V AC', 'Mise à la terre PE'],
            en: ['Positive +24V DC signal (PNP = Positive)', 'Negative 0V signal', '400V AC phase', 'Protective earth PE'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'حساس PNP يقوم بتوصيل الموجب +24V (السلك البني) إلى سلك الخرج الأسود لحظة الاكتشاف.',
            fr: 'Un capteur PNP commute le +24V (fil marron) vers la sortie noire lors de la détection.',
            en: 'A PNP sensor switches the +24V supply internally onto the black output wire upon target detection.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 7. Vocational Training (vocational)
  {
    id: 'voc_101',
    categoryId: 'vocational',
    title: {
      ar: 'التأهيل المهني: استخدام الملتيمتر، قياس العزل، وإجراءات LOTO',
      fr: 'Formation Pratique: Multimètre, Mégohmmètre & Consignation LOTO',
      en: 'Vocational Mastery: Multimeter, Insulation & LOTO Safety',
    },
    description: {
      ar: 'مهارات الورشة اليومية الأساسية للفنيين الميدانيين: قياس التوصيلية، فحص عزل المحركات، والعزل الآمن للطاقة.',
      fr: 'Compétences terrain essentielles: test de continuité, mesure d’isolement et consignation électrique LOTO.',
      en: 'Essential field workshop skills: continuity testing, motor winding insulation checks, and Lockout-Tagout.',
    },
    level: 'Beginner',
    durationHours: 8,
    xpReward: 170,
    lessons: [
      {
        id: 'voc_101_l1',
        courseId: 'voc_101',
        title: {
          ar: 'الاستخدام الآمن لجهاز القياس المتعدد (CAT III / CAT IV)',
          fr: 'Utilisation Sécurisée du Multimètre (CAT III / CAT IV)',
          en: 'Safe Industrial Multimeter Operation (CAT III / CAT IV)',
        },
        durationMin: 25,
        summary: {
          ar: 'كيف تقيس الجهد والتيار والمقاومة دون حرق فيوز الجهاز أو التسبب في قوس كهربائي داخل اللوحة.',
          fr: 'Mesurer tension, courant et résistance sans endommager l’appareil ni provoquer d’arc électrique.',
          en: 'Measuring voltage, resistance, and continuity safely inside live industrial panels.',
        },
        sections: [
          {
            heading: {
              ar: 'خطوات القياس الخمس (فحص – تحقق – قِس)',
              fr: 'Procédure de Test en 3 Étapes (Live-Dead-Live)',
              en: 'Three-Step Live-Dead-Live Verification',
            },
            body: {
              ar: 'لا تقس المقاومة (Ω) أو الجرس (Continuity) أبداً على دائرة مغذاة بالكهرباء! اتبع قاعدة Live-Dead-Live: اختبر الملتيمتر على مصدر معلوم، ثم تحقق من غياب الجهد (VAT = 0V)، ثم أعد اختبار الجهاز للتأكد من سلامة بطاريته وفيوزاته.',
              fr: 'Ne jamais mesurer une résistance sur un circuit sous tension. Appliquez la vérification d’absence de tension (VAT) avant et après test.',
              en: 'Never measure resistance or continuity on an energized circuit. Always perform Live-Dead-Live voltage absence testing.',
            },
            keyRules: {
              ar: ['استخدم ملتيمتر بتصنيف CAT III 600V على الأقل للوحات التوزيع الصناعية', 'افصل التغذية وأقفل القاطع بالقفل الشخصي (LOTO) قبل لمس الموصلات'],
              fr: ['Multimètre CAT III 600V minimum exigé en armoire industrielle', 'Consignation LOTO obligatoire avant toute mesure ohmmétrique'],
              en: ['Minimum CAT III 600V meter rating required for industrial panels', 'Lockout-Tagout mandatory before resistance or continuity probing'],
            },
          },
        ],
        practicalExercise: {
          ar: 'شغّل مختبر الدوائر 2D وفعّل وضع Multimeter لقياس الجهد على أطراف المحرك قبل وبعد الضغط على Start.',
          fr: 'Activez le multimètre virtuel dans le Studio 2D pour relever les tensions aux bornes moteur.',
          en: 'Open the 2D Circuit Studio and toggle Digital Multimeter Probe mode on motor terminals.',
        },
        quizQuestion: {
          id: 'aq_voc_101_l1',
          labId: 'electronics',
          question: {
            ar: 'ما هو الفحص الإلزامي الذي يجب إجراؤه قبل وضع محدد الملتيمتر على وضع قياس المقاومة (Ω) داخل لوحة صناعية؟',
            fr: 'Quelle vérification est obligatoire avant de placer le multimètre en mode ohmmètre (Ω) dans une armoire ?',
            en: 'Which verification is mandatory before setting a multimeter to Resistance (Ω) inside a control cabinet?',
          },
          options: {
            ar: ['التأكد من قطع الطاقة والتحقق من غياب الجهد (0V)', 'رفع جهد المصدر إلى 400V', 'تغيير الكابل إلى اللون الأحمر', 'تشغيل المحرك على السرعة القصوى'],
            fr: ['Vérifier la consignation et l’absence de tension (0V)', 'Monter à 400V', 'Changer la couleur des pointes', 'Démarrer le moteur'],
            en: ['Verify isolation and Absence of Voltage (0V)', 'Increase supply to 400V', 'Swap red probe', 'Start motor at full speed'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'قياس المقاومة على خط يحمل جهداً كهربائياً قد يتلف الجهاز ويعرض الفني لخطر الصعق والقوس الكهربائي.',
            fr: 'Mesurer une résistance sous tension détruit l’instrument et crée un risque d’arc électrique grave.',
            en: 'Testing resistance on a live line blows internal protection fuses and creates an arc-flash hazard.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 8. Computer Science & Automation Scripting (cs)
  {
    id: 'cs_201',
    categoryId: 'cs',
    title: {
      ar: 'أساسيات البرمجة الصناعية وبروتوكولات الشبكات (Modbus / JSON)',
      fr: 'Algorithmique Industrielle & Protocoles Réseaux (Modbus / JSON)',
      en: 'Industrial Computing, Binary Logic & Modbus/SCADA',
    },
    description: {
      ar: 'منطق البوابات الرقمية AND/OR/XOR، أنظمة العد الثنائي والست عشري، وتبادل بيانات الحساسات عبر Modbus TCP.',
      fr: 'Logique booléenne, binaire/hexadécimal et communication automates Modbus TCP / SCADA.',
      en: 'Boolean logic gates, binary/hex numbering systems, and PLC-to-SCADA telemetry via Modbus.',
    },
    level: 'Intermediate',
    durationHours: 12,
    xpReward: 210,
    lessons: [
      {
        id: 'cs_201_l1',
        courseId: 'cs_201',
        title: {
          ar: 'البت والبايت والمنطق البولياني في الأتمتة و SCADA',
          fr: 'Bits, Octets et Algèbre de Boole en Automatisme',
          en: 'Bits, Bytes & Boolean Logic in Automation Software',
        },
        durationMin: 30,
        summary: {
          ar: 'كيف تتحول حالات الحساسات 0 و 1 إلى كلمات تحكم رقمية 16-bit تُقرأ عبر شاشات SCADA.',
          fr: 'Conversion des états TOR (0/1) en mots 16 bits exploités par les systèmes SCADA.',
          en: 'How discrete sensor states map into 16-bit holding registers monitored by SCADA dashboards.',
        },
        sections: [
          {
            heading: {
              ar: 'بوابات المنطق الأساسية (AND / OR / NOT)',
              fr: 'Portes Logiques Fondamentales (ET / OU / NON)',
              en: 'Core Boolean Gates (AND / OR / NOT)',
            },
            body: {
              ar: 'في برمجة السلم والأنظمة الرقمية، التوصيل على التوالي يمثل بوابة AND (يجب تحقق الشرطين معاً)، بينما التوصيل على التوازي يمثل بوابة OR (يكفي تحقق شرط واحد). القيم في سجلات Modbus تُخزن كـ Word من 16 بت (من 0 إلى 65535).',
              fr: 'En logique câblée ou Ladder, la mise en série équivaut au ET logique (AND) et la mise en parallèle au OU logique (OR).',
              en: 'In control code, series contacts implement Boolean AND while parallel branches implement Boolean OR. Standard Modbus registers hold 16-bit unsigned words (0–65535).',
            },
            formulas: ['2^{16} = 65536 \\text{ états possibles}', 'Y = A \\cdot B + \\overline{C}'],
          },
        ],
        quizQuestion: {
          id: 'aq_cs_201_l1',
          labId: 'plc',
          question: {
            ar: 'ما البوابة المنطقية التي يمثلها توصيل ملامسين مفتوحين طبيعياً (NO) على التوالي في سطر برمجة PLC؟',
            fr: 'Quelle porte logique correspond à deux contacts normalement ouverts (NO) câblés en série dans un réseau Ladder ?',
            en: 'Which Boolean logic gate is represented by two Normally Open (NO) contacts wired in series on a PLC rung?',
          },
          options: {
            ar: ['بوابة AND (و)', 'بوابة OR (أو)', 'بوابة XOR (أو الحصرية)', 'بوابة NOT (نفي)'],
            fr: ['Porte ET (AND)', 'Porte OU (OR)', 'Porte OU exclusif (XOR)', 'Porte NON (NOT)'],
            en: ['AND gate', 'OR gate', 'XOR gate', 'NOT inverter'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'التوالي يتطلب إغلاق الملامس الأول والثاني معاً لمرور الإشارة، وهذا هو تعريف بوابة AND.',
            fr: 'En série, les deux conditions doivent être vraies simultanément pour activer la bobine: fonction ET (AND).',
            en: 'Series wiring requires both contacts closed simultaneously to energize the coil — Boolean AND.',
          },
          xpReward: 30,
        },
      },
    ],
  },

  // 9. Technical Languages & Terminology (languages)
  {
    id: 'lang_101',
    categoryId: 'languages',
    title: {
      ar: 'قاموس المصطلحات الهندسية ثلاثي اللغات (عربي / فرنسي / إنجليزي)',
      fr: 'Terminologie Technique Trilingue (AR / FR / EN)',
      en: 'Trilingual Industrial & Engineering Glossary (AR / FR / EN)',
    },
    description: {
      ar: 'حفظ سريع لأهم 50 مصطلحاً ميدانياً تُستخدم في المخططات الكهربائية والكتالوجات الألمانية والفرنسية والمصانع التونسية والعربية.',
      fr: 'Maîtrise rapide des termes industriels clés sur schémas électriques, fiches techniques et maintenance.',
      en: 'Rapid memorization of core field terms across electrical schematics, maintenance sheets, and multilingual manuals.',
    },
    level: 'Beginner',
    durationHours: 6,
    xpReward: 150,
    lessons: [
      {
        id: 'lang_101_l1',
        courseId: 'lang_101',
        title: {
          ar: 'مصطلحات اللوحات الكهربائية والمحركات في الورشات',
          fr: 'Lexique Terrain des Armoires Électriques et Moteurs',
          en: 'Field Terminology for Switchgear & Motors',
        },
        durationMin: 20,
        summary: {
          ar: 'ربط فوري بين الكلمة العربية والفرنسية والإنجليزية: Disjoncteur / Circuit Breaker، Contacteur / Contactor، Roulement / Bearing.',
          fr: 'Correspondance instantanée AR / FR / EN : Disjoncteur, Contacteur, Relais Thermique et Roulement.',
          en: 'Instant AR/FR/EN mapping for field technicians: Breakers, Contactors, Thermal Relays, and Bearings.',
        },
        sections: [
          {
            heading: {
              ar: 'جدول المرادفات الهندسية الأكثر استخداماً',
              fr: 'Correspondances Clés en Atelier',
              en: 'Essential Multilingual Field Pairs',
            },
            body: {
              ar: 'قاطع الدائرة = Disjoncteur = Circuit Breaker | مفتاح التلامس = Contacteur = Contactor | المرحل الحراري = Relais Thermique = Thermal Overload | كرسي التحميل (رولمان) = Roulement = Bearing | مانع التسرب = Garniture Mécanique = Mechanical Seal.',
              fr: 'Disjoncteur = Circuit Breaker = قاطع الدائرة | Roulement = Bearing = كرسي التحميل | Garniture mécanique = Mechanical Seal = حشوة مانعة للتسرب.',
              en: 'Circuit Breaker = Disjoncteur = قاطع | Contactor = Contacteur = كونتاكتور | Bearing = Roulement = رولمان | Gasket = Joint = جوان.',
            },
          },
        ],
        quizQuestion: {
          id: 'aq_lang_101_l1',
          labId: 'electrical',
          question: {
            ar: 'ما المقابل الصحيح بالفرنسية والإنجليزية لمصطلح "قاطع الدائرة الكهربائية"؟',
            fr: 'Quelle est la traduction exacte en anglais et en arabe de "Disjoncteur" ?',
            en: 'What is the accurate French and Arabic equivalent of "Circuit Breaker"?',
          },
          options: {
            ar: ['Disjoncteur (FR) / Circuit Breaker (EN)', 'Roulement / Bearing', 'Vanne / Gate Valve', 'Bobine / Stator'],
            fr: ['Circuit Breaker (EN) / قاطع الدائرة (AR)', 'Bearing / كرسي تحميل', 'Impeller / مروحة مضخة', 'Thermocouple / حساس حرارة'],
            en: ['Disjoncteur (FR) / قاطع الدائرة (AR)', 'Roulement / Bearing', 'Vanne / Valve', 'Serpentin / Coil'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'قاطع الدائرة المغناطيسي الحراري يُسمى بالفرنسية Disjoncteur وبالإنجليزية Circuit Breaker ويرمز له في المخططات بـ Q.',
            fr: 'Disjoncteur correspond à Circuit Breaker (EN) et قاطع الدائرة (AR), repéré Q sur les schémas IEC.',
            en: 'Circuit Breaker translates to Disjoncteur (FR) and قاطع الدائرة (AR), designated as Q on IEC diagrams.',
          },
          xpReward: 25,
        },
      },
    ],
  },

  // 10. General Sciences & Industrial HSE Safety (general_science)
  {
    id: 'hse_101',
    categoryId: 'general_science',
    title: {
      ar: 'مبادئ السلامة الصناعية LOTO ومكافحة الحرائق (HSE)',
      fr: 'Principes Fondamentaux HSE, LOTO & Sécurité Incendie',
      en: 'General Engineering Science & Industrial HSE Safety',
    },
    description: {
      ar: 'مثلث الحريق وفئات الطفايات، معدات الوقاية الشخصية PPE، والالتزام بإجراءات القفل والتعليق LOTO لإنقاذ الأرواح.',
      fr: 'Triangle du feu, classes d’extincteurs, équipements de protection (EPI) et procédure LOTO.',
      en: 'Fire triangle and extinguisher classes, PPE selection, electrical arc boundaries, and LOTO isolation.',
    },
    level: 'Beginner',
    durationHours: 8,
    xpReward: 180,
    lessons: [
      {
        id: 'hse_101_l1',
        courseId: 'hse_101',
        title: {
          ar: 'تصنيف الحرائق الصناعية ومطافئ ثاني أكسيد الكربون CO2',
          fr: 'Classes de Feux Industriels & Extincteurs CO2',
          en: 'Industrial Fire Classes & Electrical CO2 Extinguishers',
        },
        durationMin: 20,
        summary: {
          ar: 'لماذا يُمنع استخدام الماء في حرائق الكهرباء والزيوت، ومتى نستخدم طفاية CO2 أو البودرة الجافة.',
          fr: 'Pourquoi proscrire l’eau sur feux électriques/hydrocarbures et privilégier le CO2 ou la poudre ABC.',
          en: 'Why water is fatal on live switchgear or oil fires, and when to deploy CO2 vs dry powder.',
        },
        sections: [
          {
            heading: {
              ar: 'مثلث الاحتراق والوقاية الكهربائية',
              fr: 'Triangle du Feu & Risque Électrique',
              en: 'Fire Triangle & Electrical Hazard Control',
            },
            body: {
              ar: 'يتكون الحريق من 3 عناصر: الوقود + الأكسجين + الحرارة. في حرائق اللوحات الكهربائية الحية نستخدم طفاية CO2 لأن الغاز لا يوصل الكهرباء ولا يترك بقايا تتلف البطاقات الإلكترونية، بخلاف الماء الموصل للتيار.',
              fr: 'Combustion = Combustible + Comburant + Énergie d’activation. Le CO2 étouffe l’arc électrique sans endommager l’électronique.',
              en: 'Combustion requires Fuel + Oxygen + Heat. CO2 extinguishers displace oxygen cleanly on live electrical panels without conductive residue.',
            },
            keyRules: {
              ar: ['لا تستخدم الماء أبداً على المعدات الكهربائية أو الزيت الحراري الساخن', 'تحقق دائماً من اتجاه الريح ومخرج الطوارئ قبل مكافحة أي حريق أولي'],
              fr: ['Ne jamais utiliser d’eau sur une armoire sous tension ou huile chaude', 'Toujours garder une issue de secours dégagée derrière soi'],
              en: ['Never apply water to energized switchgear or hot thermal oil', 'Keep an unobstructed exit path behind you at all times'],
            },
          },
        ],
        practicalExercise: {
          ar: 'افتح مركز السلامة HSE وجرب سيناريوهات العزل والتقييم المباشر للوقاية من المخاطر.',
          fr: 'Ouvrez le module Sécurité HSE et complétez la check-list de consignation.',
          en: 'Open the HSE Safety Center and practice lockout-tagout and PPE selection.',
        },
        quizQuestion: {
          id: 'aq_hse_101_l1',
          labId: 'faults',
          question: {
            ar: 'أي نوع من طفايات الحريق هو الأنسب والأكثر أماناً لإخماد اشتعال داخل لوحة تحكم كهربائية حية؟',
            fr: 'Quel extincteur est le plus sûr pour un début d’incendie dans une armoire électrique sous tension ?',
            en: 'Which extinguisher type is safest for an electrical fire inside an energized control cabinet?',
          },
          options: {
            ar: ['طفاية ثاني أكسيد الكربون CO2', 'خراطيم المياه المضغوطة', 'الرغوة المائية الكثيفة', 'الزيت المعدني'],
            fr: ['Extincteur au CO2', 'Lance à eau pulvérisée', 'Mousse aqueuse abondante', 'Huile minérale'],
            en: ['CO2 (Carbon Dioxide) Extinguisher', 'Pressurized Water Hose', 'Heavy Water Foam', 'Mineral Oil'],
          },
          correctIndex: 0,
          explanation: {
            ar: 'غاز CO2 غير موصل للكهرباء ولا يتلف اللوحات الإلكترونية بالرطوبة أو الرواسب.',
            fr: 'Le CO2 est diélectrique et ne laisse aucun résidu corrosif sur les composants électriques.',
            en: 'CO2 is non-conductive and leaves zero conductive or corrosive residue on electronics.',
          },
          xpReward: 30,
        },
      },
    ],
  },
];
