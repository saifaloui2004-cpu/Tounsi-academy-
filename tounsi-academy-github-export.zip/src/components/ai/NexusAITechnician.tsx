/**
 * NEXUS TOUNSI — NEXUS AI TECHNICIAN
 * Industrial Maintenance AI Assistant (By Saif Eddine Aloui — فلسطين في القلب 🇵🇸)
 * Expert engineering heuristics, symptom interpreter, safety protocols, and LOTO enforcement.
 */

import React, { useState, useRef, useEffect } from 'react';
import { AITechnicianMessage, Language } from '../../types';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  Bot, Send, Sparkles, ShieldAlert, Wrench, AlertTriangle, 
  HelpCircle, CheckCircle2, RotateCcw, Cpu, Calculator 
} from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
}

const PRESET_QUERIES = [
  {
    ar: 'المضخة P-101 تهتز بشدة وتصدر صوت طحن حصى، ما هو التشخيص؟',
    fr: 'La pompe vibre et émet un bruit de gravier avec chute de débit.',
    en: 'Pump P-101 is vibrating with a gravel crackling noise and dropping head.',
  },
  {
    ar: 'محرك مضخة التبريد يفصل بعد 12 دقيقة بحرارة 114°C مع انطلاق المرحل F1.',
    fr: 'Le moteur déclenche après 12 min à 114°C avec relais thermique F1.',
    en: 'Motor trips after 12 min running at 114°C with thermal overload F1 tripped.',
  },
  {
    ar: 'كيف أحسب عزم الخرج لعلبة التروس من قدرة المحرك والسرعة؟',
    fr: 'Comment calculer le couple de sortie d’un réducteur selon la puissance et le régime ?',
    en: 'How do I calculate gearbox output torque from input power and RPM?',
  },
  {
    ar: 'ما هي خطوات وإجراءات العزل الميكانيكي والكهربائي الآمن (LOTO)؟',
    fr: 'Quelles sont les étapes obligatoires de consignation LOTO ?',
    en: 'What are the mandatory Lockout/Tagout (LOTO) energy isolation steps?',
  },
];

export const NexusAITechnician: React.FC<Props> = ({ language, onRewardXP }) => {
  const t = i18n[language];
  const [inputQuery, setInputQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<AITechnicianMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      text: language === 'ar'
        ? 'مرحباً بك يا مهندس في المساعد الفني الذكي NEXUS AI TECHNICIAN. أنا هنا لمساعدتك في تحليل الأعطال الميدانية، تفسير قياسات الحساسات، حساب المعادلات الهندسية، والتأكد من تطبيق معايير السلامة المهنية LOTO. صِف المشكلة أو اختر استفساراً سريعاً من الأسفل.'
        : language === 'fr'
        ? 'Bienvenue sur NEXUS AI TECHNICIAN. Je suis votre assistant expert en maintenance industrielle, analyse de pannes, calculs cinématiques et protocoles de consignation LOTO. Décrivez votre problème technique ou sélectionnez une question type.'
        : 'Welcome to NEXUS AI TECHNICIAN. I am your industrial reliability and troubleshooting assistant. I can help interpret telemetry, evaluate root causes, solve engineering formulas, and enforce LOTO safety protocols.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      confidence: 'fact',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Intelligent Engineering Reasoning Engine (Offline Heuristics)
  const generateEngineeringResponse = (userText: string): AITechnicianMessage => {
    const q = userText.toLowerCase();

    // 1. Cavitation query
    if (q.includes('حصى') || q.includes('تكهف') || q.includes('cavitation') || q.includes('gravel') || q.includes('p-101')) {
      return {
        id: `resp_${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        confidence: 'hypothesis',
        safetyWarning: 'خطر التدفق الساخن والضغط: لا تفتح غطاء الفلتر قبل التأكد من برودة المنظومة (< 40°C) وتصريف الضغط بالكامل.',
        text: language === 'ar'
          ? `بناءً على الأعراض المرصودة (صوت طحن الحصى، تذبذب التدفق، وهبوط الضغط):\n\n` +
            `• الوقائع المؤكدة (Facts): المضخة تعاني من اضطراب هيدروليكي حاد في غرفة السحب، وهناك انهيار لفقاعات البخار على ريش المروحة.\n` +
            `• الفرضية الأكثر ترجيحاً (Root Cause): انسداد مصفاة السحب Y-Strainer أو عدم كفاية رأس السحب الإيجابي (NPSHa < NPSHr)، مما هبط بالضغط دون ضغط البخار المشبع للسائل.\n` +
            `• القياسات المطلوبة للتأكيد: قياس فرق الضغط ΔP عبر الفلتر، ومقارنة ضغط السحب بمقياس كولومب.`
          : `Analyse technique du phénomène de cavitation:\n\n` +
            `• Faits avérés: Bruit métallique caractéristique d'implosion de bulles de vapeur et instabilité de refoulement.\n` +
            `• Hypothèse principale: Chute du NPSH disponible sous le NPSH requis, très probablement causée par l'encrassement du filtre d'aspiration Y.\n` +
            `• Mesures à vérifier: Pression relative d'aspiration PT-01 et perte de charge différentielle.`,
        diagnosticSteps: [
          'عزل المضخة وتطبيق القفل والوسم LOTO.',
          'تفريغ الضغط وفك سلة الفلتر Y-Strainer وتنظيفها.',
          'التحقق من منسوب الخزان المغذي وعدم وجود تسريب هواء على خط السحب.',
        ],
      };
    }

    // 2. Motor Overheating query
    if (q.includes('سخونة') || q.includes('حرارة') || q.includes('114') || q.includes('surchauffe') || q.includes('overheat') || q.includes('f1')) {
      return {
        id: `resp_${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        confidence: 'fact',
        safetyWarning: 'خطر الحروق: لا تلمس غلاف المحرك بيدك المجردة فوق 70°C واستخدم الكاميرا الحرارية دوماً.',
        text: language === 'ar'
          ? `تحليل حرارة المحرك الكهربائي وانطلاق المرحل F1:\n\n` +
            `• الوقائع المؤكدة: حرارة 114°C تتجاوز حد العزل الآمن، ولكن استمرار العمل لـ 12 دقيقة ينفي وجود قصر كهربائي مباشر.\n` +
            `• الفرضية المرجحة: انسداد غطاء مروحة التبريد وتراكم الغبار على الزعانف الخارجية (Thermal Choking)، مما يمنع التبديد الحراري الطبيعي.\n` +
            `• التحقق بالقياس: قياس التيارات للأطوار الثلاثة للتأكد من توازنها (~29A) وقياس سرعة تدفق الهواء بالأنيموميتر.`
          : `Diagnostic thermique statorique:\n\n` +
            `• Faits: Déclenchement thermique retardé à 114°C sans déséquilibre de phase franc.\n` +
            `• Cause racine: Colmatage du capot de ventilation ou ailettes encrassées empêchant la convection forcée.\n` +
            `• Actions: Nettoyage à l'air sec et recalibrage du relais F1 à 1.05 In.`,
        diagnosticSteps: [
          'فصل القاطع المغذي Q1 وتطبيق إجراءات LOTO.',
          'فك الغطاء الخلفي للمروحة وتنظيفه بالهواء المضغوط.',
          'فحص عيار المرحل الحراري F1 ومقاومة العزل بجهاز الميغومتر (500V).',
        ],
      };
    }

    // 3. Torque & Gearbox calculation query
    if (q.includes('عزم') || q.includes('تروس') || q.includes('couple') || q.includes('torque') || q.includes('gear')) {
      return {
        id: `resp_${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        confidence: 'fact',
        text: language === 'ar'
          ? `حسابات عزم الدوران لعلب التروس الميكانيكية:\n\n` +
            `1. عزم الدخول للمحرك: T_{in} = \\frac{9550 \\times P_{kW}}{N_{RPM}}\n` +
            `2. نسبة التخفيض: i = \\frac{Z_{driven}}{Z_{driver}} = \\frac{N_{in}}{N_{out}}\n` +
            `3. عزم الخرج النظري: T_{out} = T_{in} \\times i \\times \\eta\n` +
            `حيث \\eta تمثل كفاءة التعشيق (حوالي 0.96 للتروس الأسطوانية الحلزونية).`
          : `Calcul cinématique et dynamique des réducteurs:\n\n` +
            `• Couple moteur: T = 9550 * P(kW) / N(tr/min)\n` +
            `• Rapport de réduction: i = Z2 / Z1\n` +
            `• Couple utile: T_sortie = T_moteur * i * rendement (0.95 - 0.98).`,
        diagnosticSteps: [
          'تحديد سرعة دوران عمود المحرك الاسمية من لوحة البيانات (Nameplate).',
          'عد أسنان الترس القائد والمقاد لحساب النسبة الدقيقة.',
          'مراعاة عزم القصور الذاتي للأحمال الثقيلة عند بدء الحركة.',
        ],
      };
    }

    // 4. LOTO safety query
    if (q.includes('loto') || q.includes('عزل') || q.includes('سلامة') || q.includes('consignation') || q.includes('lockout')) {
      return {
        id: `resp_${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        confidence: 'fact',
        safetyWarning: 'قاعدة صارمة: لا تعتمد أبداً على مفتاح تحكم عادي أو زر إيقاف في لوحة PLC؛ يجب عزل قاطع القوى الرئيسي ووضع القفل الشخصي Padlock.',
        text: language === 'ar'
          ? `خطوات العزل المعتمدة للصيانة الصناعية (Lockout / Tagout - LOTO):\n\n` +
            `1. الإشعار والتحضير: إخطار مشغلي الخط ومسؤولي الإنتاج.\n` +
            `2. إيقاف التشغيل النظامي للمعدة.\n` +
            `3. العزل الفعلي: فصل القاطع الكهربائي الرئيسي وصمامات الإمداد الهيدروليكية والغازية.\n` +
            `4. القفل والوسم: تركيب القفل الشخصي وبطاقة التحذير الصفراء/الحمراء باسم الفني.\n` +
            `5. تفريغ الطاقة المتبقية: تفريغ المجمعات الهيدروليكية، المكثفات، والضغط الميكانيكي.\n` +
            `6. التحقق من غياب الجهد (VAT): استخدام جهاز فحص الجهد للتأكد من صفر فولت.`
          : `Procédure formelle de consignation industrielle (LOTO):\n\n` +
            `1. Séparation des sources d'énergie (électrique, hydraulique, pneumatique).\n` +
            `2. Condamnation par cadenas personnel et étiquetage de sécurité.\n` +
            `3. Dissipation / purge des énergies résiduelles (accumulateurs, vérins).\n` +
            `4. Vérification d'Absence de Tension (VAT) avec appareil certifié.`,
      };
    }

    // Default general technical guidance
    return {
      id: `resp_${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      confidence: 'hypothesis',
      text: language === 'ar'
        ? `شكراً على استفسارك الهندسي.\n\n` +
          `لإعطائك تشخيصاً دقيقاً دون افتراضات عشوائية، يرجى تزويدي بالبيانات التالية:\n` +
          `1. ما هي القياسات المأخوذة بالأجهزة (الجهد V، التيار A، الضغط bar، أو الاهتزاز mm/s)؟\n` +
          `2. هل العطل يظهر عند بدء التشغيل فوراً أم بعد فترة زمنية محددة تحت الحمل؟\n` +
          `3. ما هي الحالة الميكانيكية الظاهرة (سخونة، تسريب، ضوضاء غير عادية)؟\n\n` +
          `يمكنك أيضاً استخدام أحد النماذج المسبقة من القائمة السريعة أدناه.`
        : `Analyse technique générale:\n\n` +
          `Pour affiner le diagnostic selon les règles de l'art, merci de préciser:\n` +
          `1. Relevés au multimètre, manomètre ou vibromètre.\n` +
          `2. Régime de fonctionnement au moment de l'anomalie.\n` +
          `3. Symptômes acoustiques ou thermiques observés.`,
    };
  };

  const handleSendMessage = () => {
    if (!inputQuery.trim() || isProcessing) return;
    const userText = inputQuery.trim();
    setInputQuery('');

    const userMsg: AITechnicianMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsProcessing(true);
    sound.playBeep(900, 0.04);

    setTimeout(() => {
      const resp = generateEngineeringResponse(userText);
      setMessages((prev) => [...prev, resp]);
      setIsProcessing(false);
      sound.playBeep(700, 0.06);
      onRewardXP(15);
    }, 600);
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 md:p-6 gap-4 overflow-hidden">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3.5 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
            <Bot className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white flex items-center gap-2">
              NEXUS AI TECHNICIAN — المساعد الصناعي الذكي
            </h1>
            <span className="text-[11px] text-slate-400 font-mono">
              Expert Reliability Assistant • Saif Eddine Aloui — فلسطين في القلب 🇵🇸
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setMessages([messages[0]]);
              sound.playRelayClick();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-mono"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>محادثة جديدة</span>
          </button>
        </div>
      </div>

      {/* Chat Messages Feed */}
      <div className="flex-1 bg-slate-900/60 border border-slate-800 rounded-xl p-4 overflow-y-auto space-y-4 shadow-inner">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-2xl rounded-2xl p-4 text-xs md:text-sm leading-relaxed space-y-2 shadow-lg ${
                  isUser
                    ? 'bg-cyan-600 text-white rounded-br-none'
                    : 'bg-slate-950/90 border border-slate-800 text-slate-200 rounded-bl-none'
                }`}
              >
                {!isUser && (
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 text-[10px] font-mono">
                    <span className="text-cyan-400 font-bold flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      NEXUS AI ENGINE
                    </span>
                    {msg.confidence && (
                      <span
                        className={`px-1.5 py-0.5 rounded ${
                          msg.confidence === 'fact'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}
                      >
                        {msg.confidence === 'fact' ? 'حقائق مؤكدة (Fact)' : 'فرضية هندسية (Hypothesis)'}
                      </span>
                    )}
                  </div>
                )}

                <div className="whitespace-pre-line font-sans">
                  {msg.text}
                </div>

                {/* Safety Warning Box */}
                {msg.safetyWarning && (
                  <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{msg.safetyWarning}</span>
                  </div>
                )}

                {/* Diagnostic Steps List */}
                {msg.diagnosticSteps && (
                  <div className="pt-2 border-t border-slate-800 space-y-1">
                    <span className="text-[11px] font-bold text-cyan-300 block">إجراءات الفحص الموصى بها:</span>
                    <ol className="list-decimal list-inside space-y-0.5 text-xs text-slate-300">
                      {msg.diagnosticSteps.map((s, idx) => (
                        <li key={idx}>{s}</li>
                      ))}
                    </ol>
                  </div>
                )}

                <div className="text-[10px] text-right font-mono text-slate-500 pt-1">
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isProcessing && (
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 p-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>جاري تحليل الأعراض الهندسية والفيزيائية...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {PRESET_QUERIES.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInputQuery(preset[language]);
              sound.playBeep(700, 0.03);
            }}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 text-xs whitespace-nowrap transition-all font-mono"
          >
            {preset[language]}
          </button>
        ))}
      </div>

      {/* Input Message Bar */}
      <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 p-2 rounded-xl shadow-lg">
        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSendMessage();
          }}
          placeholder="اكتب استفسارك الهندسي، قياساتك، أو أعراض العطل بالتفصيل..."
          className="flex-1 bg-transparent px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
        />
        <button
          onClick={handleSendMessage}
          disabled={!inputQuery.trim() || isProcessing}
          className={`p-2.5 rounded-xl transition-all ${
            inputQuery.trim() && !isProcessing
              ? 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-md shadow-cyan-500/25 active:scale-95'
              : 'bg-slate-800 text-slate-600 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4 rtl:rotate-180" />
        </button>
      </div>
    </div>
  );
};
