/**
 * NEXUS WORKSHOP — 2D Interactive Industrial Circuit Simulation Canvas
 * Full drag-and-drop, wiring between terminals, live motor spin, breaker trip,
 * multimeter probing, and preset industrial circuits.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { CircuitComponent, CircuitWire, ComponentType, Language } from '../../types';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  Play, Square, RotateCcw, Plus, Trash2, Zap, 
  HelpCircle, CheckCircle2, AlertOctagon, Activity 
} from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
}

// Preset circuit templates
const PRESETS = [
  {
    id: 'dol_motor',
    name: { ar: 'دائرة إقلاع مباشر للمحرك (DOL Starter)', fr: 'Démarrage Direct Moteur (DOL)', en: 'Direct-on-Line (DOL) Motor Starter' },
    components: [
      {
        id: 'pwr_1',
        type: 'power_source' as ComponentType,
        label: 'Mains 400V 3~',
        x: 40,
        y: 40,
        state: { closed: true, energized: true, value: 400 },
        terminals: [
          { id: 'L1', name: 'L1', x: 20, y: 100, type: 'phase' as const },
          { id: 'L2', name: 'L2', x: 50, y: 100, type: 'phase' as const },
          { id: 'L3', name: 'L3', x: 80, y: 100, type: 'phase' as const },
        ],
      },
      {
        id: 'q1',
        type: 'circuit_breaker' as ComponentType,
        label: 'Disjoncteur Q1',
        x: 40,
        y: 160,
        state: { closed: true, tripped: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 20, y: 100, type: 'out' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
          { id: '6', name: '6', x: 80, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 'km1',
        type: 'contactor' as ComponentType,
        label: 'Contacteur KM1',
        x: 40,
        y: 300,
        state: { closed: false, energized: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 20, y: 100, type: 'out' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
          { id: '6', name: '6', x: 80, y: 100, type: 'out' as const },
          { id: 'A1', name: 'A1', x: 0, y: 50, type: 'coil' as const },
          { id: 'A2', name: 'A2', x: 100, y: 50, type: 'coil' as const },
        ],
      },
      {
        id: 'f1',
        type: 'thermal_relay' as ComponentType,
        label: 'Relais Thermique F1',
        x: 40,
        y: 440,
        state: { closed: true, tripped: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 20, y: 100, type: 'out' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
          { id: '6', name: '6', x: 80, y: 100, type: 'out' as const },
          { id: '95', name: '95', x: 0, y: 50, type: 'aux' as const },
          { id: '96', name: '96', x: 100, y: 50, type: 'aux' as const },
        ],
      },
      {
        id: 'm1',
        type: 'motor_3phase' as ComponentType,
        label: 'Moteur Triphasé M1 (11 kW)',
        x: 40,
        y: 580,
        state: { running: false, rotation: 0 },
        terminals: [
          { id: 'U1', name: 'U1', x: 20, y: 0, type: 'in' as const },
          { id: 'V1', name: 'V1', x: 50, y: 0, type: 'in' as const },
          { id: 'W1', name: 'W1', x: 80, y: 0, type: 'in' as const },
        ],
      },
      // Control Circuit
      {
        id: 's0',
        type: 'push_button_nc' as ComponentType,
        label: 'Bouton Arrêt S0 (NC)',
        x: 270,
        y: 140,
        state: { closed: true },
        terminals: [
          { id: '1', name: '1', x: 50, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 50, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 's1',
        type: 'push_button_no' as ComponentType,
        label: 'Bouton Marche S1 (NO)',
        x: 270,
        y: 280,
        state: { closed: false },
        terminals: [
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 'h1',
        type: 'indicator_lamp' as ComponentType,
        label: 'Voyant Marche H1 (Vert)',
        x: 420,
        y: 340,
        state: { energized: false },
        terminals: [
          { id: 'X1', name: 'X1', x: 50, y: 0, type: 'in' as const },
          { id: 'X2', name: 'X2', x: 50, y: 100, type: 'neutral' as const },
        ],
      },
    ],
    wires: [
      { id: 'w1', fromCompId: 'pwr_1', fromTermId: 'L1', toCompId: 'q1', toTermId: '1', color: '#ef4444', isLive: true, current: 0 },
      { id: 'w2', fromCompId: 'pwr_1', fromTermId: 'L2', toCompId: 'q1', toTermId: '3', color: '#eab308', isLive: true, current: 0 },
      { id: 'w3', fromCompId: 'pwr_1', fromTermId: 'L3', toCompId: 'q1', toTermId: '5', color: '#3b82f6', isLive: true, current: 0 },
      { id: 'w4', fromCompId: 'q1', fromTermId: '2', toCompId: 'km1', toTermId: '1', color: '#ef4444', isLive: true, current: 0 },
      { id: 'w5', fromCompId: 'q1', fromTermId: '4', toCompId: 'km1', toTermId: '3', color: '#eab308', isLive: true, current: 0 },
      { id: 'w6', fromCompId: 'q1', fromTermId: '6', toCompId: 'km1', toTermId: '5', color: '#3b82f6', isLive: true, current: 0 },
      { id: 'w7', fromCompId: 'km1', fromTermId: '2', toCompId: 'f1', toTermId: '1', color: '#ef4444', isLive: false, current: 0 },
      { id: 'w8', fromCompId: 'km1', fromTermId: '4', toCompId: 'f1', toTermId: '3', color: '#eab308', isLive: false, current: 0 },
      { id: 'w9', fromCompId: 'km1', fromTermId: '6', toCompId: 'f1', toTermId: '5', color: '#3b82f6', isLive: false, current: 0 },
      { id: 'w10', fromCompId: 'f1', fromTermId: '2', toCompId: 'm1', toTermId: 'U1', color: '#ef4444', isLive: false, current: 0 },
      { id: 'w11', fromCompId: 'f1', fromTermId: '4', toCompId: 'm1', toTermId: 'V1', color: '#eab308', isLive: false, current: 0 },
      { id: 'w12', fromCompId: 'f1', fromTermId: '6', toCompId: 'm1', toTermId: 'W1', color: '#3b82f6', isLive: false, current: 0 },
    ],
  },
  {
    id: 'single_phase_motor',
    name: { ar: 'دائرة محرك أحادي الطور 230V مع حماية تفاضلية', fr: 'Circuit Moteur Monophasé 230V & Différentiel', en: 'Single-Phase 230V Motor & RCD Circuit' },
    components: [
      {
        id: 'pwr_sp',
        type: 'power_source_single' as ComponentType,
        label: 'Mains 230V (Phase + Neutral + PE)',
        x: 40,
        y: 50,
        state: { closed: true, energized: true, value: 230 },
        terminals: [
          { id: 'Ph', name: 'Phase (L)', x: 25, y: 100, type: 'phase' as const },
          { id: 'N', name: 'Neutre (N)', x: 50, y: 100, type: 'neutral' as const },
          { id: 'PE', name: 'Terre (PE)', x: 75, y: 100, type: 'earth' as const },
        ],
      },
      {
        id: 'rcd_1',
        type: 'differential_breaker' as ComponentType,
        label: 'Disjoncteur Différentiel 30mA (Q0)',
        x: 40,
        y: 180,
        state: { closed: true, tripped: false },
        terminals: [
          { id: '1', name: '1 (L)', x: 25, y: 0, type: 'in' as const },
          { id: 'N_in', name: 'N in', x: 75, y: 0, type: 'in' as const },
          { id: '2', name: '2 (L)', x: 25, y: 100, type: 'out' as const },
          { id: 'N_out', name: 'N out', x: 75, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 'km_sp',
        type: 'contactor' as ComponentType,
        label: 'Contacteur KM1 Monophasé',
        x: 40,
        y: 330,
        state: { closed: false, energized: false },
        terminals: [
          { id: '1', name: '1', x: 30, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 70, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 30, y: 100, type: 'out' as const },
          { id: '4', name: '4', x: 70, y: 100, type: 'out' as const },
          { id: 'A1', name: 'A1', x: 0, y: 50, type: 'coil' as const },
          { id: 'A2', name: 'A2', x: 100, y: 50, type: 'coil' as const },
        ],
      },
      {
        id: 'm_sp',
        type: 'motor_single' as ComponentType,
        label: 'Moteur Monophasé (2.2 kW + Condensateur)',
        x: 40,
        y: 480,
        state: { running: false, rotation: 0 },
        terminals: [
          { id: 'U', name: 'U (Phase)', x: 30, y: 0, type: 'in' as const },
          { id: 'N', name: 'N (Neutre)', x: 70, y: 0, type: 'neutral' as const },
        ],
      },
      {
        id: 's0_sp',
        type: 'push_button_nc' as ComponentType,
        label: 'Arrêt S0 (NC)',
        x: 270,
        y: 180,
        state: { closed: true },
        terminals: [
          { id: '1', name: '1', x: 50, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 50, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 's1_sp',
        type: 'push_button_no' as ComponentType,
        label: 'Marche S1 (NO)',
        x: 270,
        y: 320,
        state: { closed: false },
        terminals: [
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
        ],
      },
    ],
    wires: [
      { id: 'w_sp1', fromCompId: 'pwr_sp', fromTermId: 'Ph', toCompId: 'rcd_1', toTermId: '1', color: '#ef4444', isLive: true, current: 0 },
      { id: 'w_sp2', fromCompId: 'pwr_sp', fromTermId: 'N', toCompId: 'rcd_1', toTermId: 'N_in', color: '#3b82f6', isLive: true, current: 0 },
      { id: 'w_sp3', fromCompId: 'rcd_1', fromTermId: '2', toCompId: 'km_sp', toTermId: '1', color: '#ef4444', isLive: true, current: 0 },
      { id: 'w_sp4', fromCompId: 'rcd_1', fromTermId: 'N_out', toCompId: 'km_sp', toTermId: '3', color: '#3b82f6', isLive: true, current: 0 },
      { id: 'w_sp5', fromCompId: 'km_sp', fromTermId: '2', toCompId: 'm_sp', toTermId: 'U', color: '#ef4444', isLive: false, current: 0 },
      { id: 'w_sp6', fromCompId: 'km_sp', fromTermId: '4', toCompId: 'm_sp', toTermId: 'N', color: '#3b82f6', isLive: false, current: 0 },
    ],
  },
  {
    id: 'star_delta_starter',
    name: { ar: 'دائرة إقلاع نجمي-مثلثي (Star-Delta Y-Δ Starter)', fr: 'Démarrage Étoile-Triangle (Y-Δ)', en: 'Star-Delta (Y-Δ) Automated Starter' },
    components: [
      {
        id: 'pwr_sd',
        type: 'power_source' as ComponentType,
        label: 'Mains 400V 3~ (L1-L2-L3)',
        x: 40,
        y: 40,
        state: { closed: true, energized: true, value: 400 },
        terminals: [
          { id: 'L1', name: 'L1', x: 20, y: 100, type: 'phase' as const },
          { id: 'L2', name: 'L2', x: 50, y: 100, type: 'phase' as const },
          { id: 'L3', name: 'L3', x: 80, y: 100, type: 'phase' as const },
        ],
      },
      {
        id: 'q1_sd',
        type: 'circuit_breaker' as ComponentType,
        label: 'Disjoncteur Q1 (Moteur 22kW)',
        x: 40,
        y: 160,
        state: { closed: true, tripped: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 20, y: 100, type: 'out' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
          { id: '6', name: '6', x: 80, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 'km1_line',
        type: 'contactor' as ComponentType,
        label: 'Contacteur Ligne KM1',
        x: 40,
        y: 300,
        state: { closed: false, energized: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
          { id: '2', name: '2', x: 20, y: 100, type: 'out' as const },
          { id: '4', name: '4', x: 50, y: 100, type: 'out' as const },
          { id: '6', name: '6', x: 80, y: 100, type: 'out' as const },
        ],
      },
      {
        id: 'km2_star',
        type: 'contactor' as ComponentType,
        label: 'Contacteur Étoile KM2 (Star)',
        x: 240,
        y: 300,
        state: { closed: false, energized: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
        ],
      },
      {
        id: 'km3_delta',
        type: 'contactor' as ComponentType,
        label: 'Contacteur Triangle KM3 (Delta)',
        x: 430,
        y: 300,
        state: { closed: false, energized: false },
        terminals: [
          { id: '1', name: '1', x: 20, y: 0, type: 'in' as const },
          { id: '3', name: '3', x: 50, y: 0, type: 'in' as const },
          { id: '5', name: '5', x: 80, y: 0, type: 'in' as const },
        ],
      },
      {
        id: 'm1_sd',
        type: 'motor_3phase' as ComponentType,
        label: 'Moteur Triphasé 22kW (U1-V1-W1 / U2-V2-W2)',
        x: 180,
        y: 480,
        state: { running: false, rotation: 0 },
        terminals: [
          { id: 'U1', name: 'U1', x: 20, y: 0, type: 'in' as const },
          { id: 'V1', name: 'V1', x: 50, y: 0, type: 'in' as const },
          { id: 'W1', name: 'W1', x: 80, y: 0, type: 'in' as const },
        ],
      },
    ],
    wires: [
      { id: 'wsd_1', fromCompId: 'pwr_sd', fromTermId: 'L1', toCompId: 'q1_sd', toTermId: '1', color: '#ef4444', isLive: true, current: 0 },
      { id: 'wsd_2', fromCompId: 'pwr_sd', fromTermId: 'L2', toCompId: 'q1_sd', toTermId: '3', color: '#eab308', isLive: true, current: 0 },
      { id: 'wsd_3', fromCompId: 'pwr_sd', fromTermId: 'L3', toCompId: 'q1_sd', toTermId: '5', color: '#3b82f6', isLive: true, current: 0 },
      { id: 'wsd_4', fromCompId: 'q1_sd', fromTermId: '2', toCompId: 'km1_line', toTermId: '1', color: '#ef4444', isLive: true, current: 0 },
      { id: 'wsd_5', fromCompId: 'q1_sd', fromTermId: '4', toCompId: 'km1_line', toTermId: '3', color: '#eab308', isLive: true, current: 0 },
      { id: 'wsd_6', fromCompId: 'q1_sd', fromTermId: '6', toCompId: 'km1_line', toTermId: '5', color: '#3b82f6', isLive: true, current: 0 },
    ],
  },
];

export const CircuitCanvas2D: React.FC<Props> = ({ language, onRewardXP }) => {
  const t = i18n[language];
  const [components, setComponents] = useState<CircuitComponent[]>(PRESETS[0].components);
  const [wires, setWires] = useState<CircuitWire[]>(PRESETS[0].wires);
  const [isSimulating, setIsSimulating] = useState(true);
  const [activeWiringTerminal, setActiveWiringTerminal] = useState<{ compId: string; termId: string } | null>(null);
  const [selectedCompId, setSelectedCompId] = useState<string | null>(null);
  const [multimeterActive, setMultimeterActive] = useState(false);
  const [multimeterReadout, setMultimeterReadout] = useState<string>('0.00 V');
  const [circuitNotice, setCircuitNotice] = useState<{ text: string; type: 'info' | 'success' | 'warn' | 'error' }>({
    text: t.circuitNormal,
    type: 'success',
  });

  const canvasRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef<{ id: string; startX: number; startY: number; origX: number; origY: number } | null>(null);

  // Toggle Breaker Q1
  const toggleBreaker = (compId: string) => {
    setComponents((prev) =>
      prev.map((c) => {
        if (c.id === compId) {
          const nextClosed = !c.state.closed;
          sound.playRelayClick();
          return { ...c, state: { ...c.state, closed: nextClosed, tripped: false } };
        }
        return c;
      })
    );
  };

  // Push Start Button S1 (works across DOL 3~, Mono 230V, and Star-Delta presets)
  const pressStartButton = () => {
    const breakerOpen = components.some(
      (c) => (c.type === 'circuit_breaker' || c.type === 'differential_breaker') && (!c.state.closed || c.state.tripped)
    );
    const relayTripped = components.some((c) => c.type === 'thermal_relay' && c.state.tripped);
    if (breakerOpen || relayTripped) {
      sound.playAlarm();
      setCircuitNotice({
        text:
          language === 'ar'
            ? 'تعذّر التشغيل: القاطع مفتوح أو المرحل الحراري مفصول (Reset Q1/F1)'
            : language === 'fr'
            ? 'Démarrage bloqué : disjoncteur ouvert ou relais thermique déclenché'
            : 'Start blocked: Breaker is open or thermal relay is tripped',
        type: 'error',
      });
      return;
    }

    sound.playRelayClick();
    sound.playMotorStart();
    setComponents((prev) =>
      prev.map((c) => {
        if (c.type === 'contactor') return { ...c, state: { ...c.state, closed: true, energized: true } };
        if (c.type === 'motor_3phase' || c.type === 'motor_single') return { ...c, state: { ...c.state, running: true } };
        if (c.type === 'indicator_lamp') return { ...c, state: { ...c.state, energized: true } };
        return c;
      })
    );
    setWires((prev) => prev.map((w) => ({ ...w, isLive: true, current: 21.4 })));
    setCircuitNotice({
      text:
        language === 'ar'
          ? 'المحرك يعمل بنجاح — التيار الاسمي متوازن'
          : language === 'fr'
          ? 'Moteur en marche nominale — Alimentation active'
          : 'Motor running smoothly — Nominal phase current active',
      type: 'success',
    });
    onRewardXP(15);
  };

  // Push Stop Button S0
  const pressStopButton = () => {
    sound.playRelayClick();
    setComponents((prev) =>
      prev.map((c) => {
        if (c.type === 'contactor') return { ...c, state: { ...c.state, closed: false, energized: false } };
        if (c.type === 'motor_3phase' || c.type === 'motor_single') return { ...c, state: { ...c.state, running: false } };
        if (c.type === 'indicator_lamp') return { ...c, state: { ...c.state, energized: false } };
        return c;
      })
    );
    setWires((prev) =>
      prev.map((w) => {
        const isUpstream = w.fromCompId.startsWith('pwr_');
        return { ...w, isLive: isUpstream, current: 0 };
      })
    );
    setCircuitNotice({
      text:
        language === 'ar'
          ? 'تم إيقاف تشغيل المحرك بأمر من زر الإيقاف S0'
          : language === 'fr'
          ? 'Moteur arrêté par commande S0'
          : 'Motor stopped via STOP pushbutton S0',
      type: 'info',
    });
  };

  // Handle Dragging
  const handlePointerDown = (id: string, e: React.PointerEvent) => {
    if (multimeterActive) return;
    const comp = components.find((c) => c.id === id);
    if (!comp) return;
    draggingRef.current = {
      id,
      startX: e.clientX,
      startY: e.clientY,
      origX: comp.x,
      origY: comp.y,
    };
    setSelectedCompId(id);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggingRef.current) return;
    const dx = e.clientX - draggingRef.current.startX;
    const dy = e.clientY - draggingRef.current.startY;
    const newX = Math.max(10, Math.min(800, draggingRef.current.origX + dx));
    const newY = Math.max(10, Math.min(700, draggingRef.current.origY + dy));

    setComponents((prev) =>
      prev.map((c) => (c.id === draggingRef.current?.id ? { ...c, x: newX, y: newY } : c))
    );
  };

  const handlePointerUp = () => {
    draggingRef.current = null;
  };

  // Handle Wire terminal connection
  const handleTerminalClick = (compId: string, termId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (multimeterActive) {
      sound.playBeep(1200, 0.05);
      const isMotorRunning = components.find((c) => c.id === 'm1')?.state.running;
      if (['L1', 'L2', 'L3'].includes(termId)) {
        setMultimeterReadout('400.0 V AC (Line-to-Line)');
      } else if (['U1', 'V1', 'W1'].includes(termId)) {
        setMultimeterReadout(isMotorRunning ? '398.5 V AC (Active Load)' : '0.00 V AC');
      } else if (['A1', 'A2'].includes(termId)) {
        setMultimeterReadout(isMotorRunning ? '230.2 V AC (Control Coil)' : '0.00 V AC');
      } else {
        setMultimeterReadout('0.00 V AC');
      }
      return;
    }

    if (!activeWiringTerminal) {
      setActiveWiringTerminal({ compId, termId });
      sound.playBeep(600, 0.06);
    } else {
      if (activeWiringTerminal.compId === compId && activeWiringTerminal.termId === termId) {
        setActiveWiringTerminal(null);
        return;
      }
      // Create new wire
      const newWire: CircuitWire = {
        id: `wire_${Date.now()}`,
        fromCompId: activeWiringTerminal.compId,
        fromTermId: activeWiringTerminal.termId,
        toCompId: compId,
        toTermId: termId,
        color: '#00f0ff',
        isLive: true,
        current: 0,
      };
      setWires((prev) => [...prev, newWire]);
      setActiveWiringTerminal(null);
      sound.playBeep(880, 0.08);
      onRewardXP(10);
    }
  };

  // Inject Overload Trip Fault
  const triggerThermalOverload = () => {
    sound.playAlarm();
    setComponents((prev) =>
      prev.map((c) => {
        if (c.type === 'thermal_relay') return { ...c, state: { ...c.state, tripped: true, closed: false } };
        if (c.type === 'contactor') return { ...c, state: { ...c.state, closed: false, energized: false } };
        if (c.type === 'motor_3phase' || c.type === 'motor_single') return { ...c, state: { ...c.state, running: false } };
        if (c.type === 'indicator_lamp') return { ...c, state: { ...c.state, energized: false } };
        return c;
      })
    );
    setWires((prev) => prev.map((w) => ({ ...w, isLive: false, current: 0 })));
    setCircuitNotice({
      text:
        language === 'ar'
          ? 'انطلاق المرحل الحراري F1 بسبب زيادة تيار السحب الميكانيكي! تم قطع التغذية آلياً لحماية ملفات المحرك.'
          : language === 'fr'
          ? 'Déclenchement du relais thermique F1 par surcharge courant ! Alimentation coupée.'
          : 'Thermal overload F1 tripped due to excessive motor current! Power cut automatically.',
      type: 'error',
    });
  };

  // Reset circuit
  const resetCircuit = () => {
    sound.playRelayClick();
    setComponents(PRESETS[0].components);
    setWires(PRESETS[0].wires);
    setCircuitNotice({ text: t.circuitNormal, type: 'success' });
  };

  // Calculate terminal absolute position on canvas
  const getTerminalCoords = (compId: string, termId: string) => {
    const comp = components.find((c) => c.id === compId);
    if (!comp) return { x: 0, y: 0 };
    const term = comp.terminals.find((t) => t.id === termId);
    if (!term) return { x: comp.x + 80, y: comp.y + 40 };

    const compWidth = comp.type === 'motor_3phase' ? 180 : 160;
    const compHeight = comp.type === 'motor_3phase' ? 110 : 80;

    return {
      x: comp.x + (term.x / 100) * compWidth,
      y: comp.y + (term.y / 100) * compHeight,
    };
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 gap-4 select-none">
      {/* Top Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-400 font-mono text-xs uppercase tracking-wider">
            <Activity className="w-4 h-4 animate-pulse" />
            2D CAD Engine
          </span>

          {/* Preset Circuits Selector */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            {PRESETS.map((p, pIdx) => (
              <button
                key={p.id}
                onClick={() => {
                  setComponents(p.components);
                  setWires(p.wires);
                  sound.playRelayClick();
                  setCircuitNotice({ text: `تم تحميل ${p.name[language]}`, type: 'info' });
                }}
                className="px-2.5 py-1 rounded-md text-[11px] font-medium transition-all text-slate-300 hover:text-cyan-300 hover:bg-slate-800"
              >
                {pIdx === 0 && 'DOL 3~'}
                {pIdx === 1 && 'Mono 230V'}
                {pIdx === 2 && 'Star-Delta (Y-Δ)'}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setMultimeterActive(!multimeterActive);
              sound.playBeep(multimeterActive ? 400 : 900, 0.05);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              multimeterActive
                ? 'bg-orange-500 text-black shadow-lg shadow-orange-500/30'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            {t.testMultimeter}
          </button>

          <button
            onClick={pressStartButton}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-950"
          >
            <Play className="w-3.5 h-3.5" />
            بدء التشغيل (S1)
          </button>

          <button
            onClick={pressStopButton}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-950"
          >
            <Square className="w-3.5 h-3.5" />
            إيقاف (S0)
          </button>

          <button
            onClick={triggerThermalOverload}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-medium transition-all"
            title="محاكاة انطلاق المرحل الحراري"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
            حقن عطل Overload
          </button>

          <button
            onClick={resetCircuit}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-medium transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            {t.clearCanvas}
          </button>
        </div>
      </div>

      {/* Multimeter floating banner if active */}
      {multimeterActive && (
        <div className="flex items-center justify-between bg-gradient-to-r from-amber-950/80 to-slate-900 border border-amber-500/50 p-2.5 rounded-lg text-xs font-mono text-amber-300 shadow-md">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
            <span className="font-bold">Digital Multimeter Probe Mode:</span>
            <span>انقر على أي طرف لتسجيل قياس الجهد الحقيقي</span>
          </div>
          <div className="text-base font-extrabold text-amber-400 bg-black/60 px-3 py-1 rounded border border-amber-500/30">
            {multimeterReadout}
          </div>
        </div>
      )}

      {/* Circuit Notice Banner */}
      <div
        className={`px-3 py-2 rounded-lg text-xs font-medium flex items-center gap-2 border ${
          circuitNotice.type === 'error'
            ? 'bg-rose-950/50 border-rose-500/40 text-rose-300'
            : circuitNotice.type === 'warn'
            ? 'bg-amber-950/50 border-amber-500/40 text-amber-300'
            : 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
        }`}
      >
        <CheckCircle2 className="w-4 h-4 shrink-0" />
        <span>{circuitNotice.text}</span>
      </div>

      {/* Interactive Schematic Canvas inside mobile-safe scroll wrapper */}
      <div className="w-full flex-1 overflow-x-auto rounded-xl border border-slate-800/80">
      <div
        ref={canvasRef}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="relative w-full min-h-[580px] bg-[#0c121e] overflow-auto bg-tech-grid shadow-inner"
        style={{ minWidth: '700px' }}
      >
        {/* SVG Wiring Layer */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
          <defs>
            <filter id="wire-glow">
              <feGaussianBlur stdDeviation="1.5" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {wires.map((wire) => {
            const start = getTerminalCoords(wire.fromCompId, wire.fromTermId);
            const end = getTerminalCoords(wire.toCompId, wire.toTermId);
            const midY = (start.y + end.y) / 2;
            const pathData = `M ${start.x} ${start.y} C ${start.x} ${midY}, ${end.x} ${midY}, ${end.x} ${end.y}`;

            return (
              <g key={wire.id}>
                {/* Glow background for active line */}
                {wire.isLive && (
                  <path
                    d={pathData}
                    fill="none"
                    stroke={wire.color}
                    strokeWidth="5"
                    strokeOpacity="0.25"
                    filter="url(#wire-glow)"
                  />
                )}
                <path
                  d={pathData}
                  fill="none"
                  stroke={wire.color}
                  strokeWidth="2.5"
                  strokeDasharray={wire.isLive ? '6 4' : 'none'}
                  className={wire.isLive ? 'animate-pulse' : ''}
                />
              </g>
            );
          })}
        </svg>

        {/* Components Layer */}
        {components.map((comp) => {
          const isSelected = selectedCompId === comp.id;

          return (
            <div
              key={comp.id}
              onPointerDown={(e) => handlePointerDown(comp.id, e)}
              style={{
                transform: `translate3d(${comp.x}px, ${comp.y}px, 0)`,
              }}
              className={`absolute z-20 cursor-grab active:cursor-grabbing transition-shadow rounded-lg p-3 select-none ${
                comp.type === 'motor_3phase' ? 'w-48' : 'w-40'
              } ${
                isSelected
                  ? 'border-2 border-cyan-400 bg-slate-900/95 shadow-xl shadow-cyan-950/40'
                  : 'border border-slate-700 bg-slate-900/90 hover:border-slate-500'
              }`}
            >
              {/* Component Header */}
              <div className="flex items-center justify-between pb-1 mb-2 border-b border-slate-800 text-[11px] font-bold text-slate-300">
                <span className="truncate">{comp.label}</span>
                {comp.type === 'circuit_breaker' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleBreaker(comp.id);
                    }}
                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                      comp.state.closed ? 'bg-emerald-500 text-black' : 'bg-rose-500 text-white'
                    }`}
                  >
                    {comp.state.closed ? 'ON' : 'TRIP'}
                  </button>
                )}
              </div>

              {/* Visual Body per Component Type */}
              <div className="flex flex-col items-center justify-center py-1">
                {comp.type === 'motor_3phase' && (
                  <div className="flex flex-col items-center gap-1">
                    <div
                      className={`w-14 h-14 rounded-full border-2 border-dashed flex items-center justify-center transition-all ${
                        comp.state.running
                          ? 'border-cyan-400 bg-cyan-950/50 animate-spin text-cyan-300'
                          : 'border-slate-600 bg-slate-950 text-slate-500'
                      }`}
                    >
                      <RotateCcw className="w-7 h-7" />
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400">
                      {comp.state.running ? '1460 RPM • 400V' : '0 RPM • OFF'}
                    </span>
                  </div>
                )}

                {comp.type === 'contactor' && (
                  <div className="flex items-center justify-center gap-2 py-1">
                    <div
                      className={`w-8 h-8 rounded border flex items-center justify-center text-xs font-bold font-mono transition-colors ${
                        comp.state.closed
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                          : 'bg-slate-950 border-slate-700 text-slate-500'
                      }`}
                    >
                      {comp.state.closed ? 'KM' : '--'}
                    </div>
                  </div>
                )}

                {comp.type === 'thermal_relay' && (
                  <div className="flex items-center gap-2 py-1">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        comp.state.tripped
                          ? 'bg-rose-500 text-white animate-pulse'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {comp.state.tripped ? 'TRIPPED F1' : 'READY 16-24A'}
                    </span>
                  </div>
                )}

                {comp.type === 'indicator_lamp' && (
                  <div className="py-1">
                    <div
                      className={`w-9 h-9 rounded-full border-2 flex items-center justify-center transition-all ${
                        comp.state.energized
                          ? 'bg-emerald-500 border-emerald-300 shadow-lg shadow-emerald-500/50'
                          : 'bg-emerald-950/40 border-emerald-800'
                      }`}
                    />
                  </div>
                )}

                {comp.type === 'push_button_no' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      pressStartButton();
                    }}
                    className="w-12 h-12 rounded-full bg-emerald-600 hover:bg-emerald-500 border-2 border-emerald-400 flex items-center justify-center text-xs font-bold text-white shadow-md active:scale-95"
                  >
                    START
                  </button>
                )}

                {comp.type === 'push_button_nc' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      pressStopButton();
                    }}
                    className="w-12 h-12 rounded-full bg-rose-600 hover:bg-rose-500 border-2 border-rose-400 flex items-center justify-center text-xs font-bold text-white shadow-md active:scale-95"
                  >
                    STOP
                  </button>
                )}
              </div>

              {/* Terminals Pins */}
              <div className="relative mt-2 pt-1 border-t border-slate-800/80 flex justify-around">
                {comp.terminals.map((term) => {
                  const isCurrentActive =
                    activeWiringTerminal?.compId === comp.id && activeWiringTerminal.termId === term.id;

                  return (
                    <button
                      key={term.id}
                      onClick={(e) => handleTerminalClick(comp.id, term.id, e)}
                      title={`Terminal ${term.name} (${term.type})`}
                      className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold transition-all ${
                        isCurrentActive
                          ? 'bg-cyan-400 text-black ring-2 ring-cyan-300 scale-110'
                          : 'bg-slate-800 hover:bg-cyan-900 text-slate-300 hover:text-cyan-200 border border-slate-700'
                      }`}
                    >
                      {term.name}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      </div>

      {/* Footer instruction note */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 px-2 font-mono">
        <span>{t.wiringGuide}</span>
        <span className="text-cyan-400">NEXUS TOUNSI — Industrial CAD 2D v2.4</span>
      </div>
    </div>
  );
};
