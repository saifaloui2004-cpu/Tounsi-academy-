/**
 * NEXUS WORKSHOP — Dedicated Thermal Oil Boiler & Circuit Simulator (Huile Thermique)
 * Real-time P&ID interactive diagram, thermodynamics calculations, and fault injections.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState, useEffect } from 'react';
import { ThermalOilState, Language } from '../../types';
import { IndustrialPhysics } from '../../sim/physics';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  Flame, Gauge, Activity, AlertTriangle, ShieldAlert, 
  RotateCcw, Sliders, Play, Thermometer, Wind, RefreshCw 
} from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
}

export const ThermalOilSimulator: React.FC<Props> = ({ language, onRewardXP }) => {
  const t = i18n[language];

  // Simulator operational state
  const [burnerPower, setBurnerPower] = useState<number>(65); // %
  const [pumpSpeedRPM, setPumpSpeedRPM] = useState<number>(2400); // 0 - 2900 RPM
  const [heatDemandKW, setHeatDemandKW] = useState<number>(450); // kW
  const [bypassValve, setBypassValve] = useState<number>(15); // %
  const [activeFault, setActiveFault] = useState<'none' | 'overheat' | 'low_level' | 'cavitation' | 'leak'>('none');

  // Dynamic state computed
  const [state, setState] = useState<ThermalOilState>({
    boilerPower: 65,
    pumpSpeed: 2400,
    systemPressure: 4.8,
    boilerTempOut: 245,
    boilerTempIn: 215,
    expansionTankTemp: 48,
    expansionTankLevel: 62,
    flowRate: 38.5,
    bypassValveOpen: 15,
    heatDemandKW: 450,
    heatTransferredKW: 420,
    oilDegradation: 4,
    activeFault: 'none',
    alarmActive: false,
    alarmMessage: '',
  });

  // Thermodynamics calculation loop
  useEffect(() => {
    const timer = setInterval(() => {
      setState((prev) => {
        // Compute flow rate from pump RPM
        const baseFlow = (pumpSpeedRPM / 2900) * 45; // m3/h
        let effectiveFlow = activeFault === 'cavitation' ? baseFlow * 0.55 : baseFlow;
        if (effectiveFlow < 0.1) effectiveFlow = 0.1;

        // Compute temperatures
        let targetTempOut = 120 + (burnerPower / 100) * 190; // up to 310°C
        if (activeFault === 'overheat') targetTempOut = 325; // severe overheat fault

        // Rate of temperature convergence
        const tempOut = prev.boilerTempOut + (targetTempOut - prev.boilerTempOut) * 0.08;
        const deltaT = Math.max(8, 35 * (heatDemandKW / 600) * (35 / effectiveFlow));
        const tempIn = Math.max(80, tempOut - deltaT);

        // Compute transferred heat duty Q = m_dot * Cp * deltaT
        const heatKW = IndustrialPhysics.thermal.heatTransferKW(effectiveFlow, tempIn, tempOut);

        // System pressure calculation
        let pressure = 1.0 + (pumpSpeedRPM / 2900) * 4.2;
        if (activeFault === 'cavitation') pressure = 1.2 + Math.sin(Date.now() / 200) * 0.8;
        if (activeFault === 'leak') pressure = Math.max(0.5, prev.systemPressure - 0.1);

        // Expansion tank level
        let expLevel = 50 + (tempOut - 100) * 0.12;
        if (activeFault === 'low_level') expLevel = 14;

        // Expansion tank temperature (cold seal)
        const expTemp = 35 + (tempOut - 100) * 0.08;

        // Check alarm conditions
        let alarm = false;
        let alarmMsg = '';

        if (tempOut > 310) {
          alarm = true;
          alarmMsg = 'إنذار حرج: ارتفاع حرارة الزيت فوق حد الأمان 310°C — تفحم الزيت!';
        } else if (expLevel < 20) {
          alarm = true;
          alarmMsg = 'إنذار: انخفاض مستوى خزان التمدد عن الحد الأدنى 20%!';
        } else if (activeFault === 'cavitation') {
          alarm = true;
          alarmMsg = 'تحذير: ظاهرة التكهف واضطراب التدفق في مضخة التدوير!';
        }

        return {
          ...prev,
          boilerPower: burnerPower,
          pumpSpeed: pumpSpeedRPM,
          systemPressure: Math.round(pressure * 10) / 10,
          boilerTempOut: Math.round(tempOut * 10) / 10,
          boilerTempIn: Math.round(tempIn * 10) / 10,
          expansionTankTemp: Math.round(expTemp * 10) / 10,
          expansionTankLevel: Math.round(expLevel),
          flowRate: Math.round(effectiveFlow * 10) / 10,
          heatTransferredKW: heatKW,
          activeFault,
          alarmActive: alarm,
          alarmMessage: alarmMsg,
        };
      });
    }, 400);

    return () => clearInterval(timer);
  }, [burnerPower, pumpSpeedRPM, heatDemandKW, activeFault]);

  // Inject fault
  const handleFault = (fault: 'none' | 'overheat' | 'low_level' | 'cavitation' | 'leak') => {
    setActiveFault(fault);
    if (fault !== 'none') {
      sound.playAlarm();
      onRewardXP(15);
    } else {
      sound.playRelayClick();
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 gap-4 overflow-y-auto">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3.5 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-950/80 border border-orange-500/40 text-orange-400">
            <Flame className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-bold text-white flex items-center gap-2">
              {t.thermalTitle}
            </h1>
            <span className="text-[11px] text-slate-400 font-mono">
              Fluid Circuit P&ID • Synthetic Thermal Medium ISO VG 32
            </span>
          </div>
        </div>

        {/* Fault Injection Buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => handleFault('none')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeFault === 'none'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
          >
            {t.faultNormal}
          </button>
          <button
            onClick={() => handleFault('overheat')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeFault === 'overheat'
                ? 'bg-rose-600 text-white shadow-md animate-pulse'
                : 'bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60'
            }`}
          >
            {t.faultOverheat}
          </button>
          <button
            onClick={() => handleFault('low_level')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeFault === 'low_level'
                ? 'bg-amber-600 text-white shadow-md'
                : 'bg-amber-950/50 hover:bg-amber-900/60 text-amber-300 border border-amber-800/60'
            }`}
          >
            {t.faultLowLevel}
          </button>
          <button
            onClick={() => handleFault('cavitation')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeFault === 'cavitation'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-purple-950/50 hover:bg-purple-900/60 text-purple-300 border border-purple-800/60'
            }`}
          >
            {t.faultCavitation}
          </button>
        </div>
      </div>

      {/* Alarm Banner if active */}
      {state.alarmActive && (
        <div className="flex items-center gap-3 bg-rose-950/80 border border-rose-500/60 text-rose-200 px-4 py-2.5 rounded-xl shadow-lg animate-pulse">
          <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
          <div className="text-xs font-bold font-mono">
            {state.alarmMessage}
          </div>
        </div>
      )}

      {/* Main Grid: Interactive P&ID + Live Telemetry Gauges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Simplified Interactive P&ID Diagram (Left 2 cols) */}
        <div className="lg:col-span-2 bg-[#0a0f1b] rounded-xl border border-slate-800 p-4 flex flex-col justify-between shadow-inner relative overflow-hidden bg-tech-grid">
          <div className="flex justify-between items-center text-xs text-slate-400 font-mono pb-2 border-b border-slate-800/80">
            <span>SCHÉMA P&ID — BOILER & LOOP SKID</span>
            <span className="text-cyan-400">STATUS: {activeFault === 'none' ? 'NORMAL RUN' : 'ALARM TRIP'}</span>
          </div>

          {/* Diagram Canvas */}
          <div className="relative w-full h-[320px] my-3 select-none">
            {/* Piping Paths */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {/* Hot supply line from boiler out (top) to heat exchanger */}
              <path
                d="M 120 80 L 460 80 L 460 160"
                fill="none"
                stroke="#f97316"
                strokeWidth="4"
                strokeDasharray="6 4"
                className="animate-pulse"
              />
              {/* Return line from heat exchanger back through pump to boiler in (bottom) */}
              <path
                d="M 460 220 L 460 270 L 320 270 L 260 270 L 120 270"
                fill="none"
                stroke="#0284c7"
                strokeWidth="4"
                strokeDasharray="6 4"
                className="animate-pulse"
              />
              {/* Expansion pipe from suction to overhead expansion tank */}
              <path
                d="M 230 270 L 230 40 L 290 40"
                fill="none"
                stroke="#64748b"
                strokeWidth="2.5"
              />
            </svg>

            {/* 1. Thermal Oil Boiler Block */}
            <div className="absolute top-10 left-6 w-36 h-56 bg-slate-900 border-2 border-orange-500/60 rounded-xl p-3 flex flex-col items-center justify-between shadow-xl">
              <span className="text-[11px] font-bold text-orange-400 font-mono text-center">
                BOILER B-01 (1.2 MW)
              </span>
              <div className="w-16 h-20 rounded-lg border border-orange-500/30 bg-orange-950/30 flex items-center justify-center relative overflow-hidden">
                <Flame className={`w-9 h-9 text-orange-500 transition-transform ${burnerPower > 0 ? 'scale-110 animate-bounce' : 'opacity-20'}`} />
                <span className="absolute bottom-1 text-[9px] font-mono text-orange-300 font-bold">
                  {burnerPower}%
                </span>
              </div>
              <div className="text-[10px] font-mono text-center space-y-0.5">
                <div className="text-orange-300 font-bold">T_out: {state.boilerTempOut}°C</div>
                <div className="text-cyan-300">T_in: {state.boilerTempIn}°C</div>
              </div>
            </div>

            {/* 2. Expansion Tank Block (Top Middle) */}
            <div className="absolute top-4 left-[42%] -translate-x-1/2 w-32 h-24 bg-slate-900 border border-slate-700 rounded-lg p-2 flex flex-col justify-between shadow-lg">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-300">
                <span>EXPANSION</span>
                <span className="text-cyan-400">{state.expansionTankLevel}%</span>
              </div>
              <div className="w-full bg-slate-800 h-6 rounded-md overflow-hidden relative border border-slate-700">
                <div
                  className={`h-full transition-all duration-500 ${
                    state.expansionTankLevel < 20 ? 'bg-rose-500' : 'bg-cyan-500'
                  }`}
                  style={{ width: `${state.expansionTankLevel}%` }}
                />
              </div>
              <span className="text-[9px] font-mono text-slate-400 text-center">
                Cold Seal: {state.expansionTankTemp}°C
              </span>
            </div>

            {/* 3. Circulation Pump Block (Bottom Middle) */}
            <div className="absolute bottom-4 left-[42%] -translate-x-1/2 w-28 h-24 bg-slate-900 border-2 border-cyan-500/50 rounded-xl p-2 flex flex-col items-center justify-between shadow-lg">
              <span className="text-[10px] font-bold text-cyan-400 font-mono">PUMP P-101</span>
              <div className="w-10 h-10 rounded-full border-2 border-dashed border-cyan-400 flex items-center justify-center animate-spin">
                <RefreshCw className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="text-[9px] font-mono text-slate-300">{pumpSpeedRPM} RPM</span>
            </div>

            {/* 4. Industrial Heat Exchanger Block (Right) */}
            <div className="absolute top-28 right-8 w-36 h-40 bg-slate-900 border-2 border-indigo-500/50 rounded-xl p-3 flex flex-col justify-between shadow-xl">
              <span className="text-[11px] font-bold text-indigo-400 font-mono text-center">
                HEAT EXCHANGER
              </span>
              <div className="text-center font-mono py-1">
                <div className="text-xs text-indigo-300 font-bold">
                  {state.heatTransferredKW} kW
                </div>
                <div className="text-[10px] text-slate-400">Duty Transferred</div>
              </div>
              <div className="text-[10px] font-mono text-center text-slate-400">
                ΔT: {(state.boilerTempOut - state.boilerTempIn).toFixed(1)} °C
              </div>
            </div>
          </div>

          {/* Interactive Sliders Panel */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3 border-t border-slate-800">
            {/* Burner Power Slider */}
            <div className="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-300 font-medium">{t.boilerBurnerPower}</span>
                <span className="font-mono text-orange-400 font-bold">{burnerPower}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={burnerPower}
                onChange={(e) => setBurnerPower(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
              />
            </div>

            {/* Pump Speed Slider */}
            <div className="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-300 font-medium">{t.pumpSpeedRPM}</span>
                <span className="font-mono text-cyan-400 font-bold">{pumpSpeedRPM}</span>
              </div>
              <input
                type="range"
                min="0"
                max="2900"
                step="50"
                value={pumpSpeedRPM}
                onChange={(e) => setPumpSpeedRPM(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Heat Demand Slider */}
            <div className="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-300 font-medium">حمل الاستهلاك (Demand)</span>
                <span className="font-mono text-indigo-400 font-bold">{heatDemandKW} kW</span>
              </div>
              <input
                type="range"
                min="100"
                max="800"
                step="25"
                value={heatDemandKW}
                onChange={(e) => setHeatDemandKW(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
              />
            </div>
          </div>
        </div>

        {/* Live Industrial Telemetry Readouts (Right 1 col) */}
        <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-3 shadow-lg">
          <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider pb-2 border-b border-slate-800 flex items-center justify-between">
            <span>لوحة المؤشرات الحية</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </h2>

          {/* Dials Cards */}
          <div className="space-y-2.5">
            {/* Temperature Out */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-orange-950/60 text-orange-400">
                  <Thermometer className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">{t.tempOutlet}</div>
                  <div className="text-xs text-slate-500 font-mono">PT100 Transmitter</div>
                </div>
              </div>
              <div className="text-lg font-bold font-mono text-orange-400">
                {state.boilerTempOut} °C
              </div>
            </div>

            {/* Flow Rate */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-cyan-950/60 text-cyan-400">
                  <Wind className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">{t.flowRateM3h}</div>
                  <div className="text-xs text-slate-500 font-mono">Magnetic Meter FT-01</div>
                </div>
              </div>
              <div className="text-lg font-bold font-mono text-cyan-400">
                {state.flowRate} m³/h
              </div>
            </div>

            {/* Pressure */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-emerald-950/60 text-emerald-400">
                  <Gauge className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">{t.systemPressureBar}</div>
                  <div className="text-xs text-slate-500 font-mono">Discharge Head PT-02</div>
                </div>
              </div>
              <div className="text-lg font-bold font-mono text-emerald-400">
                {state.systemPressure} bar
              </div>
            </div>

            {/* Heat Transfer Duty */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-indigo-950/60 text-indigo-400">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">{t.heatDutyKW}</div>
                  <div className="text-xs text-slate-500 font-mono">Q = ṁ · Cp · ΔT</div>
                </div>
              </div>
              <div className="text-lg font-bold font-mono text-indigo-400">
                {state.heatTransferredKW} kW
              </div>
            </div>
          </div>

          {/* Educational Insights Box */}
          <div className="bg-cyan-950/30 border border-cyan-500/20 rounded-xl p-3 text-[11px] text-cyan-200/90 leading-relaxed space-y-1">
            <span className="font-bold block text-cyan-300">مبدأ الهندسة الكيميائية:</span>
            يستخدم الزيت الحراري لنقل درجات حرارة تتجاوز 280°C عند ضغط منخفض جداً مقارنة بالبخار المائي، مع وجوب الحفاظ على خزان التمدد بارداً لمنع أكسدة الزيت وتفحمه.
          </div>
        </div>
      </div>

      {/* Legal & Educational Disclaimer Required by Master Prompt */}
      <div className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg text-[11px] text-slate-400 text-center font-mono">
        {t.thermalDisclaimer}
      </div>
    </div>
  );
};
