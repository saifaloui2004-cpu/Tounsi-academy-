/**
 * NEXUS WORKSHOP — Educational Certificate of Completion Modal
 * Unofficial educational completion certificate with student name, verification hash,
 * founder signature (Saif Eddine Aloui), and print/download capability.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { Language } from '../../types';
import { i18n } from '../../i18n/translations';
import { Award, Printer, Download, X, ShieldCheck } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userName: string;
  onUpdateUserName: (name: string) => void;
  userXP: number;
  userLevel: number;
}

function computeCredentialHash(name: string, xp: number, level: number): string {
  const input = `${name.trim().toUpperCase()}|${xp}|${level}|TOUNSI-ACADEMY`;
  let hash = 2166136261;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const hex = (hash >>> 0).toString(16).toUpperCase().padStart(8, '0');
  return `TA-TN-PS-${hex.slice(0, 4)}-${hex.slice(4, 8)}`;
}

export const CertificateModal: React.FC<Props> = ({
  isOpen,
  onClose,
  language,
  userName,
  onUpdateUserName,
  userXP,
  userLevel,
}) => {
  const t = i18n[language];
  const [nameInput, setNameInput] = useState<string>(userName);
  const [savedNotice, setSavedNotice] = useState<boolean>(false);

  useEffect(() => {
    setNameInput(userName);
  }, [userName]);

  useEffect(() => {
    if (isOpen) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00f0ff', '#ff6b00', '#10b981', '#f59e0b'],
        });
      } catch {
        // Ignore in restricted environments
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isAr = language === 'ar';
  const isFr = language === 'fr';
  const displayName = (nameInput || userName || 'Student').trim();
  const verificationHash = computeCredentialHash(displayName, userXP, userLevel);

  const issueDate = new Date().toLocaleDateString(
    language === 'ar' ? 'ar-TN' : language === 'fr' ? 'fr-FR' : 'en-US',
    { year: 'numeric', month: 'long', day: 'numeric' }
  );

  const handlePrint = () => {
    window.print();
  };

  const handleSaveName = () => {
    if (nameInput.trim()) {
      onUpdateUserName(nameInput.trim());
    }
  };

  const handleDownloadPng = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 820;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background gradient
    const bg = ctx.createLinearGradient(0, 0, 1200, 820);
    bg.addColorStop(0, '#070b14');
    bg.addColorStop(0.5, '#0c1528');
    bg.addColorStop(1, '#070b14');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, 1200, 820);

    // Double gold border
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 6;
    ctx.strokeRect(28, 28, 1144, 764);
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.45)';
    ctx.lineWidth = 2;
    ctx.strokeRect(44, 44, 1112, 732);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#22d3ee';
    ctx.font = 'bold 24px monospace';
    ctx.fillText('TOUNSI ACADEMY — POWERED BY NEXUS SIMULATION ENGINES', 600, 115);

    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 42px sans-serif';
    ctx.fillText(
      isAr ? 'شهادة إتمام تدريبية تعليمية' : isFr ? 'CERTIFICAT DE FORMATION TECHNIQUE' : 'CERTIFICATE OF TECHNICAL COMPLETION',
      600,
      195
    );

    ctx.fillStyle = '#94a3b8';
    ctx.font = '22px sans-serif';
    ctx.fillText(
      isAr ? 'تشهد منصة TOUNSI ACADEMY بأن المتدرب:' : isFr ? 'TOUNSI ACADEMY atteste que :' : 'TOUNSI ACADEMY certifies that:',
      600,
      275
    );

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 52px serif';
    ctx.fillText(displayName, 600, 355);

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(320, 378);
    ctx.lineTo(880, 378);
    ctx.stroke();

    ctx.fillStyle = '#cbd5e1';
    ctx.font = '22px sans-serif';
    ctx.fillText(
      isAr
        ? 'قد أتم بنجاح وحدات الأكاديمية التقنية ومختبرات المحاكاة 2D/3D و PLC والزيت الحراري'
        : isFr
        ? 'A complété les parcours académiques et laboratoires de simulation 2D/3D, API et Thermique'
        : 'Has successfully completed Technical Academy courses & 2D/3D/PLC/Thermal simulations',
      600,
      440
    );

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 28px monospace';
    ctx.fillText(`${userXP} XP  •  Level ${userLevel}`, 600, 505);

    // Footer metadata
    ctx.fillStyle = '#94a3b8';
    ctx.font = '18px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`DATE: ${issueDate}`, 90, 620);
    ctx.fillStyle = '#22d3ee';
    ctx.fillText(`HASH: ${verificationHash}`, 90, 655);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('فلسطين في القلب 🇵🇸', 600, 635);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#fcd34d';
    ctx.font = 'italic bold 28px serif';
    ctx.fillText('Saif Eddine Aloui', 1110, 625);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '16px sans-serif';
    ctx.fillText('Founder — TOUNSI ACADEMY', 1110, 655);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#64748b';
    ctx.font = '15px sans-serif';
    ctx.fillText(
      'Unofficial educational completion certificate — Offline Local Verification',
      600,
      740
    );

    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `TOUNSI_ACADEMY_${verificationHash}.png`;
    a.click();
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#090e18] border-2 border-cyan-500/60 rounded-2xl shadow-2xl p-6 text-slate-100 space-y-6 print:border-none print:shadow-none print:p-0 print:bg-white print:text-black">
        {/* Modal Top Bar (Hidden on print) */}
        <div className="flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-orange-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              {isAr ? 'شهادة إتمام تعليمية — TOUNSI ACADEMY' : isFr ? 'Certificat — TOUNSI ACADEMY' : 'Educational Certificate — TOUNSI ACADEMY'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Student Name Input Bar (Hidden on print) */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 print:hidden text-xs">
          <span className="text-slate-400 font-medium">{t.studentName}:</span>
          <input
            type="text"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            onBlur={handleSaveName}
            className="flex-1 min-w-[200px] bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={handleSaveName}
            className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-black font-bold"
          >
            {isAr ? 'تحديث الاسم' : isFr ? 'Mettre à jour' : 'Save Name'}
          </button>
        </div>

        {/* Certificate Graphical Document Body */}
        <div className="relative border-4 border-double border-amber-500/50 rounded-xl p-6 md:p-8 bg-gradient-to-b from-[#0c1322] via-[#090e18] to-[#0c1322] text-center space-y-6 shadow-inner print:text-black print:bg-white print:border-black">
          <div className="absolute top-3 left-3 text-amber-500/40 text-lg font-serif">❖</div>
          <div className="absolute top-3 right-3 text-amber-500/40 text-lg font-serif">❖</div>
          <div className="absolute bottom-3 left-3 text-amber-500/40 text-lg font-serif">❖</div>
          <div className="absolute bottom-3 right-3 text-amber-500/40 text-lg font-serif">❖</div>

          {/* Platform Crest */}
          <div className="space-y-1">
            <span className="text-xs font-mono tracking-widest text-cyan-400 uppercase font-bold">
              TOUNSI ACADEMY — POWERED BY NEXUS SIMULATION ENGINES
            </span>
            <h1 className="text-xl md:text-2xl font-black text-amber-400 tracking-wide font-serif">
              {isAr ? 'شهادة إتمام تدريبية تعليمية' : isFr ? 'Certificat de Formation Technique' : 'Certificate of Technical Completion'}
            </h1>
            <p className="text-[11px] text-slate-400 font-mono tracking-wider">
              com.saifaloui.tounsiacademy • LEARN WITHOUT LIMITS
            </p>
          </div>

          {/* Recipient */}
          <div className="space-y-2 py-2">
            <span className="text-xs text-slate-400 block">
              {isAr
                ? 'تشهد أكاديمية TOUNSI ACADEMY بأن المتدرب / المهندس:'
                : isFr
                ? 'La plateforme TOUNSI ACADEMY atteste que :'
                : 'TOUNSI ACADEMY hereby recognizes that:'}
            </span>
            <div className="text-2xl md:text-3xl font-extrabold text-white tracking-wider border-b-2 border-amber-500/40 inline-block px-8 pb-1 font-serif print:text-black">
              {displayName}
            </div>
            <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed pt-2">
              {isAr
                ? 'قد أتم بنجاح متطلبات المسارات الأكاديمية والمحاكاة الهندسية في مختبرات الكهرباء الصناعية، الميكانيكا، أنظمة الأتمتة PLC، ومنظومة الزيت الحراري وتشخيص الأعطال برصيد خبرة:'
                : isFr
                ? 'A complété avec succès les parcours académiques et les laboratoires de simulation industrielle (2D, 3D, PLC, Huile Thermique et Diagnostic) avec un score de :'
                : 'Has successfully completed academic modules and industrial simulation tracks across Electrical 2D, 3D Mechanics, PLC Logic, Thermal Oil & Fault Diagnosis earning:'}
            </p>
            <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono text-sm font-bold">
              <span>{userXP} XP</span>
              <span>•</span>
              <span>{t.level} {userLevel}</span>
            </div>
          </div>

          {/* Footer Metadata & Signature */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-slate-800/80 text-xs items-end">
            <div className="text-start space-y-1">
              <span className="text-slate-400 block text-[10px] font-mono">{t.issueDate}:</span>
              <span className="font-bold text-slate-200">{issueDate}</span>
              <span className="block text-[10px] text-cyan-400 font-mono">
                HASH: {verificationHash}
              </span>
            </div>

            <div className="text-center space-y-1">
              <div className="text-sm font-bold text-emerald-400 flex items-center justify-center gap-1">
                <span>فلسطين في القلب 🇵🇸</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono block">
                TOUNSI ACADEMY • NEXUS LABS
              </span>
            </div>

            <div className="text-end space-y-1">
              <span className="text-slate-400 block text-[10px] font-mono">
                {isAr ? 'الاعتماد والتوقيع:' : isFr ? 'Fondateur :' : 'Founder Signature:'}
              </span>
              <div className="font-serif italic text-base text-amber-300 font-bold">
                Saif Eddine Aloui
              </div>
              <span className="text-[10px] text-slate-400 block">
                {isAr ? 'مؤسس المنصة ومطور النظام' : isFr ? 'Fondateur & Architecte' : 'Platform Founder & Architect'}
              </span>
            </div>
          </div>

          {/* Unofficial Disclaimer */}
          <div className="pt-3 border-t border-slate-800/60 text-[10px] text-slate-500 font-mono leading-relaxed">
            {t.certificateNotice}
          </div>
        </div>

        {/* Action Controls (Hidden on print) */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 print:hidden">
          <div className="text-xs text-slate-400 font-mono flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>
              {savedNotice
                ? (isAr ? 'تم تنزيل صورة الشهادة بنجاح ✓' : 'Certificate PNG downloaded ✓')
                : (isAr ? 'موثقة محلياً دون اتصال' : isFr ? 'Vérification locale hors-ligne' : 'Verified locally offline')}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleDownloadPng}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold transition-all shadow-md active:scale-95"
            >
              <Download className="w-4 h-4" />
              {isAr ? 'حفظ كصورة PNG' : isFr ? 'Télécharger PNG' : 'Download PNG'}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold transition-all shadow-md active:scale-95"
            >
              <Printer className="w-4 h-4" />
              {t.printCertificate}
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
