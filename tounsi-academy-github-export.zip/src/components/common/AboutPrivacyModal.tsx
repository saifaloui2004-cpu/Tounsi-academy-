/**
 * TOUNSI ACADEMY — About, Privacy Policy & Legal Notice Modal
 * Required for standalone Android distribution (Uptodown / APKPure compliance).
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React from 'react';
import { Language } from '../../types';
import { ShieldCheck, Lock, Info, X, Award, Cpu, Scale } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const AboutPrivacyModal: React.FC<Props> = ({ isOpen, onClose, language }) => {
  if (!isOpen) return null;

  const isAr = language === 'ar';
  const isFr = language === 'fr';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#090e18] border-2 border-cyan-500/50 rounded-2xl shadow-2xl p-6 text-slate-100 space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <img
              src="/icon-192.png"
              alt="TOUNSI ACADEMY"
              className="w-10 h-10 rounded-xl border border-cyan-500/40 object-cover"
            />
            <div>
              <h2 className="text-base font-black text-white tracking-wide font-mono">
                TOUNSI ACADEMY — v1.0.0
              </h2>
              <p className="text-[11px] text-cyan-400 font-mono">
                com.saifaloui.tounsiacademy • Standalone Offline Edition
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Founder & Identity */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Award className="w-4 h-4" />
            <span>
              {isAr
                ? 'الهوية والتأسيس (Founder & Architecture)'
                : isFr
                ? 'Identité & Conception'
                : 'Application Identity & Founder'}
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {isAr
              ? 'منصة TOUNSI ACADEMY هي بيئة تعليمية وتدريبية تقنية متكاملة أسسها وطورها سيف الدين العلوي (Saif Eddine Aloui — فلسطين في القلب 🇵🇸)، وتعمل بالكامل دون إنترنت (Offline-First) بالاعتماد على محركات المحاكاة الهندسية NEXUS Simulation Engines.'
              : isFr
              ? 'TOUNSI ACADEMY est une plateforme éducative et technique conçue par Saif Eddine Aloui (فلسطين في القلب 🇵🇸), fonctionnant 100% hors-ligne grâce aux moteurs de simulation industrielle NEXUS.'
              : 'TOUNSI ACADEMY is an offline-first educational and technical training platform founded by Saif Eddine Aloui (فلسطين في القلب 🇵🇸), powered by the NEXUS Simulation Engines.'}
          </p>
        </div>

        {/* Privacy Policy */}
        <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <Lock className="w-4 h-4" />
            <span>
              {isAr
                ? 'سياسة الخصوصية (100% محلي وبدون تتبع)'
                : isFr
                ? 'Politique de Confidentialité (100% Local)'
                : 'Privacy Policy (100% Offline & Zero Tracking)'}
            </span>
          </div>
          <ul className="space-y-1.5 text-xs text-slate-300 leading-relaxed list-disc list-inside">
            <li>
              {isAr
                ? 'لا يجمع التطبيق أي بيانات شخصية أو حسابات أو كلمات مرور أو موقع جغرافي.'
                : isFr
                ? 'Aucune donnée personnelle, aucun compte, mot de passe ou géolocalisation n’est collecté.'
                : 'This application collects zero personal data, requires no account/signup, and accesses no location or contacts.'}
            </li>
            <li>
              {isAr
                ? 'جميع نقاط الخبرة (XP) والدروس المكتملة والشهادات تُحفظ محلياً فقط على جهازك عبر التخزين المحلي (LocalStorage).'
                : isFr
                ? 'Vos points XP, leçons terminées et certificats sont stockés exclusivement localement sur votre appareil.'
                : 'All XP scores, completed lessons, and certificates are stored strictly locally on your device.'}
            </li>
            <li>
              {isAr
                ? 'لا يحتوي التطبيق على إعلانات ولا برمجيات تتبع ولا مكالمات شبكة خارجية في وضع الدراسة.'
                : isFr
                ? 'Zéro publicité, zéro traceur tiers et fonctionnement autonome sans serveur externe.'
                : 'Zero ads, zero third-party analytics SDKs, and full offline functionality without external servers.'}
            </li>
          </ul>
        </div>

        {/* Legal / Educational Disclaimer */}
        <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Scale className="w-4 h-4" />
            <span>
              {isAr
                ? 'إخلاء المسؤولية التعليمية والقانونية'
                : isFr
                ? 'Avertissement Éducatif Non Officiel'
                : 'Unofficial Educational Disclaimer'}
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {isAr
              ? 'جميع الدروس والشهادات وأدوات المحاكاة (2D، 3D، PLC، الزيت الحراري، SCADA) هي محتويات تدريبية غير رسمية مخصصة للتعلم والتأهيل الذاتي فقط، ولا تُغني عن معايير السلامة الميدانية المعتمدة أو التراخيص الرسمية لتشغيل المنشآت الصناعية الحقيقية.'
              : isFr
              ? 'Tous les cours, certificats et simulateurs (2D, 3D, API, Huile Thermique) constituent un support pédagogique non officiel destiné à la formation personnelle et ne remplacent pas les habilitations industrielles officielles.'
              : 'All lessons, certificates, and interactive simulators (2D, 3D, PLC, Thermal Oil) are unofficial educational training resources intended for self-study and must not be used for live plant control without certified engineering oversight.'}
          </p>
        </div>

        {/* Permissions Summary */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            {isAr ? 'أذونات الأندرويد: صفر أذونات حساسة' : isFr ? 'Permissions Android : Aucune permission sensible' : 'Android Permissions: Zero sensitive permissions'}
          </span>
          <span className="flex items-center gap-1 text-cyan-400">
            <Cpu className="w-3.5 h-3.5" />
            Offline Engine
          </span>
        </div>

        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold transition-all"
          >
            {isAr ? 'حسناً — إغلاق' : isFr ? 'Fermer' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
