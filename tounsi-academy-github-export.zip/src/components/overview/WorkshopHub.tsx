/**
 * NEXUS WORKSHOP — Central Workshop Hub & Engineering Modules Grid
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React from 'react';
import { LABS_LIST } from '../../data/trainingData';
import { FAULT_SCENARIOS } from '../../data/faultScenarios';
import { EngineeringLabId, Language } from '../../types';
import { i18n, arabicDialects } from '../../i18n/translations';
import { sound } from '../../utils/audio';
import { 
  Zap, Cog, Cpu, Flame, Gauge, Car, Radio, Wrench, 
  AlertTriangle, Box, ArrowRight, Award, CheckCircle2, ShieldCheck, Sparkles, GraduationCap 
} from 'lucide-react';
import { MainTab } from '../layout/Navigation';

interface Props {
  language: Language;
  dialect?: string;
  onSelectTab: (tab: MainTab) => void;
  onSelectLab: (id: EngineeringLabId) => void;
  userXP: number;
  solvedFaultCount: number;
}

export const WorkshopHub: React.FC<Props> = ({
  language,
  dialect,
  onSelectTab,
  onSelectLab,
  userXP,
  solvedFaultCount,
}) => {
  const t = i18n[language];
  const isAr = language === 'ar';
  const isFr = language === 'fr';
  const dialectInfo = arabicDialects[dialect || language] || arabicDialects.ar;
  const totalScenarios = FAULT_SCENARIOS.length;

  const getLabIcon = (id: EngineeringLabId) => {
    switch (id) {
      case 'electrical': return Zap;
      case 'mechanical': return Cog;
      case 'plc': return Cpu;
      case 'thermal': return Flame;
      case 'hydraulics': return Gauge;
      case 'automotive': return Car;
      case 'electronics': return Radio;
      case 'maintenance': return Wrench;
      case 'faults': return AlertTriangle;
      case 'sim3d': return Box;
      default: return Zap;
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 md:p-6 gap-6 overflow-y-auto">
      {/* Hero Futuristic Technical Banner */}
      <div className="relative rounded-2xl border border-cyan-500/30 bg-gradient-to-r from-slate-900 via-[#0b1322] to-slate-900 p-6 md:p-8 overflow-hidden shadow-2xl bg-tech-grid">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono text-xs font-bold shadow-md">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>TOUNSI ACADEMY — POWERED BY NEXUS SIMULATION LABS</span>
          </div>

          <h1 className="text-2xl md:text-4xl font-black text-white tracking-wide font-sans leading-tight">
            {isAr
              ? 'منصة TOUNSI ACADEMY للتعلم السريع والمحاكاة الهندسية الشاملة'
              : isFr
              ? 'TOUNSI ACADEMY : Plateforme d’Apprentissage Rapide & Simulation Industrielle'
              : 'TOUNSI ACADEMY — Rapid Mastery & 2D/3D Industrial Simulation'}
          </h1>

          <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-sans">
            {isAr
              ? `${dialectInfo.subtitle} — تجمع المنصة مسارات الأكاديمية في 10 تخصصات من المبتدئ إلى العبقري مع مختبرات NEXUS التفاعلية للدوائر الكهربائية، الأتمتة PLC، الزيت الحراري، والنماذج ثلاثية الأبعاد دون إنترنت.`
              : isFr
              ? 'Réunit les parcours pédagogiques de débutant à expert dans 10 spécialités techniques avec les laboratoires interactifs NEXUS (2D, 3D, PLC, Huile Thermique et diagnostic hors-ligne).'
              : 'Unites beginner-to-genius learning paths across 10 technical domains with interactive NEXUS 2D circuit, 3D mechanical, PLC ladder, thermal oil, and fault diagnosis simulators completely offline.'}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-mono">
            <span className="text-orange-400 font-bold tracking-wider">{t.tagline}</span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-300 font-medium">By Saif Eddine Aloui</span>
            <span className="text-slate-600">•</span>
            <span className="text-emerald-400 font-bold">{t.palestineMotto}</span>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => {
                onSelectTab('academy');
                sound.playRelayClick();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold transition-all shadow-lg shadow-amber-500/25 active:scale-95"
            >
              <GraduationCap className="w-4 h-4" />
              <span>{isAr ? 'دخول الأكاديمية وسلّم العبقرية' : isFr ? 'Accéder à l’Académie' : 'Enter Academy & Flashcards'}</span>
            </button>

            <button
              onClick={() => {
                onSelectTab('3d');
                sound.playRelayClick();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold transition-all shadow-lg shadow-cyan-500/25 active:scale-95"
            >
              <Box className="w-4 h-4" />
              <span>{isAr ? 'مركز المحاكاة 3D (7 معدات)' : isFr ? 'Centre 3D (7 Modèles)' : '3D Center (7 Models)'}</span>
            </button>

            <button
              onClick={() => {
                onSelectTab('thermal');
                sound.playRelayClick();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-400 text-black text-xs font-bold transition-all shadow-lg shadow-orange-500/25 active:scale-95"
            >
              <Flame className="w-4 h-4" />
              <span>{isAr ? 'منظومة الزيت الحراري' : isFr ? 'Huile Thermique' : 'Thermal Oil Loop'}</span>
            </button>

            <button
              onClick={() => {
                onSelectTab('faults');
                sound.playRelayClick();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-bold transition-all active:scale-95"
            >
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>
                {isAr
                  ? `تشخيص الأعطال (${totalScenarios} سيناريوهات)`
                  : isFr
                  ? `Diagnostic Pannes (${totalScenarios} cas)`
                  : `Fault Center (${totalScenarios} Cases)`}
              </span>
            </button>
          </div>
        </div>

        {/* Floating Epic Logo Emblem Preview */}
        <div className="hidden lg:block absolute right-8 rtl:right-auto rtl:left-8 top-1/2 -translate-y-1/2 z-20">
          <div className="relative w-48 h-48 rounded-2xl overflow-hidden border-2 border-cyan-500/60 shadow-2xl shadow-cyan-500/30 bg-slate-950 group">
            <img 
              src="/assets/aistudio/IMG-20261112-WA4032_c81ca538.jpg" 
              alt="Tounsi Academy Epic Emblem" 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-cyan-300">TOUNSI ACADEMY EMBLEM</span>
            </div>
          </div>
        </div>

        {/* Ambient Corner Graphic Elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-mono">
              {isAr ? 'الوحدات الهندسية' : isFr ? 'Unités Pratiques' : 'Engineering Labs'}
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-cyan-400">
              {isAr ? '10 مختبرات' : isFr ? '10 Labos' : '10 Labs'}
            </div>
          </div>
          <Zap className="w-5 h-5 text-cyan-500/60" />
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-mono">
              {isAr ? 'رصيد الخبرة المكتسبة' : isFr ? 'Expérience XP' : 'Earned XP'}
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-orange-400">{userXP} XP</div>
          </div>
          <Award className="w-5 h-5 text-orange-500/60" />
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-mono">
              {isAr ? 'الأعطال المحلولة' : isFr ? 'Pannes Résolues' : 'Faults Solved'}
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-emerald-400">
              {solvedFaultCount} / {totalScenarios}
            </div>
          </div>
          <CheckCircle2 className="w-5 h-5 text-emerald-500/60" />
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-mono">
              {isAr ? 'نماذج المعدات 3D' : isFr ? 'Équipements 3D' : '3D PBR Models'}
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-indigo-400">
              {isAr ? '7 معدات PBR' : isFr ? '7 Modèles PBR' : '7 PBR Units'}
            </div>
          </div>
          <Box className="w-5 h-5 text-indigo-500/60" />
        </div>
      </div>

      {/* Platform Philosophy & Strengths Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-cyan-500/30 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center gap-2 mb-3">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
            {isAr ? 'المزايا الاستراتيجية الفريدة (Platform Superpowers)' : isFr ? 'Points Forts de la Plateforme' : 'Core Platform Superpowers'}
          </h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <div className="font-bold text-cyan-300 mb-1">
              {isAr ? '⚡ يعمل دون إنترنت (Offline-First)' : isFr ? '⚡ 100% Hors-Ligne (Autonome)' : '⚡ 100% Offline Ready'}
            </div>
            <div className="text-slate-400 leading-relaxed">
              {isAr ? 'تعمل جميع المختبرات والمحاكاة والبطاقات التعليمية مباشرة دون اتصال بالشبكة.' : isFr ? 'Tous les laboratoires et cours fonctionnent localement sans connexion internet.' : 'All interactive simulators, courses, and flashcards run natively offline.'}
            </div>
          </div>
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <div className="font-bold text-orange-300 mb-1">
              {isAr ? '🎯 من مبتدئ إلى عبقري' : isFr ? '🎯 Progression Rapide' : '🎯 Beginner to Genius'}
            </div>
            <div className="text-slate-400 leading-relaxed">
              {isAr ? 'تدرج ذكي مع بطاقات الحفظ السريع واختبارات فورية وتوضيح عملي.' : isFr ? 'Apprentissage accéléré avec flashcards mémorisables et quiz instantanés.' : 'Accelerated understanding with spaced flashcards, diagrams, and hands-on testing.'}
            </div>
          </div>
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <div className="font-bold text-emerald-300 mb-1">
              {isAr ? '🔒 خصوصية تامة (Zero Signup)' : isFr ? '🔒 Confidentialité Totale' : '🔒 Zero Tracking Privacy'}
            </div>
            <div className="text-slate-400 leading-relaxed">
              {isAr ? 'بدون تسجيل حساب، بياناتك وتقدمك محفوظة محلياً بأمان تام على جهازك.' : isFr ? 'Aucun compte requis. Votre progression reste strictement locale sur l’appareil.' : 'No account signup needed. Your XP and certificates remain strictly on-device.'}
            </div>
          </div>
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <div className="font-bold text-indigo-300 mb-1">
              {isAr ? '🛠️ كفاءة ميدانية (Skill-First)' : isFr ? '🛠️ Compétences Terrain' : '🛠️ Field Diagnostics (Skill-First)'}
            </div>
            <div className="text-slate-400 leading-relaxed">
              {isAr ? 'تدريب ميداني تفاعلي على كشف وتشخيص الأعطال الصناعية والكهربائية الحقيقية.' : isFr ? 'Entraînement immersif à la recherche de pannes électriques et mécaniques réelles.' : 'Hands-on training in diagnosing authentic electrical, PLC, and mechanical failures.'}
            </div>
          </div>
        </div>
      </div>

      {/* 10 Core Engineering Labs Cards Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            {isAr ? 'الوحدات الهندسية الرئيسية (10 Labs)' : isFr ? 'Les 10 Laboratoires d’Ingénierie' : 'Core Engineering Modules (10 Labs)'}
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {isAr ? 'انقر على أي مختبر لفتح أدواته التفاعلية' : isFr ? 'Cliquez sur un laboratoire pour l’ouvrir' : 'Tap any lab to open its interactive toolkit'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {LABS_LIST.map((lab) => {
            const Icon = getLabIcon(lab.id);

            return (
              <div
                key={lab.id}
                onClick={() => {
                  onSelectLab(lab.id);
                  sound.playRelayClick();
                }}
                className="bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-4 flex flex-col justify-between space-y-3 cursor-pointer transition-all hover:bg-slate-850 hover:shadow-xl hover:shadow-cyan-950/20 group"
              >
                <div className="flex items-start justify-between">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-cyan-400 group-hover:text-cyan-300 group-hover:border-cyan-500/40 transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800/80">
                    +{lab.xpReward} XP
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors mb-1">
                    {lab.name[language]}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {lab.description[language]}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-cyan-400">
                  <span>{isAr ? 'فتح أدوات المختبر' : isFr ? 'Ouvrir le Laboratoire' : 'Open Lab Tools'}</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
