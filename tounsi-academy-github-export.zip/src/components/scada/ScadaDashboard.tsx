/**
 * NEXUS TOUNSI — Industrial SCADA & Plant Telemetry Dashboard
 * Real-time monitoring of plant OEE, temperature/pressure heatmaps, and alarm management.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState, useEffect } from 'react';
import { Language } from '../../types';
import { i18n } from '../../i18n/translations';
import { sound } from '../../utils/audio';
import { Activity, ShieldAlert, Cpu, Gauge, Zap, TrendingUp, Power, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface Props {
  language: Language;
}

export const ScadaDashboard: React.FC<Props> = ({ language }) => {
  const t = i18n[language];
  const [plantLive, setPlantLive] = useState<boolean>(true);
  const [boilerTemp, setBoilerTemp] = useState<number>(285.4);
  const [systemPressure, setSystemPressure] = useState<number>(12.8);
  const [pumpRpm, setPumpRpm] = useState<number>(2850);
  const [oeeScore, setOeeScore] = useState<number>(94.2);
  const [alarmTriggered, setAlarmTriggered] = useState<boolean>(false);

  // Live telemetry fluctuation
  useEffect(() => {
    let interval: any;
    if (plantLive) {
      interval = setInterval(() => {
        setBoilerTemp((bt) => +(bt + (Math.random() * 0.8 - 0.4)).toFixed(1));
        setSystemPressure((sp) => +(sp + (Math.random() * 0.1 - 0.05)).toFixed(1));
        setPumpRpm((pr) => Math.round(2850 + (Math.random() * 20 - 10)));
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [plantLive]);

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* SCADA Header */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs uppercase tracking-wider mb-2">
              <Gauge className="w-4 h-4" />
              <span>NEXUS SCADA CONTROL ROOM • PLANT TELEMETRY</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white">
              {language === 'ar' ? 'لوحة المراقبة والتحكم الصناعي SCADA' : language === 'fr' ? 'Supervision SCADA & Télémétrie Usine' : 'Plant SCADA Supervision & Telemetry'}
            </h2>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              {language === 'ar'
                ? 'مراقبة حية لكفاءة المعدات الإجمالية OEE، درجات حرارة العمليات، ضغط الشبكة، والإنذارات الفورية.'
                : language === 'fr'
                ? 'Supervision en temps réel du TRS (OEE), températures, pressions et gestion des alarmes.'
                : 'Real-time monitoring of Overall Equipment Effectiveness (OEE), live thermal/pressure telemetry, and plant alarm logs.'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setPlantLive(!plantLive);
                sound.playRelayClick();
              }}
              className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold shadow-lg transition-all ${
                plantLive
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-black shadow-emerald-500/30'
                  : 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/30'
              }`}
            >
              <Power className="w-5 h-5" />
              <span>{plantLive ? (language === 'ar' ? 'النظام متصل (Online)' : 'SCADA ONLINE') : (language === 'ar' ? 'النظام مفصول' : 'SCADA OFFLINE')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* OEE & Key KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">PLANT OEE SCORE</div>
          <div className="text-3xl font-black text-emerald-400">{oeeScore}%</div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>World-class benchmark &gt; 85%</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">BOILER TEMPERATURE</div>
          <div className="text-3xl font-black text-amber-400">{boilerTemp} °C</div>
          <div className="text-xs text-slate-400 mt-2">Setpoint: 285.0 °C</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">HYDRAULIC PRESSURE</div>
          <div className="text-3xl font-black text-cyan-400">{systemPressure} bar</div>
          <div className="text-xs text-slate-400 mt-2">Max limit: 16.0 bar</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">CIRCULATION PUMP</div>
          <div className="text-3xl font-black text-indigo-400">{pumpRpm} RPM</div>
          <div className="text-xs text-slate-400 mt-2">VFD Frequency: 50.0 Hz</div>
        </div>
      </div>

      {/* Live Plant Diagram & Alarm Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Plant Schema View */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span>{language === 'ar' ? 'مخطط تدفق العمليات الصناعية (P&ID Live)' : 'Industrial Process Flow & P&ID Live Map'}</span>
          </h3>

          <div className="bg-slate-950/80 rounded-2xl p-6 border border-slate-800 relative min-h-[300px] flex flex-col items-center justify-center">
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:24px_24px]"></div>

            <div className="grid grid-cols-3 gap-6 relative z-10 w-full max-w-xl text-center">
              <div className="p-4 bg-slate-900/90 border border-slate-700 rounded-2xl shadow-lg">
                <div className="text-xs font-mono text-slate-400">BOILER SKID</div>
                <div className="text-lg font-bold text-amber-400 mt-1">{boilerTemp}°C</div>
                <div className="text-[10px] text-emerald-400 mt-1">BURNER ON</div>
              </div>

              <div className="flex items-center justify-center">
                <div className="h-1 bg-cyan-500/50 w-full relative animate-pulse">
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 bg-cyan-400 rounded-full shadow-lg shadow-cyan-500/50"></div>
                </div>
              </div>

              <div className="p-4 bg-slate-900/90 border border-slate-700 rounded-2xl shadow-lg">
                <div className="text-xs font-mono text-slate-400">HEAT EXCHANGER</div>
                <div className="text-lg font-bold text-cyan-400 mt-1">198.5°C</div>
                <div className="text-[10px] text-emerald-400 mt-1">FLOW OK</div>
              </div>
            </div>

            <div className="mt-8 p-3 bg-slate-900/80 border border-slate-800 rounded-xl max-w-md text-center">
              <p className="text-xs text-slate-300">
                {language === 'ar'
                  ? 'جميع الصمامات الآلية والمضخات تعمل بكفاءة عالية ضمن النطاق الآمن المعياري.'
                  : 'All automated valves and circulation pumps operate within normal safe operating envelopes.'}
              </p>
            </div>
          </div>
        </div>

        {/* Alarm Log Panel */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <span>{language === 'ar' ? 'سجل الإنذارات والأحداث' : 'Plant Alarm & Event Log'}</span>
          </h3>

          <div className="space-y-2.5">
            <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-2xl flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-emerald-300">SYSTEM NORMAL</div>
                <div className="text-[10px] text-slate-400">All loops verified by PLC CPU • 12:00:00</div>
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-start gap-3">
              <Activity className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-slate-200">VFD PUMP SPEED SYNC</div>
                <div className="text-[10px] text-slate-400">Rpm locked at 2850 RPM • 11:58:20</div>
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-start gap-3">
              <Zap className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-slate-200">POWER FACTOR STABLE</div>
                <div className="text-[10px] text-slate-400">Cos φ = 0.96 inductive • 11:55:00</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
