/**
 * NEXUS WORKSHOP — Global Futuristic Technical Header
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 * Dark technical styling with Cyan & Orange accents.
 */

import React from 'react';
import { Language } from '../../types';
import { calculateLevel } from '../../utils/storage';
import { i18n, arabicDialects } from '../../i18n/translations';
import { 
  Award, Volume2, VolumeX, Globe, 
  RotateCcw, Layers, ShieldCheck 
} from 'lucide-react';

interface Props {
  language: Language;
  dialect?: string;
  onLanguageChange: (lang: Language, dialect?: string) => void;
  userXP: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  liteMode: boolean;
  onToggleLiteMode: () => void;
  onOpenCertificate: () => void;
  onOpenAbout: () => void;
  onResetProgress: () => void;
}

export const Header: React.FC<Props> = ({
  language,
  dialect,
  onLanguageChange,
  userXP,
  soundEnabled,
  onToggleSound,
  liteMode,
  onToggleLiteMode,
  onOpenCertificate,
  onOpenAbout,
  onResetProgress,
}) => {
  const t = i18n[language];
  const activeDialect = dialect || language;
  const dialectInfo = arabicDialects[activeDialect] || arabicDialects.ar;
  const levelData = calculateLevel(userXP);

  return (
    <header className="bg-[#070b14] border-b border-slate-800/80 sticky top-0 z-40 px-4 py-2.5 shadow-xl select-none">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Crest */}
        <div className="flex items-center gap-3">
          <div className="relative w-11 h-11 rounded-xl overflow-hidden border border-cyan-500/50 shadow-lg shadow-cyan-500/30 flex items-center justify-center bg-slate-950 shrink-0">
            <img 
              src="/assets/aistudio/IMG-20261112-WA4032_c81ca538.jpg" 
              alt="Tounsi Academy Logo" 
              className="w-full h-full object-cover"
            />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-base md:text-lg font-black tracking-wider text-white font-mono">
                {t.workshopTitle}
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-cyan-950 text-cyan-400 border border-cyan-800">
                NEXUS SIM ENGINE
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-2 text-[10px] text-slate-400 font-mono">
              <span className="text-orange-400 font-bold">
                {language === 'ar' ? dialectInfo.motto : t.tagline}
              </span>
              <span>•</span>
              <span className="text-slate-300 font-medium">By Saif Eddine Aloui</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">{t.palestineMotto}</span>
            </div>
          </div>
        </div>

        {/* User Level, XP Bar & Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* XP & Level Badge */}
          <div className="hidden md:flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-xl shadow-inner text-xs font-mono">
            <Award className="w-4 h-4 text-amber-400" />
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-white">Lvl {levelData.level}</span>
                <span className="text-cyan-400 font-bold">{userXP} XP</span>
              </div>
              <div className="w-24 bg-slate-800 h-1 rounded-full overflow-hidden mt-0.5">
                <div
                  className="bg-gradient-to-r from-cyan-400 to-orange-400 h-full rounded-full transition-all duration-300"
                  style={{ width: `${levelData.progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Certificate Trigger Button */}
          <button
            onClick={onOpenCertificate}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-orange-500/20 to-amber-500/20 hover:from-orange-500/30 hover:to-amber-500/30 border border-orange-500/50 text-orange-300 text-xs font-bold transition-all shadow-md active:scale-95"
            title={t.getCertificate}
          >
            <Award className="w-3.5 h-3.5 text-orange-400" />
            <span className="hidden sm:inline">{t.getCertificate}</span>
          </button>

          {/* Lite Mode Toggle for Low-End Devices */}
          <button
            onClick={onToggleLiteMode}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-mono font-medium transition-all border ${
              liteMode
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title={liteMode ? t.liteMode : t.full3DMode}
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{liteMode ? 'Lite' : '3D Max'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
            title={soundEnabled ? t.soundOn : t.soundOff}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-cyan-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {/* About / Privacy Policy Button */}
          <button
            onClick={onOpenAbout}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-emerald-400 hover:text-emerald-300 transition-colors"
            title={language === 'ar' ? 'حول التطبيق والخصوصية' : language === 'fr' ? 'À propos & Confidentialité' : 'About & Privacy'}
          >
            <ShieldCheck className="w-4 h-4" />
          </button>

          {/* Reset Progress Button */}
          <button
            onClick={onResetProgress}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-rose-950/50 border border-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
            title={t.resetProgress}
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Language & Dialects Switcher */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs font-mono font-bold">
            <Globe className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <select
              value={dialect || language}
              onChange={(e) => {
                const val = e.target.value;
                if (val === 'fr' || val === 'en' || val === 'ar') {
                  onLanguageChange(val as Language, undefined);
                } else {
                  onLanguageChange('ar', val);
                }
              }}
              className="bg-transparent text-slate-200 font-bold focus:outline-none cursor-pointer"
            >
              <option value="ar" className="bg-slate-900 text-white">العربية (الفصحى)</option>
              <option value="ar_tn" className="bg-slate-900 text-white">🇹🇳 اللهجة التونسية</option>
              <option value="ar_ps" className="bg-slate-900 text-white">🇵🇸 اللهجة الفلسطينية</option>
              <option value="ar_eg" className="bg-slate-900 text-white">🇪🇬 اللهجة المصرية</option>
              <option value="ar_ma" className="bg-slate-900 text-white">🇲🇦 اللهجة المغربية</option>
              <option value="ar_sa" className="bg-slate-900 text-white">🇸🇦 اللهجة الخليجية</option>
              <option value="ar_lb" className="bg-slate-900 text-white">🇱🇧 اللهجة الشامية</option>
              <option value="fr" className="bg-slate-900 text-white">🇫🇷 Français</option>
              <option value="en" className="bg-slate-900 text-white">🇬🇧 English</option>
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
