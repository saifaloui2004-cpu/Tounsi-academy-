/**
 * NEXUS WORKSHOP — Global Navigation Bar
 * Fast tab switching between Workshop Hub, 2D Studio, 3D Center, Thermal Oil, Faults, and Training.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React from 'react';
import { Language, EngineeringLabId } from '../../types';
import { i18n } from '../../i18n/translations';
import { sound } from '../../utils/audio';
import { 
  LayoutDashboard, CircuitBoard, Box, Flame, 
  AlertTriangle, BookOpen, ChevronRight, Zap, ShieldAlert, Cpu, Gauge, Trophy 
} from 'lucide-react';

export type MainTab = 'overview' | 'academy' | 'ai_tech' | 'hse' | '2d' | '3d' | 'thermal' | 'faults' | 'training' | 'plc_studio' | 'scada' | 'challenge' | 'lab_detail';

interface Props {
  activeTab: MainTab;
  onSelectTab: (tab: MainTab) => void;
  language: Language;
  selectedLabId: EngineeringLabId;
  onSelectLabId: (id: EngineeringLabId) => void;
}

export const Navigation: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  language,
  selectedLabId,
  onSelectLabId,
}) => {
  const t = i18n[language];

  const tabs = [
    { id: 'overview' as MainTab, label: t.navOverview, icon: LayoutDashboard },
    { id: 'academy' as MainTab, label: t.navAcademy, icon: BookOpen },
    { id: 'ai_tech' as MainTab, label: t.navAITech, icon: Zap },
    { id: 'hse' as MainTab, label: t.navHSE, icon: ShieldAlert },
    { id: 'challenge' as MainTab, label: language === 'ar' ? 'تحدي المهندس' : language === 'fr' ? 'Défi Arena' : 'Challenge Arena', icon: Trophy },
    { id: 'plc_studio' as MainTab, label: language === 'ar' ? 'منطق PLC' : language === 'fr' ? 'Automate PLC' : 'PLC Studio', icon: Cpu },
    { id: 'scada' as MainTab, label: language === 'ar' ? 'نظام SCADA' : language === 'fr' ? 'SCADA Usine' : 'SCADA Telemetry', icon: Gauge },
    { id: '2d' as MainTab, label: t.nav2DStudio, icon: CircuitBoard },
    { id: '3d' as MainTab, label: t.nav3DCenter, icon: Box },
    { id: 'thermal' as MainTab, label: t.navThermalOil, icon: Flame },
    { id: 'faults' as MainTab, label: t.navFaultCenter, icon: AlertTriangle },
    { id: 'training' as MainTab, label: t.navTraining, icon: BookOpen },
  ];

  return (
    <nav className="bg-[#090e19] border-b border-slate-800/80 px-4 py-2 select-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1.5 shrink-0">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => {
                  onSelectTab(tab.id);
                  sound.playRelayClick();
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/25 scale-[1.02]'
                    : 'bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
