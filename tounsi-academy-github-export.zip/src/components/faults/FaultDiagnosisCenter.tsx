/**
 * NEXUS WORKSHOP — Industrial Fault Diagnosis Center
 * Step-by-step mystery breakdown investigation with virtual test instruments,
 * hypothesis isolation, safety protocol enforcement, and scored evaluations.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState } from 'react';
import { FAULT_SCENARIOS } from '../../data/faultScenarios';
import { FaultScenario, Language } from '../../types';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  AlertTriangle, Wrench, Gauge, Activity, Thermometer, 
  CheckCircle2, XCircle, ShieldAlert, Award, ChevronRight, Eye, Volume2 
} from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
  solvedFaultIds: string[];
  onMarkFaultSolved: (id: string) => void;
}

export const FaultDiagnosisCenter: React.FC<Props> = ({
  language,
  onRewardXP,
  solvedFaultIds,
  onMarkFaultSolved,
}) => {
  const t = i18n[language];
  const [selectedFault, setSelectedFault] = useState<FaultScenario>(FAULT_SCENARIOS[0]);
  const [revealedMeasurements, setRevealedMeasurements] = useState<string[]>([]);
  const [selectedCauseId, setSelectedCauseId] = useState<string | null>(null);
  const [diagnosisSubmitted, setDiagnosisSubmitted] = useState<boolean>(false);
  const [activeSymptomTab, setActiveSymptomTab] = useState<'visual' | 'auditory' | 'thermal' | 'vibration'>('visual');

  const handleSelectFault = (scenario: FaultScenario) => {
    setSelectedFault(scenario);
    setRevealedMeasurements([]);
    setSelectedCauseId(null);
    setDiagnosisSubmitted(false);
    setActiveSymptomTab('visual');
    sound.playRelayClick();
  };

  const handleTakeMeasurement = (testPoint: string) => {
    if (!revealedMeasurements.includes(testPoint)) {
      setRevealedMeasurements((prev) => [...prev, testPoint]);
      sound.playBeep(920, 0.05);
    }
  };

  const handleSubmitDiagnosis = () => {
    if (!selectedCauseId) return;
    setDiagnosisSubmitted(true);
    const chosenCause = selectedFault.possibleCauses.find((c) => c.id === selectedCauseId);

    if (chosenCause?.isCorrect) {
      sound.playSuccess();
      onRewardXP(selectedFault.xpPoints);
      onMarkFaultSolved(selectedFault.id);
    } else {
      sound.playAlarm();
    }
  };

  const isSolved = solvedFaultIds.includes(selectedFault.id);
  const chosenCause = selectedFault.possibleCauses.find((c) => c.id === selectedCauseId);

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 gap-4 overflow-y-auto">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3.5 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-bold text-white flex items-center gap-2">
              {t.faultCenterTitle}
            </h1>
            <span className="text-[11px] text-slate-400 font-mono">
              Industrial Troubleshooting Missions • ISO 13849 & Root Cause Analysis (RCA)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs font-mono">
          <span className="text-slate-400">الأعطال المحلولة:</span>
          <span className="text-cyan-400 font-bold">{solvedFaultIds.length} / {FAULT_SCENARIOS.length}</span>
        </div>
      </div>

      {/* Main Grid: Scenario Selector (Left) + Mission Workspace (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Mystery Scenarios List */}
        <div className="lg:col-span-4 space-y-2">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            سجل بلاغات الأعطال الميدانية
          </h2>

          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {FAULT_SCENARIOS.map((scenario) => {
              const active = selectedFault.id === scenario.id;
              const solved = solvedFaultIds.includes(scenario.id);

              return (
                <div
                  key={scenario.id}
                  onClick={() => handleSelectFault(scenario)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    active
                      ? 'bg-slate-800/90 border-cyan-500/70 shadow-lg shadow-cyan-950/30'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        scenario.difficulty === 'Beginner'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : scenario.difficulty === 'Intermediate'
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                          : 'bg-orange-950 text-orange-400 border border-orange-800'
                      }`}
                    >
                      {scenario.difficulty}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-mono text-cyan-400 font-bold">
                      +{scenario.xpPoints} XP
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-slate-200 line-clamp-1 mb-1">
                    {scenario.title[language]}
                  </h3>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span className="truncate">{scenario.system[language]}</span>
                    {solved && (
                      <span className="text-emerald-400 font-bold flex items-center gap-1 shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5" /> تم الحل
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Mission Workbench */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5 shadow-xl">
          {/* Active Mission Header */}
          <div className="flex flex-wrap items-start justify-between gap-2 pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono text-[10px] uppercase">
                  {selectedFault.system[language]}
                </span>
                <span className="text-xs font-mono text-slate-400">ID: {selectedFault.id}</span>
              </div>
              <h2 className="text-base font-bold text-white mt-1">
                {selectedFault.title[language]}
              </h2>
            </div>

            {isSolved && (
              <span className="px-3 py-1 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 text-xs font-bold flex items-center gap-1.5 shadow-md">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                تم حل العطل بنجاح
              </span>
            )}
          </div>

          {/* 1. Problem Description / Operator Complaint */}
          <div className="bg-slate-950/70 rounded-xl p-3.5 border border-slate-800/80 space-y-1">
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              {t.operatorReport}
            </span>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {selectedFault.initialReport[language]}
            </p>
          </div>

          {/* 2. Observed Symptoms (Tabs) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">
                الأعراض المرصودة في الميدان:
              </span>
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                {(['visual', 'auditory', 'thermal', 'vibration'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveSymptomTab(tab)}
                    className={`px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
                      activeSymptomTab === tab
                        ? 'bg-cyan-500 text-black font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tab === 'visual' && 'بصرية'}
                    {tab === 'auditory' && 'صوتية'}
                    {tab === 'thermal' && 'حرارية'}
                    {tab === 'vibration' && 'اهتزازية'}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800/60 text-xs text-slate-300 min-h-[48px] flex items-center">
              {activeSymptomTab === 'visual' && (
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{selectedFault.symptoms.visual[language]}</span>
                </div>
              )}
              {activeSymptomTab === 'auditory' && (
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{selectedFault.symptoms.auditory[language]}</span>
                </div>
              )}
              {activeSymptomTab === 'thermal' && (
                <div className="flex items-center gap-2">
                  <Thermometer className="w-4 h-4 text-orange-400 shrink-0" />
                  <span>{selectedFault.symptoms.thermal[language]}</span>
                </div>
              )}
              {activeSymptomTab === 'vibration' && (
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>{selectedFault.symptoms.vibration[language]}</span>
                </div>
              )}
            </div>
          </div>

          {/* 3. Interactive Virtual Measurements */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-cyan-400" />
                {t.takeVirtualMeasurement}
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                اضغط على نقطة الفحص لتشغيل أداة القياس
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {selectedFault.virtualMeasurements.map((m, idx) => {
                const isRevealed = revealedMeasurements.includes(m.testPoint);

                return (
                  <div
                    key={idx}
                    onClick={() => handleTakeMeasurement(m.testPoint)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isRevealed
                        ? 'bg-slate-950 border-cyan-500/50'
                        : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-300">{m.testPoint}</span>
                      <span className="text-[10px] font-mono text-cyan-400 uppercase">
                        [{m.tool}]
                      </span>
                    </div>

                    {isRevealed ? (
                      <div className="space-y-0.5 pt-1 border-t border-slate-800 font-mono text-xs">
                        <div className="text-cyan-300 font-bold flex items-center justify-between">
                          <span>القياس الفعلي:</span>
                          <span>{m.reading}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 flex items-center justify-between">
                          <span>النطاق الطبيعي:</span>
                          <span>{m.normalRange}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-500 font-mono flex items-center justify-between pt-1">
                        <span>انقر لأخذ القياس...</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* 4. Root Cause Hypothesis Picker */}
          <div className="space-y-2.5 pt-2 border-t border-slate-800">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-orange-400" />
              {t.selectProbableCause}
            </span>

            <div className="space-y-2">
              {selectedFault.possibleCauses.map((cause) => {
                const isSelected = selectedCauseId === cause.id;

                return (
                  <div
                    key={cause.id}
                    onClick={() => {
                      if (!diagnosisSubmitted) setSelectedCauseId(cause.id);
                    }}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-cyan-950/40 border-cyan-400 shadow-md'
                        : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                          isSelected ? 'border-cyan-400 bg-cyan-400' : 'border-slate-600'
                        }`}
                      >
                        {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                      </div>
                      <span className="text-xs text-slate-200 font-medium">
                        {cause.text[language]}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {!diagnosisSubmitted && (
              <button
                onClick={handleSubmitDiagnosis}
                disabled={!selectedCauseId}
                className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg ${
                  selectedCauseId
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-cyan-500/20 active:scale-98'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {t.submitDiagnosis}
              </button>
            )}
          </div>

          {/* 5. Diagnostic Outcome & Detailed Feedback (Shown after attempt) */}
          {diagnosisSubmitted && chosenCause && (
            <div
              className={`p-4 rounded-xl border space-y-3 ${
                chosenCause.isCorrect
                  ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-200'
                  : 'bg-rose-950/50 border-rose-500/50 text-rose-200'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-sm">
                {chosenCause.isCorrect ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>تشخيص دقيق وناجح! استحققت +{selectedFault.xpPoints} XP</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-rose-400" />
                    <span>تشخيص غير دقيق — راجع التفسير الهندسي أدناه</span>
                  </>
                )}
              </div>

              <p className="text-xs leading-relaxed font-sans">
                {chosenCause.explanation[language]}
              </p>

              {/* Show solution and diagnostic steps if correct */}
              {chosenCause.isCorrect && (
                <div className="space-y-2 pt-2 border-t border-emerald-800/60">
                  <div className="text-xs font-bold text-emerald-300">
                    خطوات المعالجة والإصلاح المعتمدة:
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-xs text-slate-300">
                    {selectedFault.diagnosticSteps.map((step, sIdx) => (
                      <li key={sIdx}>{step[language]}</li>
                    ))}
                  </ol>
                  <div className="pt-2">
                    <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-amber-400" />
                      {t.safetyProtocol}:
                    </span>
                    <p className="text-xs text-amber-200/90 mt-0.5">
                      {selectedFault.safetyRule[language]}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
