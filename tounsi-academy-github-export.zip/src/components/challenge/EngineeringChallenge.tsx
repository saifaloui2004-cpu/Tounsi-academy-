/**
 * NEXUS TOUNSI — Global Engineering Challenge & Timed Troubleshooting Arena
 * Timed engineering quizzes, rapid fault identification, and global leaderboard.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState, useEffect } from 'react';
import { Language } from '../../types';
import { i18n } from '../../i18n/translations';
import { sound } from '../../utils/audio';
import { Trophy, Timer, Award, Zap, CheckCircle2, XCircle, RotateCcw, Flame, Target } from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (amount: number) => void;
}

interface ChallengeQuestion {
  id: string;
  question: { ar: string; fr: string; en: string };
  options: { ar: string[]; fr: string[]; en: string[] };
  correctIndex: number;
  explanation: { ar: string; fr: string; en: string };
  xp: number;
}

const challengeQuestions: ChallengeQuestion[] = [
  {
    id: 'ch_1',
    question: {
      ar: 'ما هو سبب ارتفاع حرارة محرك حثي ثلاثي الأطوار بشكل غير طبيعي مع صدور طنين كهربائي؟',
      fr: 'Quelle est la cause d’une surchauffe anormale d’un moteur asynchrone triphasé accompagnée d’un bourdonnement?',
      en: 'What is the cause of abnormal heating and humming in a 3-phase induction motor?',
    },
    options: {
      ar: ['فقدان أحد الأطوار (Single Phasing)', 'زيادة الفولتية بنسبة 2%', 'برودة جوية شديدة', 'تلف مروحة التبريد فقط'],
      fr: ['Fonctionnement sur deux phases (Single Phasing)', 'Hausse de tension de 2%', 'Froid intense', 'Panne du ventilateur'],
      en: ['Single phasing (loss of one phase)', '2% voltage increase', 'Extreme cold', 'Cooling fan failure'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'فقدان أحد الأطوار يتسبب في سحب تيار هائل في الملفات المتبقية مما يؤدي لسخونة سريعة واحتراق.',
      fr: 'Le fonctionnement sur deux phases provoque un appel de courant excessif et une surchauffe rapide.',
      en: 'Loss of one phase causes unbalanced high current in remaining windings, leading to rapid overheating.',
    },
    xp: 50,
  },
  {
    id: 'ch_2',
    question: {
      ar: 'في صمامات الأتمتة الهيدروليكية، ماذا يعبر الرمز 4/3؟',
      fr: 'Dans les systèmes hydrauliques, que signifie un distributeur 4/3?',
      en: 'In hydraulic valves, what does 4/3 designation mean?',
    },
    options: {
      ar: ['4 فتحات (Ports) و 3 وضعيات تشغيل', '4 ضغوط و 3 مضخات', '4 مراحل و 3 صمامات أمان', '4 أسطوانات و 3 فلاتر'],
      fr: ['4 orifices et 3 positions', '4 pressions et 3 pompes', '4 étages et 3 clapets', '4 vérins et 3 filtres'],
      en: ['4 ports and 3 operating positions', '4 pressures and 3 pumps', '4 stages and 3 safety valves', '4 cylinders and 3 filters'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'الرمز 4/3 يعني أن الصمام يمتلك 4 فتحات توصيل رئيسية و 3 وضعيات تحكم مختلفة.',
      fr: 'Le code 4/3 indique 4 voies de raccordement et 3 positions de commutation.',
      en: '4/3 means 4 ports (working lines) and 3 distinct spool positions.',
    },
    xp: 50,
  },
  {
    id: 'ch_3',
    question: {
      ar: 'ما هو الهدف الأساسي من تركيب خزان التمدد (Expansion Tank) في منظومة الزيت الحراري؟',
      fr: 'Quel est le rôle principal du vase d’expansion dans une installation d’huile thermique?',
      en: 'What is the primary role of an expansion tank in a thermal oil installation?',
    },
    options: {
      ar: ['استيعاب التمدد الحراري للزيت ومنع دخول الهواء والرطوبة', 'تبريد الزيت لدرجة حرارة الغرفة فوراً', 'زيادة ضغط الشبكة إلى 50 بار', 'تصفية الرواسب الصلبة الكبيرة'],
      fr: ['Absorber la dilatation thermique de l’huile et empêcher l’air', 'Refroidir l’huile instantanément', 'Augmenter la pression à 50 bar', 'Filtrer les gros sédiments'],
      en: ['Absorb thermal oil expansion and prevent air/moisture ingress', 'Cool oil to room temp instantly', 'Boost system pressure to 50 bar', 'Filter large solid sediments'],
    },
    correctIndex: 0,
    explanation: {
      ar: 'خزان التمدد يستوعب التغير في حجم الزيت نتيجة التسخين، ويحمي الزيت من الأكسدة والرطوبة.',
      fr: 'Le vase d’expansion absorbe la variation de volume due à la chaleur et protège de l’oxydation.',
      en: 'The expansion tank accommodates oil volume changes with temperature and protects against oxidation.',
    },
    xp: 50,
  },
];

export const EngineeringChallenge: React.FC<Props> = ({ language, onRewardXP }) => {
  const t = i18n[language];
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [gameOver, setGameOver] = useState<boolean>(false);

  useEffect(() => {
    let timer: any;
    if (!gameOver && !isAnswered && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((t) => t - 1);
      }, 1000);
    } else if (timeLeft === 0 && !isAnswered) {
      setIsAnswered(true);
      sound.playError();
    }
    return () => clearInterval(timer);
  }, [timeLeft, isAnswered, gameOver]);

  const currentQ = challengeQuestions[currentIndex];

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    if (idx === currentQ.correctIndex) {
      setScore((s) => s + 1);
      onRewardXP(currentQ.xp);
      sound.playSuccess();
    } else {
      sound.playError();
    }
  };

  const handleNext = () => {
    if (currentIndex < challengeQuestions.length - 1) {
      setCurrentIndex((i) => i + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setTimeLeft(30);
      sound.playRelayClick();
    } else {
      setGameOver(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setScore(0);
    setIsAnswered(false);
    setTimeLeft(30);
    setGameOver(false);
    sound.playRelayClick();
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-4xl mx-auto px-4">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-orange-950 to-slate-900 border border-orange-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-orange-400 font-mono text-xs uppercase tracking-wider mb-2">
              <Trophy className="w-4 h-4" />
              <span>NEXUS WORLD CHALLENGE & TIMED TROUBLESHOOTING</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white">
              {language === 'ar' ? 'تحدي المهندس العالمي وحل الأعطال السريع' : language === 'fr' ? 'Défi Mondial de l’Ingénieur & Dépannage Rapide' : 'Global Engineer Challenge & Timed Troubleshooting'}
            </h2>
            <p className="text-slate-300 text-sm mt-1">
              {language === 'ar'
                ? 'اختبر سرعة بديهتك الهندسية ومعرفتك الصناعية تحت ضغط الوقت مع جوائز XP فورية.'
                : 'Test your engineering intuition and industrial knowledge under time pressure with instant XP rewards.'}
            </p>
          </div>
          <div className="flex items-center gap-4 bg-slate-950/80 px-4 py-3 rounded-2xl border border-orange-500/30">
            <Timer className={`w-6 h-6 ${timeLeft <= 10 ? 'text-rose-400 animate-pulse' : 'text-orange-400'}`} />
            <div>
              <div className="text-[10px] font-mono text-slate-400 uppercase">TIME REMAINING</div>
              <div className="text-xl font-black font-mono text-white">{timeLeft}s</div>
            </div>
          </div>
        </div>
      </div>

      {!gameOver ? (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase">
              Question {currentIndex + 1} of {challengeQuestions.length}
            </span>
            <span className="px-3 py-1 bg-orange-500/20 text-orange-400 text-xs font-mono rounded-full border border-orange-500/30">
              +{currentQ.xp} XP
            </span>
          </div>

          <h3 className="text-lg md:text-xl font-bold text-white leading-relaxed">{currentQ.question[language]}</h3>

          {/* Options Grid */}
          <div className="space-y-3">
            {currentQ.options[language].map((opt, idx) => {
              let btnStyle = 'bg-slate-950/80 hover:bg-slate-800 border-slate-800 text-slate-200';
              if (isAnswered) {
                if (idx === currentQ.correctIndex) {
                  btnStyle = 'bg-emerald-950/40 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-500/10';
                } else if (idx === selectedOption) {
                  btnStyle = 'bg-rose-950/40 border-rose-500 text-rose-300';
                } else {
                  btnStyle = 'bg-slate-950/40 border-slate-900 text-slate-600 opacity-50';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={isAnswered}
                  className={`w-full text-start p-4 rounded-2xl border transition-all flex items-center justify-between ${btnStyle}`}
                >
                  <span className="text-sm font-medium">{opt}</span>
                  {isAnswered && idx === currentQ.correctIndex && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                  {isAnswered && idx === selectedOption && idx !== currentQ.correctIndex && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Explanation if answered */}
          {isAnswered && (
            <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3 animate-fadeIn">
              <div className="text-xs font-mono font-bold text-orange-400">ENGINEERING EXPLANATION:</div>
              <p className="text-xs text-slate-300 leading-relaxed">{currentQ.explanation[language]}</p>
              <button
                onClick={handleNext}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-black font-black rounded-xl transition-all shadow-lg shadow-orange-500/25 mt-2"
              >
                {currentIndex < challengeQuestions.length - 1 ? (language === 'ar' ? 'السؤال التالي ←' : 'Next Question →') : (language === 'ar' ? 'عرض النتيجة النهائية 🏆' : 'View Final Score 🏆')}
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Game Over Scorecard */
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-8 text-center space-y-6 shadow-xl animate-fadeIn">
          <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-amber-600 rounded-3xl mx-auto flex items-center justify-center shadow-lg shadow-orange-500/30">
            <Trophy className="w-10 h-10 text-black" />
          </div>

          <div>
            <h3 className="text-2xl md:text-3xl font-black text-white">
              {language === 'ar' ? 'انتهى التحدي بنجاح تام!' : 'Challenge Completed Successfully!'}
            </h3>
            <p className="text-slate-400 text-sm mt-1">
              {language === 'ar' ? 'أداء ممتاز في اختبار التشخيص الهندسي السريع.' : 'Outstanding performance in rapid engineering troubleshooting.'}
            </p>
          </div>

          <div className="inline-flex items-center gap-6 bg-slate-950/80 px-8 py-4 rounded-2xl border border-slate-800">
            <div>
              <div className="text-xs font-mono text-slate-400">FINAL SCORE</div>
              <div className="text-3xl font-black text-emerald-400">{score} / {challengeQuestions.length}</div>
            </div>
            <div className="w-px h-10 bg-slate-800"></div>
            <div>
              <div className="text-xs font-mono text-slate-400">XP EARNED</div>
              <div className="text-3xl font-black text-orange-400">+{score * 50} XP</div>
            </div>
          </div>

          <div>
            <button
              onClick={handleRestart}
              className="flex items-center justify-center gap-2 px-6 py-3.5 bg-cyan-500 hover:bg-cyan-600 text-black font-bold rounded-2xl transition-all shadow-lg shadow-cyan-500/25 mx-auto"
            >
              <RotateCcw className="w-5 h-5" />
              <span>{language === 'ar' ? 'إعادة التحدي' : 'Play Again'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
