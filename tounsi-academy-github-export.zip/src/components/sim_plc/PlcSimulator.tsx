/**
 * NEXUS TOUNSI — Advanced PLC Ladder Logic Simulator
 * Siemens TIA Portal & RSLogix inspired industrial PLC training module.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState, useEffect, useRef } from 'react';
import { Language } from '../../types';
import { sound } from '../../utils/audio';
import { Play, Square, RefreshCw, Cpu, Activity, Terminal, Zap } from 'lucide-react';

interface Props {
  language: Language;
}

interface PlcRung {
  id: number;
  label: string;
  condition: string;
  output: string;
  isEnergized: boolean;
  description: { ar: string; fr: string; en: string };
}

export const PlcSimulator: React.FC<Props> = ({ language }) => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [inputs, setInputs] = useState({
    startBtn: false,
    stopBtn: true, // NC normally closed
    sensorProx: false,
    thermalTrip: false,
    emergencyStop: false,
  });
  const [outputs, setOutputs] = useState({
    motorRunning: false,
    conveyorBelt: false,
    alarmLamp: false,
    solenoidValve: false,
  });
  const [timerValue, setTimerValue] = useState<number>(0);
  const [selectedExample, setSelectedExample] = useState<'motor' | 'conveyor' | 'timer'>('motor');

  const inputsRef = useRef(inputs);
  const outputsRef = useRef(outputs);
  const exampleRef = useRef(selectedExample);

  useEffect(() => {
    inputsRef.current = inputs;
  }, [inputs]);

  useEffect(() => {
    outputsRef.current = outputs;
  }, [outputs]);

  useEffect(() => {
    exampleRef.current = selectedExample;
  }, [selectedExample]);

  // PLC scan cycle simulation (200ms cycle, edge-triggered audio)
  useEffect(() => {
    if (!isRunning) {
      setOutputs({
        motorRunning: false,
        conveyorBelt: false,
        alarmLamp: false,
        solenoidValve: false,
      });
      setTimerValue(0);
      return;
    }

    const interval = setInterval(() => {
      const inp = inputsRef.current;
      const prevOut = outputsRef.current;

      let nextMotor = prevOut.motorRunning;
      let nextAlarm = prevOut.alarmLamp;

      if (inp.emergencyStop || inp.thermalTrip) {
        nextMotor = false;
        nextAlarm = true;
      } else if (!inp.stopBtn) {
        nextMotor = false;
        nextAlarm = false;
      } else {
        nextAlarm = false;
        if (inp.startBtn) {
          nextMotor = true;
        }
      }

      if (nextMotor !== prevOut.motorRunning) {
        sound.playRelayClick();
      }

      setTimerValue((tv) => {
        const nextTv = nextMotor ? Math.min(tv + 2, 30) : 0; // 200ms * 15 ticks = 3.0s (30 ticks of 0.1s)
        const timerDone = nextTv >= 30;
        const convActive =
          exampleRef.current === 'conveyor'
            ? nextMotor && (timerDone || inp.sensorProx)
            : exampleRef.current === 'timer'
            ? nextMotor && timerDone
            : nextMotor;

        setOutputs({
          motorRunning: nextMotor,
          conveyorBelt: convActive,
          alarmLamp: nextAlarm,
          solenoidValve: nextMotor && (exampleRef.current !== 'conveyor' || inp.sensorProx),
        });
        return nextTv;
      });
    }, 200);

    return () => clearInterval(interval);
  }, [isRunning]);

  const rungs: PlcRung[] = [
    {
      id: 1,
      label: 'RUNG 0001 — START / STOP LATCHING',
      condition: 'I:0.0 (START) + I:0.1 (STOP_NC) + Q:0.0 (LATCH)',
      output: 'Q:0.0 (MAIN CONTACTOR)',
      isEnergized: outputs.motorRunning,
      description: {
        ar: 'دائرة إقلاع وتثبيت المحرك الرئيسية (Start/Stop Latching Circuit)',
        fr: 'Circuit de démarrage et auto-maintien du contacteur principal',
        en: 'Main motor start/stop latching circuit with normally closed stop protection',
      },
    },
    {
      id: 2,
      label: selectedExample === 'conveyor' ? 'RUNG 0002 — PROXIMITY + TON CONVEYOR' : 'RUNG 0002 — TON TIMER DELAY',
      condition:
        selectedExample === 'conveyor'
          ? 'Q:0.0 (RUNNING) + I:0.2 (PROX) -> Q:0.1 (CONV)'
          : 'Q:0.0 (RUNNING) -> TON T1 (3.0s)',
      output: 'T1.DN (CONVEYOR START)',
      isEnergized: timerValue >= 30 || (selectedExample === 'conveyor' && outputs.conveyorBelt),
      description: {
        ar: 'مؤقت تشغيل متأخر TON لتشغيل سير النقل بعد بدء المحرك بـ 3 ثوانٍ',
        fr: 'Temporisation TON pour démarrage du convoyeur après 3 secondes',
        en: 'TON Timer delay starting conveyor belt 3 seconds after motor start',
      },
    },
    {
      id: 3,
      label: 'RUNG 0003 — THERMAL & E-STOP FAULT',
      condition: 'I:0.3 (THERMAL) OR I:0.4 (E-STOP)',
      output: 'Q:0.2 (ALARM LAMP & SHUTDOWN)',
      isEnergized: inputs.thermalTrip || inputs.emergencyStop,
      description: {
        ar: 'حماية الحمل الزائد وإيقاف الطوارئ لتفعيل مصباح الإنذار وقطع الطاقة',
        fr: 'Protection thermique et arrêt d’urgence pour activation du voyant d’alarme',
        en: 'Thermal overload and emergency stop circuit triggering alarm lamp & trip',
      },
    },
  ];

  return (
    <div className="space-y-6 animate-fadeIn pb-12 px-4 pt-4 overflow-y-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 font-mono text-xs uppercase tracking-wider mb-2">
              <Cpu className="w-4 h-4" />
              <span>TOUNSI ACADEMY • NEXUS PLC STUDIO IEC 61131-3</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white">
              {language === 'ar' ? 'محاكي الأتمتة الصناعية ومنطق السلم (PLC)' : language === 'fr' ? 'Simulateur API & Logique Ladder' : 'Industrial PLC & Ladder Logic Simulator'}
            </h2>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              {language === 'ar'
                ? 'محاكاة حية لوحدات التحكم القابلة للبرمجة (PLC) مع المداخل، المخارج، المؤقتات TON، ومنطق السلم الصناعي.'
                : language === 'fr'
                ? 'Simulation en temps réel d’automate programmable industriel (API) avec entrées, sorties et temporisateurs TON.'
                : 'Real-time programmable logic controller (PLC) simulation with digital I/O, TON timers, and ladder logic execution.'}
            </p>
            {/* Example Program Selector */}
            <div className="flex flex-wrap items-center gap-2 mt-3">
              {(['motor', 'timer', 'conveyor'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => {
                    setSelectedExample(mode);
                    sound.playRelayClick();
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-mono font-bold border transition-all ${
                    selectedExample === mode
                      ? 'bg-indigo-500 text-white border-indigo-400'
                      : 'bg-slate-900/80 text-slate-400 border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {mode === 'motor' && (language === 'ar' ? 'برنامج: إقلاع محرك' : 'Mode: DOL Motor')}
                  {mode === 'timer' && (language === 'ar' ? 'برنامج: مؤقت TON' : 'Mode: TON Delay')}
                  {mode === 'conveyor' && (language === 'ar' ? 'برنامج: خط سير وحساس' : 'Mode: Conveyor + Sensor')}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setIsRunning(!isRunning);
                sound.playRelayClick();
              }}
              className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold shadow-lg transition-all ${
                isRunning
                  ? 'bg-amber-500 hover:bg-amber-600 text-black shadow-amber-500/30'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-black shadow-emerald-500/30'
              }`}
            >
              {isRunning ? <Square className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
              <span>{isRunning ? (language === 'ar' ? 'إيقاف المحاكاة' : 'Stop PLC') : (language === 'ar' ? 'تشغيل PLC' : 'Run PLC')}</span>
            </button>
            <button
              onClick={() => {
                setInputs({ startBtn: false, stopBtn: true, sensorProx: false, thermalTrip: false, emergencyStop: false });
                setIsRunning(false);
                setTimerValue(0);
                sound.playRelayClick();
              }}
              className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl border border-slate-700 transition-all"
              title="Reset PLC"
            >
              <RefreshCw className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Control Panel & Ladder Rungs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Virtual I/O Panel */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Terminal className="w-5 h-5 text-indigo-400" />
            <span>{language === 'ar' ? 'لوحة المداخل والمخارج (I/O)' : language === 'fr' ? 'Tableau Entrées / Sorties' : 'Virtual I/O Control Panel'}</span>
          </h3>

          {/* Digital Inputs */}
          <div className="space-y-3">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
              {language === 'ar' ? 'المداخل الرقمية (Digital Inputs)' : 'Digital Inputs (DI)'}
            </span>

            {/* Start Button */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div>
                <div className="text-sm font-bold text-white">I:0.0 — START Push Button</div>
                <div className="text-xs text-slate-400">Normally Open (NO)</div>
              </div>
              <button
                onMouseDown={() => setInputs((p) => ({ ...p, startBtn: true }))}
                onMouseUp={() => setInputs((p) => ({ ...p, startBtn: false }))}
                onTouchStart={() => setInputs((p) => ({ ...p, startBtn: true }))}
                onTouchEnd={() => setInputs((p) => ({ ...p, startBtn: false }))}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  inputs.startBtn ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/30' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {inputs.startBtn ? 'PRESSED' : 'HOLD TO START'}
              </button>
            </div>

            {/* Stop Button */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div>
                <div className="text-sm font-bold text-white">I:0.1 — STOP Push Button</div>
                <div className="text-xs text-slate-400">Normally Closed (NC)</div>
              </div>
              <button
                onClick={() => {
                  setInputs((p) => ({ ...p, stopBtn: !p.stopBtn }));
                  sound.playRelayClick();
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  inputs.stopBtn ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' : 'bg-rose-500/20 text-rose-400 border border-rose-500/50'
                }`}
              >
                {inputs.stopBtn ? 'CLOSED (OK)' : 'OPEN (TRIPPED)'}
              </button>
            </div>

            {/* Emergency Stop */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div>
                <div className="text-sm font-bold text-rose-400">I:0.4 — E-STOP Mushroom</div>
                <div className="text-xs text-slate-400">Emergency Safety Link</div>
              </div>
              <button
                onClick={() => {
                  setInputs((p) => ({ ...p, emergencyStop: !p.emergencyStop }));
                  sound.playRelayClick();
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  inputs.emergencyStop ? 'bg-rose-500 text-white animate-pulse' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {inputs.emergencyStop ? 'E-STOP ACTIVE' : 'NORMAL'}
              </button>
            </div>
          </div>

          {/* Digital Outputs Status */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
              {language === 'ar' ? 'المخارج الرقمية (Digital Outputs)' : 'Digital Outputs (DO)'}
            </span>

            <div className="grid grid-cols-2 gap-3">
              <div className={`p-3 rounded-2xl border ${outputs.motorRunning ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400' : 'bg-slate-950/60 border-slate-800 text-slate-500'}`}>
                <div className="text-xs font-mono font-bold">Q:0.0 MOTOR</div>
                <div className="text-sm font-bold mt-1">{outputs.motorRunning ? 'RUNNING' : 'OFF'}</div>
              </div>
              <div className={`p-3 rounded-2xl border ${outputs.conveyorBelt ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-400' : 'bg-slate-950/60 border-slate-800 text-slate-500'}`}>
                <div className="text-xs font-mono font-bold">Q:0.1 CONV</div>
                <div className="text-sm font-bold mt-1">{outputs.conveyorBelt ? 'ACTIVE' : 'IDLE'}</div>
              </div>
              <div className={`p-3 rounded-2xl border ${outputs.alarmLamp ? 'bg-rose-500/10 border-rose-500/50 text-rose-400 animate-pulse' : 'bg-slate-950/60 border-slate-800 text-slate-500'}`}>
                <div className="text-xs font-mono font-bold">Q:0.2 ALARM</div>
                <div className="text-sm font-bold mt-1">{outputs.alarmLamp ? 'TRIPPED' : 'NORMAL'}</div>
              </div>
              <div className={`p-3 rounded-2xl border ${timerValue > 0 ? 'bg-indigo-500/10 border-indigo-500/50 text-indigo-400' : 'bg-slate-950/60 border-slate-800 text-slate-500'}`}>
                <div className="text-xs font-mono font-bold">T1 TON TIMER</div>
                <div className="text-sm font-bold mt-1">{(timerValue * 0.1).toFixed(1)}s / 3.0s</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Ladder Logic Diagram Viewer */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-400" />
              <span>{language === 'ar' ? 'مخطط منطق السلم (Ladder Diagram)' : 'IEC 61131-3 Ladder Logic Rungs'}</span>
            </h3>
            <span className="px-3 py-1 bg-indigo-500/20 text-indigo-400 text-xs font-mono rounded-full border border-indigo-500/30">
              {isRunning ? 'RUNNING (CPU OK)' : 'STOPPED'}
            </span>
          </div>

          {/* Rungs List */}
          <div className="space-y-4">
            {rungs.map((rung) => (
              <div
                key={rung.id}
                className={`p-4 rounded-2xl border transition-all ${
                  rung.isEnergized
                    ? 'bg-emerald-950/20 border-emerald-500/50 shadow-lg shadow-emerald-500/10'
                    : 'bg-slate-950/60 border-slate-800/80'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-bold text-indigo-400">{rung.label}</span>
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${rung.isEnergized ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`}></span>
                    <span className="text-xs font-mono text-slate-300">{rung.output}</span>
                  </div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 font-mono text-xs text-amber-300 mb-2 overflow-x-auto">
                  --[ {rung.condition} ]---------------------------------( {rung.output} )--
                </div>

                <p className="text-xs text-slate-300">{rung.description[language]}</p>
              </div>
            ))}
          </div>

          <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 flex items-start gap-3">
            <Zap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-slate-300 leading-relaxed">
              {language === 'ar'
                ? 'ملاحظة تعليمية: يمثل منطق السلم (Ladder Logic) المعيار الصناعي العالمي لبرمجة وحدات PLC في مصانع الطاقة، السيارات، وخطوط الإنتاج.'
                : language === 'fr'
                ? 'Note pédagogique: La logique Ladder est le standard industriel mondial pour la programmation des automates programmables (API).'
                : 'Educational note: Ladder logic is the worldwide industrial standard for programming PLCs in manufacturing, power plants, and robotics.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
