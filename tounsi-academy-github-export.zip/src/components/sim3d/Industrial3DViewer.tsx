/**
 * NEXUS WORKSHOP — 3D Industrial Simulation Center
 * Implements high-fidelity procedural 3D equipment models:
 * Centrifugal Pump, 3-Phase Induction Motor, Thermal Boiler, and Gate Valve.
 * Complies with Three.js Skill (procedural parts, software-GL guard, collapsible bottom dock).
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Model3DType, Language } from '../../types';
import { i18n } from '../../i18n/translations';
import { sound } from '../../utils/audio';
import { 
  Box, Eye, Layers, Rotate3d, Compass, Maximize2, 
  ChevronUp, ChevronDown, Info, ShieldCheck, Flame
} from 'lucide-react';

interface Props {
  language: Language;
  liteMode?: boolean;
  onRewardXP: (xp: number) => void;
}

interface PartSpec {
  name: { ar: string; fr: string; en: string };
  material: string;
  function: { ar: string; fr: string; en: string };
  faults: { ar: string; fr: string; en: string };
}

const PART_SPECS: Record<string, PartSpec> = {
  volute_casing: {
    name: { ar: 'جسم الحلزونة الهيدروليكي (Volute Casing)', fr: 'Corps de Volute Fonte', en: 'Cast Iron Volute Casing' },
    material: 'Cast Iron EN-GJL-250 / Ductile Iron',
    function: {
      ar: 'تحويل الطاقة الحركية للزيت إلى ضغط هيدروليكي منتظم وتوجيهه نحو مخرج الطرد.',
      fr: 'Convertit l’énergie cinétique de vitesse en pression statique vers le refoulement.',
      en: 'Converts fluid kinetic velocity into static pressure and guides flow to discharge flange.',
    },
    faults: {
      ar: 'تآكل بفعل التكهف Pitting، ترسب الشوائب الكلسية، وتشقق شفة التوصيل عند زيادة العزم.',
      fr: 'Érosion par cavitation, fissuration sous contrainte thermique et encrassement.',
      en: 'Cavitation pitting erosion, thermal shock cracking, and flange bolt overtorque.',
    },
  },
  impeller: {
    name: { ar: 'مروحة الدفع ذات الريش المنحنية (Impeller)', fr: 'Roue à Aubes Hélicoïdales', en: 'Curved Vane Impeller' },
    material: 'Stainless Steel AISI 316 / Bronze',
    function: {
      ar: 'توليد قوة الطرد المركزي ونقل الطاقة الميكانيكية للعمود إلى ذرات السائل الدوار.',
      fr: 'Transmet l’énergie mécanique de l’arbre au fluide sous force centrifuge.',
      en: 'Imparts centrifugal acceleration and kinetic head directly into the fluid medium.',
    },
    faults: {
      ar: 'انكسار الريش، عدم الاتزان الديناميكي Dynamic Unbalance، وانسداد المجاري بالألياف.',
      fr: 'Déséquilibre dynamique, rupture d’aube et colmatage par matières fibreuses.',
      en: 'Dynamic unbalance, blade tip erosion, and cavitation micro-jet perforation.',
    },
  },
  shaft: {
    name: { ar: 'عمود الإدارة الفولاذي (Pump Shaft)', fr: 'Arbre de Transmission Rectifié', en: 'Precision Ground Drive Shaft' },
    material: 'Forged Chrome-Nickel Alloy Steel (42CrMo4)',
    function: {
      ar: 'نقل عزم الدوران من المحرك الكهربائي إلى المروحة الدوارة بسرعة تصل إلى 2900 RPM.',
      fr: 'Transmet le couple moteur à la roue avec une tolérance de battement minimale.',
      en: 'Transmits drive torque from motor coupling to impeller at speeds up to 2900 RPM.',
    },
    faults: {
      ar: 'انحناء ميكانيكي (Shaft Runout > 0.03mm)، تآكل مقاعد كراسي التحميل، وكسر الإجهاد الدوري.',
      fr: 'Fléchissement plastique, usure des portées de roulement et fatigue torsionnelle.',
      en: 'Rotational runout eccentricity, bearing journal fretting, and torsional fatigue shear.',
    },
  },
  mech_seal: {
    name: { ar: 'حشوة منع التسرب الميكانيكية (Mechanical Seal)', fr: 'Garniture Mécanique d’Étanchéité', en: 'Cartridge Mechanical Face Seal' },
    material: 'Silicon Carbide (SiC) / Tungsten Carbide faces',
    function: {
      ar: 'منع تسرب السائل الساخن على طول العمود ومنع دخول الهواء إلى غرفة السحب.',
      fr: 'Empêche la fuite du fluide caloporteur le long de l’arbre en rotation.',
      en: 'Prevents high-temperature fluid egress along rotating shaft into the atmosphere.',
    },
    faults: {
      ar: 'تشقق الأسطح الاحتكاكية بالحرارة الجافة Dry Running، تيبس الحلقات المطاطية O-Rings.',
      fr: 'Fonctionnement à sec, dégradation des élastomères et rayures micrométriques.',
      en: 'Dry running thermal shock fractures, O-ring hardening, and spring crystallization.',
    },
  },
  bearing_pedestal: {
    name: { ar: 'كتلة كراسي التحميل (Bearing Housing)', fr: 'Corps de Paliers et Chambre d’Huile', en: 'Bearing Housing & Oil Sump' },
    material: 'Cast Steel ASTM A216 WCB',
    function: {
      ar: 'تثبيت عمود المضخة بدقة وامتصاص القوى المحورية والشعاعية مع تبريد الشحم والزيت.',
      fr: 'Maintient le guidage rigide de l’arbre et dissipe la chaleur des roulements.',
      en: 'Provides rigid axial and radial shaft guidance and houses lubrication bath.',
    },
    faults: {
      ar: 'تلوث زيت التزييت بالماء، سخونة مفرطة، وفقدان الخلوص الشعاعي الداخلي.',
      fr: 'Contamination du lubrifiant, surchauffe et perte de jeu radial.',
      en: 'Lubricant moisture contamination, high bearing temper, and outer ring spinning.',
    },
  },
  motor_stator: {
    name: { ar: 'جسم العضو الساكن والزعانف (Stator Casing)', fr: 'Carcasse Statorique Rainurée', en: 'Stator Ribbed Cast Frame' },
    material: 'Grey Cast Iron / Extruded Aluminum',
    function: {
      ar: 'حمل الرقائق المغناطيسية الفولاذية وملفات النحاس الثلاثية مع تبديد الحرارة للحيز المحيط.',
      fr: 'Supporte le paquet de tôles magnétiques et enroulements cuivre triphasés.',
      en: 'Supports electromagnetic laminations and copper coils with convective cooling fins.',
    },
    faults: {
      ar: 'انهيار عزل الملفات بين الأطوار، سخونة مفرطة، وكسر أرجل التثبيت.',
      fr: 'Claquant d’isolement entre spires, surchauffe et rupture de patte de fixation.',
      en: 'Inter-turn winding insulation breakdown, stator iron hotspot, and mount cracking.',
    },
  },
  motor_rotor: {
    name: { ar: 'العضو الدوار قفص السنجاب (Squirrel Cage Rotor)', fr: 'Rotor à Cage d’Écureuil', en: 'Squirrel Cage Rotor Core' },
    material: 'Laminated Silicon Steel with Die-cast Copper/Aluminum Bars',
    function: {
      ar: 'توليد التيارات الحثية والمجال المغناطيسي الدوار لإنتاج عزم الدوران الميكانيكي.',
      fr: 'Génère le champ magnétique induit pour produire le couple électromécanique.',
      en: 'Generates induced electromagnetic field to produce shaft rotational torque.',
    },
    faults: {
      ar: 'كسر قضبان القفص Rotor Bar Crack، انحراف المحور، واحتكاك بالساكن Rotor-Stator Rub.',
      fr: 'Rupture de barre de cage, faux-rond et frottement contre le stator.',
      en: 'Broken rotor bar defect, dynamic unbalance, and air-gap eccentricity rub.',
    },
  },
  gearbox_casing: {
    name: { ar: 'علبة التروس الأفقية المنفصلة (Gearbox Split Casing)', fr: 'Carter Réducteur en Fonte', en: 'Cast Iron Split Gearbox Casing' },
    material: 'Ductile Cast Iron EN-GJS-400',
    function: {
      ar: 'احتواء تروس نقل الحركة وحوض زيت التزييت ISO VG 220 وامتصاص قوى التفاعل وردود الفعل.',
      fr: 'Renferme le train d’engrenages hélicoïdaux et le bain d’huile de lubrification.',
      en: 'Rigid housing supporting gear trains, bearing seats, and ISO VG 220 oil sump.',
    },
    faults: {
      ar: 'تسريب زيت الحشيات، تآكل سنون التروس Pitting، وتلوث الزيت برياش المعدن.',
      fr: 'Fuite aux plans de joint, usure par piqûres et surchauffe d’huile.',
      en: 'Gasket oil weeping, gear teeth micro-pitting, and wear debris contamination.',
    },
  },
  compressor_cylinder: {
    name: { ar: 'أسطوانة ضاغط الهواء بزعانف التبريد (Compressor Cylinder)', fr: 'Cylindre Compresseur à Ailettes', en: 'Finned Air Compressor Cylinder' },
    material: 'Cast Iron with Diamond-Honed Bore',
    function: {
      ar: 'ضغط الهواء الجوي في مرحلتين (Two-Stage) وتوليد ضغط 8-10 bar مع تبريد سطحي عالي.',
      fr: 'Compression volumétrique d’air atmosphérique en deux étages avec ailettes de convection.',
      en: 'Two-stage air compression to 8-10 bar with high-efficiency convective cooling fins.',
    },
    faults: {
      ar: 'تلف صمامات عدم الرجوع Reed Valves، تآكل شنابر المكبس Piston Rings، وترسب الكربون.',
      fr: 'Rupture de clapets d’aspiration/refoulement, usure des segments et cokéfaction.',
      en: 'Reed valve flutter fracture, piston ring blow-by, and cylinder bore scuffing.',
    },
  },
  heat_exchanger_shell: {
    name: { ar: 'غلاف المبادل الحراري الأنبوبي (Shell & Tube Vessel)', fr: 'Calandre d’Échangeur Tubulaire', en: 'Tubular Shell & Tube Pressure Vessel' },
    material: 'Carbon Steel SA-516 Gr.70 / Stainless Tubes',
    function: {
      ar: 'تبادل الطاقة الحرارية بين الزيت الساخن في الغلاف ومائع العملية المار داخل الأنابيب.',
      fr: 'Transfert thermique entre fluide primaire caloporteur et circuit secondaire.',
      en: 'Thermal energy transfer between shell-side heating oil and process tube-side fluid.',
    },
    faults: {
      ar: 'ترسب الأوساخ Fouling، انثقاب الأنابيب بسبب الصدمة الحرارية، وانسداد حواجز التوجيه Baffles.',
      fr: 'Entartrage, corrosion sous contrainte et perforation de tubes internes.',
      en: 'Tube fouling scaling, thermal stress cracking, and baffle vibration fretting.',
    },
  },
};

export const Industrial3DViewer: React.FC<Props> = ({ language, liteMode = false, onRewardXP }) => {
  const t = i18n[language];
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedModel, setSelectedModel] = useState<Model3DType>('centrifugal_pump');
  const [explodedRatio, setExplodedRatio] = useState<number>(0);
  const [cutaway, setCutaway] = useState<boolean>(false);
  const [showFlow, setShowFlow] = useState<boolean>(true);
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const [inspectedPart, setInspectedPart] = useState<PartSpec | null>(PART_SPECS.volute_casing);
  const [dockExpanded, setDockExpanded] = useState<boolean>(true);

  // Three.js mutable references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const partsListRef = useRef<{ mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3; partKey: string }[]>([]);
  const flowParticlesRef = useRef<THREE.Points | null>(null);
  const targetExplodeRef = useRef<number>(0);
  const isSoftwareGlRef = useRef<boolean>(false);
  const autoRotateRef = useRef<boolean>(false);
  const showFlowRef = useRef<boolean>(true);
  const onRewardXpRef = useRef(onRewardXP);

  useEffect(() => {
    onRewardXpRef.current = onRewardXP;
  }, [onRewardXP]);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  useEffect(() => {
    showFlowRef.current = showFlow;
  }, [showFlow]);

  // Update target explode ratio
  useEffect(() => {
    targetExplodeRef.current = explodedRatio;
  }, [explodedRatio]);

  // Build Procedural 3D Models
  const buildCurrentModel = useCallback((type: Model3DType, scene: THREE.Scene) => {
    // Remove previous model group
    if (modelGroupRef.current) {
      scene.remove(modelGroupRef.current);
      modelGroupRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
          else child.material.dispose();
        }
      });
      modelGroupRef.current = null;
    }
    if (flowParticlesRef.current) {
      scene.remove(flowParticlesRef.current);
      flowParticlesRef.current = null;
    }

    const group = new THREE.Group();
    partsListRef.current = [];

    // Shared realistic PBR materials
    const castIronMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a, // industrial dark blue
      metalness: 0.55,
      roughness: 0.35,
    });

    const polishedSteelMat = new THREE.MeshStandardMaterial({
      color: 0xd1d5db,
      metalness: 0.95,
      roughness: 0.15,
    });

    const bronzeMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.85,
      roughness: 0.25,
    });

    const rubberMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      metalness: 0.1,
      roughness: 0.8,
    });

    const copperMat = new THREE.MeshStandardMaterial({
      color: 0xb45309,
      metalness: 0.9,
      roughness: 0.2,
    });

    // 1. Centrifugal Pump Model
    if (type === 'centrifugal_pump') {
      // Volute Casing (Main body)
      const voluteGeo = new THREE.TorusGeometry(1.6, 0.75, 24, 48, Math.PI * 1.8);
      const voluteMesh = new THREE.Mesh(voluteGeo, castIronMat.clone());
      voluteMesh.position.set(0, 2.2, 0);
      voluteMesh.rotation.y = Math.PI / 2;
      group.add(voluteMesh);
      partsListRef.current.push({
        mesh: voluteMesh,
        basePos: voluteMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 1.8),
        partKey: 'volute_casing',
      });

      // Suction Inlet Flange
      const suctionGeo = new THREE.CylinderGeometry(0.7, 0.7, 1.2, 32);
      const suctionMesh = new THREE.Mesh(suctionGeo, castIronMat.clone());
      suctionMesh.rotation.x = Math.PI / 2;
      suctionMesh.position.set(0, 2.2, 1.5);
      group.add(suctionMesh);
      partsListRef.current.push({
        mesh: suctionMesh,
        basePos: suctionMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 3.2),
        partKey: 'volute_casing',
      });

      // Discharge Outlet Flange
      const dischargeGeo = new THREE.CylinderGeometry(0.55, 0.55, 1.4, 32);
      const dischargeMesh = new THREE.Mesh(dischargeGeo, castIronMat.clone());
      dischargeMesh.position.set(-1.4, 3.2, 0);
      group.add(dischargeMesh);
      partsListRef.current.push({
        mesh: dischargeMesh,
        basePos: dischargeMesh.position.clone(),
        explodeDir: new THREE.Vector3(-1.8, 2.2, 0),
        partKey: 'volute_casing',
      });

      // Impeller (Inside volute)
      const impellerGeo = new THREE.CylinderGeometry(1.15, 1.15, 0.35, 32);
      const impellerMesh = new THREE.Mesh(impellerGeo, bronzeMat);
      impellerMesh.rotation.x = Math.PI / 2;
      impellerMesh.position.set(0, 2.2, 0.2);
      group.add(impellerMesh);
      partsListRef.current.push({
        mesh: impellerMesh,
        basePos: impellerMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 0.8),
        partKey: 'impeller',
      });

      // Drive Shaft
      const shaftGeo = new THREE.CylinderGeometry(0.22, 0.22, 4.4, 32);
      const shaftMesh = new THREE.Mesh(shaftGeo, polishedSteelMat);
      shaftMesh.rotation.x = Math.PI / 2;
      shaftMesh.position.set(0, 2.2, -1.6);
      group.add(shaftMesh);
      partsListRef.current.push({
        mesh: shaftMesh,
        basePos: shaftMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, -1.5),
        partKey: 'shaft',
      });

      // Mechanical Seal Cartridge
      const sealGeo = new THREE.CylinderGeometry(0.48, 0.48, 0.5, 24);
      const sealMesh = new THREE.Mesh(sealGeo, polishedSteelMat.clone());
      sealMesh.rotation.x = Math.PI / 2;
      sealMesh.position.set(0, 2.2, -0.6);
      group.add(sealMesh);
      partsListRef.current.push({
        mesh: sealMesh,
        basePos: sealMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, -0.8),
        partKey: 'mech_seal',
      });

      // Bearing Pedestal Housing
      const pedestalGeo = new THREE.BoxGeometry(1.4, 1.6, 2.2);
      const pedestalMesh = new THREE.Mesh(pedestalGeo, castIronMat.clone());
      pedestalMesh.position.set(0, 1.5, -2.1);
      group.add(pedestalMesh);
      partsListRef.current.push({
        mesh: pedestalMesh,
        basePos: pedestalMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, -3.0),
        partKey: 'bearing_pedestal',
      });

      // Heavy Ground Baseplate Skid
      const baseplateGeo = new THREE.BoxGeometry(2.4, 0.4, 6.2);
      const baseplateMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.6, roughness: 0.4 });
      const baseplateMesh = new THREE.Mesh(baseplateGeo, baseplateMat);
      baseplateMesh.position.set(0, 0.2, -1.2);
      group.add(baseplateMesh);
    } 
    // 2. 3-Phase Induction Motor
    else if (type === 'induction_motor') {
      // Stator Ribbed Frame
      const statorGeo = new THREE.CylinderGeometry(1.6, 1.6, 3.2, 32);
      const statorMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.65, roughness: 0.3 });
      const statorMesh = new THREE.Mesh(statorGeo, statorMat);
      statorMesh.rotation.x = Math.PI / 2;
      statorMesh.position.set(0, 2.0, 0);
      group.add(statorMesh);
      partsListRef.current.push({
        mesh: statorMesh,
        basePos: statorMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 1.8, 0),
        partKey: 'motor_stator',
      });

      // Terminal Box (Boîte à bornes)
      const termBoxGeo = new THREE.BoxGeometry(0.9, 0.6, 0.9);
      const termBoxMesh = new THREE.Mesh(termBoxGeo, statorMat.clone());
      termBoxMesh.position.set(0, 3.8, -0.2);
      group.add(termBoxMesh);
      partsListRef.current.push({
        mesh: termBoxMesh,
        basePos: termBoxMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 3.2, 0),
        partKey: 'motor_stator',
      });

      // Rotor Core & Squirrel Cage Bars
      const rotorGeo = new THREE.CylinderGeometry(1.15, 1.15, 2.2, 32);
      const rotorMesh = new THREE.Mesh(rotorGeo, copperMat);
      rotorMesh.rotation.x = Math.PI / 2;
      rotorMesh.position.set(0, 2.0, 0);
      group.add(rotorMesh);
      partsListRef.current.push({
        mesh: rotorMesh,
        basePos: rotorMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 0),
        partKey: 'motor_rotor',
      });

      // Main Motor Shaft
      const shaftGeo = new THREE.CylinderGeometry(0.3, 0.3, 5.4, 32);
      const shaftMesh = new THREE.Mesh(shaftGeo, polishedSteelMat);
      shaftMesh.rotation.x = Math.PI / 2;
      shaftMesh.position.set(0, 2.0, 0.6);
      group.add(shaftMesh);
      partsListRef.current.push({
        mesh: shaftMesh,
        basePos: shaftMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 2.4),
        partKey: 'shaft',
      });

      // Cooling Fan & Cowl
      const fanGeo = new THREE.CylinderGeometry(1.4, 1.4, 0.8, 24);
      const fanMesh = new THREE.Mesh(fanGeo, rubberMat);
      fanMesh.rotation.x = Math.PI / 2;
      fanMesh.position.set(0, 2.0, -2.1);
      group.add(fanMesh);
      partsListRef.current.push({
        mesh: fanMesh,
        basePos: fanMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, -2.6),
        partKey: 'motor_stator',
      });

      // Motor Mounting Feet
      const foot1Geo = new THREE.BoxGeometry(0.4, 0.5, 2.6);
      const foot1 = new THREE.Mesh(foot1Geo, statorMat);
      foot1.position.set(-1.4, 0.5, 0);
      const foot2 = foot1.clone();
      foot2.position.set(1.4, 0.5, 0);
      group.add(foot1, foot2);
    } 
    // 3. Thermal Boiler Skid
    else if (type === 'thermal_boiler') {
      // Boiler Outer Jacket Cylinder
      const boilerGeo = new THREE.CylinderGeometry(1.5, 1.5, 4.2, 32);
      const boilerMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.3 });
      const boilerMesh = new THREE.Mesh(boilerGeo, boilerMat);
      boilerMesh.position.set(0, 2.5, 0);
      group.add(boilerMesh);
      partsListRef.current.push({
        mesh: boilerMesh,
        basePos: boilerMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 1.5, 0),
        partKey: 'volute_casing',
      });

      // Internal Helical Coils (Serpentin)
      const coilCurve = new THREE.CatmullRomCurve3(
        Array.from({ length: 40 }, (_, i) => {
          const t = i / 39;
          const angle = t * Math.PI * 14;
          const r = 1.0;
          return new THREE.Vector3(Math.cos(angle) * r, 0.8 + t * 3.4, Math.sin(angle) * r);
        })
      );
      const coilGeo = new THREE.TubeGeometry(coilCurve, 64, 0.12, 12, false);
      const coilMesh = new THREE.Mesh(coilGeo, bronzeMat);
      group.add(coilMesh);
      partsListRef.current.push({
        mesh: coilMesh,
        basePos: coilMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 0),
        partKey: 'impeller',
      });

      // Burner Flange & Nozzle (Brûleur)
      const burnerGeo = new THREE.CylinderGeometry(0.6, 0.8, 1.2, 24);
      const burnerMat = new THREE.MeshStandardMaterial({ color: 0xe11d48, metalness: 0.5, roughness: 0.4 });
      const burnerMesh = new THREE.Mesh(burnerGeo, burnerMat);
      burnerMesh.position.set(0, 5.1, 0);
      group.add(burnerMesh);
      partsListRef.current.push({
        mesh: burnerMesh,
        basePos: burnerMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 3.0, 0),
        partKey: 'volute_casing',
      });

      // Flue Chimney Exhaust
      const exhaustGeo = new THREE.CylinderGeometry(0.4, 0.4, 1.8, 24);
      const exhaustMesh = new THREE.Mesh(exhaustGeo, polishedSteelMat);
      exhaustMesh.position.set(1.4, 4.4, 0);
      group.add(exhaustMesh);
    } 
    // 4. Industrial Gate Valve
    else if (type === 'industrial_valve') {
      // Valve Flanged Body
      const valveBodyGeo = new THREE.BoxGeometry(1.6, 1.8, 1.6);
      const valveMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, metalness: 0.6, roughness: 0.35 });
      const valveMesh = new THREE.Mesh(valveBodyGeo, valveMat);
      valveMesh.position.set(0, 1.4, 0);
      group.add(valveMesh);
      partsListRef.current.push({
        mesh: valveMesh,
        basePos: valveMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 0, 0),
        partKey: 'volute_casing',
      });

      // Valve Bonnet (Chapeau)
      const bonnetGeo = new THREE.CylinderGeometry(0.7, 0.85, 1.2, 24);
      const bonnetMesh = new THREE.Mesh(bonnetGeo, valveMat.clone());
      bonnetMesh.position.set(0, 2.8, 0);
      group.add(bonnetMesh);
      partsListRef.current.push({
        mesh: bonnetMesh,
        basePos: bonnetMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 1.2, 0),
        partKey: 'volute_casing',
      });

      // Rising Threaded Stem
      const stemGeo = new THREE.CylinderGeometry(0.12, 0.12, 2.6, 16);
      const stemMesh = new THREE.Mesh(stemGeo, polishedSteelMat);
      stemMesh.position.set(0, 3.8, 0);
      group.add(stemMesh);
      partsListRef.current.push({
        mesh: stemMesh,
        basePos: stemMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 2.4, 0),
        partKey: 'shaft',
      });

      // Handwheel (Volant de manœuvre)
      const handwheelGeo = new THREE.TorusGeometry(0.9, 0.14, 16, 32);
      const handwheelMesh = new THREE.Mesh(handwheelGeo, castIronMat);
      handwheelMesh.rotation.x = Math.PI / 2;
      handwheelMesh.position.set(0, 4.8, 0);
      group.add(handwheelMesh);
      partsListRef.current.push({
        mesh: handwheelMesh,
        basePos: handwheelMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 3.8, 0),
        partKey: 'volute_casing',
      });
    }
    // 5. Industrial Gearbox (Réducteur de Vitesse)
    else if (type === 'gearbox') {
      const gearCasingMat = new THREE.MeshStandardMaterial({ color: 0x155e75, metalness: 0.65, roughness: 0.35 });
      // Lower housing
      const lowerGeo = new THREE.BoxGeometry(3.2, 1.4, 2.4);
      const lowerMesh = new THREE.Mesh(lowerGeo, gearCasingMat);
      lowerMesh.position.set(0, 0.9, 0);
      group.add(lowerMesh);

      // Upper split casing (explodes upward)
      const upperGeo = new THREE.BoxGeometry(3.2, 1.2, 2.4);
      const upperMesh = new THREE.Mesh(upperGeo, gearCasingMat.clone());
      upperMesh.position.set(0, 2.2, 0);
      group.add(upperMesh);
      partsListRef.current.push({
        mesh: upperMesh,
        basePos: upperMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 2.5, 0),
        partKey: 'gearbox_casing',
      });

      // Pinion Gear (Small driver gear)
      const pinionGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.9, 32);
      const pinionMesh = new THREE.Mesh(pinionGeo, bronzeMat);
      pinionMesh.rotation.x = Math.PI / 2;
      pinionMesh.position.set(-0.8, 1.6, 0);
      group.add(pinionMesh);
      partsListRef.current.push({
        mesh: pinionMesh,
        basePos: pinionMesh.position.clone(),
        explodeDir: new THREE.Vector3(-1.4, 0, 0),
        partKey: 'impeller',
      });

      // Bull Gear (Large driven gear)
      const bullGeo = new THREE.CylinderGeometry(1.35, 1.35, 0.9, 32);
      const bullMesh = new THREE.Mesh(bullGeo, bronzeMat.clone());
      bullMesh.rotation.x = Math.PI / 2;
      bullMesh.position.set(0.8, 1.6, 0);
      group.add(bullMesh);
      partsListRef.current.push({
        mesh: bullMesh,
        basePos: bullMesh.position.clone(),
        explodeDir: new THREE.Vector3(1.4, 0, 0),
        partKey: 'impeller',
      });

      // Input & Output Shafts
      const inShaftGeo = new THREE.CylinderGeometry(0.2, 0.2, 4.2, 24);
      const inShaft = new THREE.Mesh(inShaftGeo, polishedSteelMat);
      inShaft.rotation.x = Math.PI / 2;
      inShaft.position.set(-0.8, 1.6, 0);

      const outShaftGeo = new THREE.CylinderGeometry(0.35, 0.35, 4.6, 24);
      const outShaft = new THREE.Mesh(outShaftGeo, polishedSteelMat);
      outShaft.rotation.x = Math.PI / 2;
      outShaft.position.set(0.8, 1.6, 0);

      group.add(inShaft, outShaft);
    }
    // 6. Industrial Air Compressor (Compresseur à Pistons)
    else if (type === 'air_compressor') {
      const compCasingMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.6, roughness: 0.4 });
      // Crankcase
      const crankcaseGeo = new THREE.BoxGeometry(2.0, 1.6, 2.0);
      const crankcaseMesh = new THREE.Mesh(crankcaseGeo, compCasingMat);
      crankcaseMesh.position.set(0, 1.2, 0);
      group.add(crankcaseMesh);

      // Left V-cylinder
      const cylLeftGeo = new THREE.CylinderGeometry(0.65, 0.65, 1.8, 24);
      const cylLeft = new THREE.Mesh(cylLeftGeo, compCasingMat.clone());
      cylLeft.position.set(-0.7, 2.6, 0);
      cylLeft.rotation.z = Math.PI / 6;
      group.add(cylLeft);
      partsListRef.current.push({
        mesh: cylLeft,
        basePos: cylLeft.position.clone(),
        explodeDir: new THREE.Vector3(-1.8, 1.8, 0),
        partKey: 'compressor_cylinder',
      });

      // Right V-cylinder
      const cylRightGeo = new THREE.CylinderGeometry(0.65, 0.65, 1.8, 24);
      const cylRight = new THREE.Mesh(cylRightGeo, compCasingMat.clone());
      cylRight.position.set(0.7, 2.6, 0);
      cylRight.rotation.z = -Math.PI / 6;
      group.add(cylRight);
      partsListRef.current.push({
        mesh: cylRight,
        basePos: cylRight.position.clone(),
        explodeDir: new THREE.Vector3(1.8, 1.8, 0),
        partKey: 'compressor_cylinder',
      });

      // Spoked Flywheel & Fan Blades
      const flywheelGeo = new THREE.TorusGeometry(1.5, 0.18, 16, 32);
      const flywheelMesh = new THREE.Mesh(flywheelGeo, castIronMat);
      flywheelMesh.rotation.y = Math.PI / 2;
      flywheelMesh.position.set(-1.4, 1.2, 0);
      group.add(flywheelMesh);
      partsListRef.current.push({
        mesh: flywheelMesh,
        basePos: flywheelMesh.position.clone(),
        explodeDir: new THREE.Vector3(-2.8, 0, 0),
        partKey: 'impeller',
      });
    }
    // 7. Shell & Tube Heat Exchanger (Échangeur de Chaleur)
    else if (type === 'heat_exchanger') {
      const vesselMat = new THREE.MeshStandardMaterial({ color: 0x0369a1, metalness: 0.7, roughness: 0.3 });
      // Main horizontal cylindrical shell
      const shellGeo = new THREE.CylinderGeometry(1.2, 1.2, 5.2, 32);
      const shellMesh = new THREE.Mesh(shellGeo, vesselMat);
      shellMesh.rotation.z = Math.PI / 2;
      shellMesh.position.set(0, 2.2, 0);
      group.add(shellMesh);
      partsListRef.current.push({
        mesh: shellMesh,
        basePos: shellMesh.position.clone(),
        explodeDir: new THREE.Vector3(0, 1.8, 0),
        partKey: 'heat_exchanger_shell',
      });

      // Channel Heads (Flanged domes)
      const headLeftGeo = new THREE.SphereGeometry(1.2, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
      const headLeft = new THREE.Mesh(headLeftGeo, vesselMat.clone());
      headLeft.rotation.z = -Math.PI / 2;
      headLeft.position.set(-2.6, 2.2, 0);

      const headRightGeo = new THREE.SphereGeometry(1.2, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
      const headRight = new THREE.Mesh(headRightGeo, vesselMat.clone());
      headRight.rotation.z = Math.PI / 2;
      headRight.position.set(2.6, 2.2, 0);

      group.add(headLeft, headRight);
      partsListRef.current.push({
        mesh: headLeft,
        basePos: headLeft.position.clone(),
        explodeDir: new THREE.Vector3(-2.2, 0, 0),
        partKey: 'heat_exchanger_shell',
      });
      partsListRef.current.push({
        mesh: headRight,
        basePos: headRight.position.clone(),
        explodeDir: new THREE.Vector3(2.2, 0, 0),
        partKey: 'heat_exchanger_shell',
      });

      // Internal Tube Bundle (visible in cutaway)
      for (let r = 0; r < 7; r++) {
        const tubeGeo = new THREE.CylinderGeometry(0.08, 0.08, 5.0, 12);
        const tubeMesh = new THREE.Mesh(tubeGeo, copperMat);
        tubeMesh.rotation.z = Math.PI / 2;
        const angle = (r / 7) * Math.PI * 2;
        tubeMesh.position.set(0, 2.2 + Math.sin(angle) * 0.6, Math.cos(angle) * 0.6);
        group.add(tubeMesh);
      }

      // Saddle Support Feet
      const saddle1Geo = new THREE.BoxGeometry(0.4, 1.0, 2.6);
      const saddle1 = new THREE.Mesh(saddle1Geo, castIronMat);
      saddle1.position.set(-1.6, 0.5, 0);
      const saddle2 = saddle1.clone();
      saddle2.position.set(1.6, 0.5, 0);
      group.add(saddle1, saddle2);
    }

    // Add Procedural Flow Particle Stream
    const particleCount = liteMode ? 60 : 200;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      positions[i * 3 + 0] = (Math.random() - 0.5) * 1.6;
      positions[i * 3 + 1] = 1.0 + Math.random() * 2.5;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 1.6;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x00f0ff,
      size: 0.1,
      transparent: true,
      opacity: 0.75,
    });
    const flowPoints = new THREE.Points(particleGeo, particleMat);
    flowPoints.visible = showFlowRef.current;
    scene.add(flowPoints);
    flowParticlesRef.current = flowPoints;

    scene.add(group);
    modelGroupRef.current = group;
  }, [liteMode]);

  // Handle Cutaway / Transparency Update
  useEffect(() => {
    if (!modelGroupRef.current) return;
    partsListRef.current.forEach(({ mesh, partKey }) => {
      if (mesh instanceof THREE.Mesh) {
        if (partKey === 'volute_casing' || partKey === 'motor_stator') {
          mesh.material.transparent = cutaway;
          mesh.material.opacity = cutaway ? (isSoftwareGlRef.current ? 0.35 : 0.4) : 1.0;
          mesh.material.wireframe = cutaway;
          mesh.material.needsUpdate = true;
        }
      }
    });
  }, [cutaway]);

  // Handle Flow Visibility
  useEffect(() => {
    if (flowParticlesRef.current) {
      flowParticlesRef.current.visible = showFlow;
    }
  }, [showFlow]);

  // Main Three.js Scene Setup (Mounts once)
  useEffect(() => {
    if (!containerRef.current) return;

    // Detect software WebGL as per Three.js skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();
    isSoftwareGlRef.current = isSoftwareGl;

    const isLite = isSoftwareGl || liteMode;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isLite,
      powerPreference: isLite ? 'low-power' : 'high-performance',
      alpha: false,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isLite ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isLite;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = containerRef.current.clientWidth || 800;
    const height = containerRef.current.clientHeight || 600;
    renderer.setSize(width, height);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Scene & Environment
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f18);
    scene.fog = new THREE.Fog(0x0a0f18, 14, 30);
    sceneRef.current = scene;

    // Studio Environment map
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(6, 4.5, 7);
    cameraRef.current = camera;

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 + 0.05; // don't go below floor
    controls.minDistance = 2.5;
    controls.maxDistance = 18;
    controls.target.set(0, 2.0, 0);
    controlsRef.current = controls;

    // Balanced 3-Point Lighting
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
    keyLight.position.set(6, 8, 5);
    keyLight.castShadow = !isSoftwareGl;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    fillLight.position.set(-6, 4, -4);
    scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x0f172a, 0.9);
    scene.add(hemiLight);

    // Ground Floor Grid
    const grid = new THREE.GridHelper(24, 24, 0x00f0ff, 0x1e293b);
    grid.position.y = 0;
    scene.add(grid);

    // Soft Radial Contact Shadow Grounding
    const contactShadowGeo = new THREE.PlaneGeometry(8, 8);
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
      grad.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 128, 128);
    }
    const shadowTex = new THREE.CanvasTexture(canvas);
    const contactShadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    });
    const contactPlane = new THREE.Mesh(contactShadowGeo, contactShadowMat);
    contactPlane.rotation.x = -Math.PI / 2;
    contactPlane.position.y = 0.01;
    scene.add(contactPlane);

    // Initial Model Build
    buildCurrentModel(selectedModel, scene);

    // Animation Loop
    let animId = 0;
    const currentExplodeVal = { value: 0 };

    const tick = () => {
      // Damped exploded view interpolation
      currentExplodeVal.value = THREE.MathUtils.damp(
        currentExplodeVal.value,
        targetExplodeRef.current,
        6,
        0.016
      );

      // Apply exploded offsets to each part
      partsListRef.current.forEach(({ mesh, basePos, explodeDir }) => {
        mesh.position.copy(basePos).addScaledVector(explodeDir, currentExplodeVal.value);
      });

      // Flow particle animation
      if (flowParticlesRef.current && flowParticlesRef.current.visible) {
        const posAttr = flowParticlesRef.current.geometry.attributes.position;
        const arr = posAttr.array as Float32Array;
        for (let i = 0; i < arr.length; i += 3) {
          arr[i + 1] += 0.03;
          if (arr[i + 1] > 3.8) arr[i + 1] = 1.0;
        }
        posAttr.needsUpdate = true;
      }

      // Auto rotation
      if (autoRotateRef.current && modelGroupRef.current) {
        modelGroupRef.current.rotation.y += 0.005;
      }

      controls.update();
      renderer.render(scene, camera);
      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);

    // Raycaster Part Tap / Click Inspection
    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();
    let pointerDownPos = { x: 0, y: 0 };

    const handlePointerDownCanvas = (ev: PointerEvent) => {
      pointerDownPos = { x: ev.clientX, y: ev.clientY };
    };

    const handlePointerUpCanvas = (ev: PointerEvent) => {
      const dist = Math.hypot(ev.clientX - pointerDownPos.x, ev.clientY - pointerDownPos.y);
      if (dist > 6 || !rendererRef.current || !cameraRef.current) return;

      const rect = rendererRef.current.domElement.getBoundingClientRect();
      pointerNdc.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointerNdc, cameraRef.current);
      const partMeshes = partsListRef.current.map((p) => p.mesh);
      const intersects = raycaster.intersectObjects(partMeshes, true);
      if (intersects.length > 0) {
        const hitObj = intersects[0].object;
        const matched = partsListRef.current.find((p) => p.mesh === hitObj || p.mesh.children.includes(hitObj));
        if (matched && PART_SPECS[matched.partKey]) {
          setInspectedPart(PART_SPECS[matched.partKey]);
          sound.playBeep(820, 0.05);
          onRewardXpRef.current(5);
        }
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDownCanvas);
    renderer.domElement.addEventListener('pointerup', handlePointerUpCanvas);

    // Resize Observer
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDownCanvas);
      renderer.domElement.removeEventListener('pointerup', handlePointerUpCanvas);
      renderer.dispose();
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, [buildCurrentModel, liteMode]);

  // Switch Model
  const handleModelChange = (type: Model3DType) => {
    setSelectedModel(type);
    sound.playRelayClick();
    if (sceneRef.current) {
      buildCurrentModel(type, sceneRef.current);
    }
    if (type === 'centrifugal_pump') setInspectedPart(PART_SPECS.volute_casing);
    else if (type === 'induction_motor') setInspectedPart(PART_SPECS.motor_stator);
    else if (type === 'thermal_boiler') setInspectedPart(PART_SPECS.volute_casing);
    else if (type === 'gearbox') setInspectedPart(PART_SPECS.gearbox_casing);
    else if (type === 'air_compressor') setInspectedPart(PART_SPECS.compressor_cylinder);
    else if (type === 'heat_exchanger') setInspectedPart(PART_SPECS.heat_exchanger_shell);
    else setInspectedPart(PART_SPECS.shaft);

    onRewardXP(20);
  };

  // Reset Camera View
  const setCameraAngle = (preset: 'iso' | 'front' | 'top') => {
    if (!cameraRef.current || !controlsRef.current) return;
    sound.playBeep(700, 0.04);
    if (preset === 'iso') {
      cameraRef.current.position.set(6, 4.5, 7);
    } else if (preset === 'front') {
      cameraRef.current.position.set(0, 2.5, 8.5);
    } else if (preset === 'top') {
      cameraRef.current.position.set(0, 10, 0.1);
    }
    controlsRef.current.target.set(0, 2.0, 0);
    controlsRef.current.update();
  };

  return (
    <div className="relative w-full h-full min-h-[640px] flex flex-col bg-[#070b13] overflow-hidden select-none">
      {/* 3D Scene WebGL Container (Isolated ref as required by Three.js skill) */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full z-0 cursor-grab active:cursor-grabbing" />

      {/* Minimal Top-Left Title Badge (Zero viewport obstruction) */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-3 bg-slate-900/80 border border-slate-800 p-2.5 rounded-xl shadow-xl backdrop-blur-none">
        <div className="p-2 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
          <Rotate3d className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold text-white tracking-wide">
              {selectedModel === 'centrifugal_pump' && t.modelPump}
              {selectedModel === 'induction_motor' && t.modelMotor}
              {selectedModel === 'thermal_boiler' && t.modelBoiler}
              {selectedModel === 'industrial_valve' && t.modelValve}
              {selectedModel === 'gearbox' && 'علبة تروس صناعية (Industrial Gearbox)'}
              {selectedModel === 'air_compressor' && 'ضاغط هواء ترددي (Air Compressor)'}
              {selectedModel === 'heat_exchanger' && 'مبادل حراري أنبوبي (Heat Exchanger)'}
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-900/60 text-cyan-300 border border-cyan-500/30">
              PBR High-Fi
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            {t.clickPartPrompt}
          </p>
        </div>
      </div>

      {/* Model Selection Tabs (Top Right) */}
      <div className="absolute top-4 right-4 z-10 flex flex-wrap items-center gap-1.5 bg-slate-900/90 border border-slate-800 p-1.5 rounded-xl shadow-xl">
        {(['centrifugal_pump', 'induction_motor', 'thermal_boiler', 'industrial_valve', 'gearbox', 'air_compressor', 'heat_exchanger'] as Model3DType[]).map((m) => (
          <button
            key={m}
            onClick={() => handleModelChange(m)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              selectedModel === m
                ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30 font-bold'
                : 'bg-slate-800/60 hover:bg-slate-700 text-slate-300'
            }`}
          >
            {m === 'centrifugal_pump' && 'Pompe'}
            {m === 'induction_motor' && 'Moteur'}
            {m === 'thermal_boiler' && 'Chaudière'}
            {m === 'industrial_valve' && 'Vanne'}
            {m === 'gearbox' && 'Réducteur'}
            {m === 'air_compressor' && 'Compresseur'}
            {m === 'heat_exchanger' && 'Échangeur'}
          </button>
        ))}
      </div>

      {/* Minimal Inspected Part Spec Card (Top-right floating if part inspected) */}
      {inspectedPart && (
        <div className="absolute top-16 right-4 z-10 max-w-sm w-80 bg-slate-900/95 border border-cyan-500/30 rounded-xl p-3.5 shadow-2xl text-xs space-y-2">
          <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
            <span className="font-bold text-cyan-300 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-cyan-400" />
              {inspectedPart.name[language]}
            </span>
            <span className="font-mono text-[10px] text-slate-400">{inspectedPart.material}</span>
          </div>
          <div>
            <span className="text-slate-400 font-semibold block text-[11px]">الوظيفة الهندسية:</span>
            <p className="text-slate-200 text-[11px] leading-relaxed">{inspectedPart.function[language]}</p>
          </div>
          <div className="pt-1 border-t border-slate-800/60">
            <span className="text-amber-400 font-semibold block text-[11px]">الأعطال الشائعة:</span>
            <p className="text-amber-200/90 text-[11px] leading-relaxed">{inspectedPart.faults[language]}</p>
          </div>
        </div>
      )}

      {/* Collapsible Unified Bottom Control Dock (Strictly as mandated by Three.js Skill Directive 5) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-4xl transition-all duration-300">
        {/* Toggle Collapse Tab */}
        <div className="flex justify-center -mb-2">
          <button
            onClick={() => setDockExpanded(!dockExpanded)}
            className="flex items-center gap-1 px-4 py-1 rounded-t-xl bg-slate-900/95 border-t border-x border-slate-700 text-[11px] font-mono text-cyan-400 hover:text-cyan-300 shadow-md"
          >
            {dockExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            {dockExpanded ? 'إخفاء لوحة التحكم (Hide Controls)' : 'إظهار لوحة التحكم (Show Controls)'}
          </button>
        </div>

        {/* Dock Body */}
        {dockExpanded && (
          <div className="bg-slate-900/95 border border-slate-700/80 rounded-2xl p-4 shadow-2xl backdrop-blur-none space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
              {/* Exploded View Slider */}
              <div className="space-y-1.5 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-300 font-medium flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    {t.explodedView}
                  </span>
                  <span className="font-mono text-cyan-400 font-bold">{Math.round(explodedRatio * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={explodedRatio}
                  onChange={(e) => {
                    setExplodedRatio(parseFloat(e.target.value));
                    if (explodedRatio === 0) onRewardXP(10);
                  }}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>

              {/* View Modes & Toggles */}
              <div className="flex flex-wrap items-center justify-center gap-2">
                <button
                  onClick={() => {
                    setCutaway(!cutaway);
                    sound.playBeep(cutaway ? 500 : 800, 0.04);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${
                    cutaway
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-lg shadow-cyan-500/20'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  {t.cutawayView}
                </button>

                <button
                  onClick={() => setShowFlow(!showFlow)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${
                    showFlow
                      ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-lg shadow-emerald-500/20'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Flame className="w-3.5 h-3.5" />
                  {t.showFlow}
                </button>

                <button
                  onClick={() => setAutoRotate(!autoRotate)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${
                    autoRotate
                      ? 'bg-orange-500/20 border-orange-400 text-orange-300 shadow-lg shadow-orange-500/20'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Rotate3d className="w-3.5 h-3.5" />
                  {t.autoRotate}
                </button>
              </div>

              {/* Camera Presets */}
              <div className="flex items-center justify-end gap-1.5 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                <span className="text-[11px] text-slate-400 font-mono ml-2">كاميرا:</span>
                <button
                  onClick={() => setCameraAngle('iso')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-medium"
                >
                  ISO
                </button>
                <button
                  onClick={() => setCameraAngle('front')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-medium"
                >
                  Front
                </button>
                <button
                  onClick={() => setCameraAngle('top')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-medium"
                >
                  Top
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
