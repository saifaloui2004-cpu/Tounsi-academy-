/**
 * NEXUS WORKSHOP — Dedicated Hands-On Lab Workbenches for 10 Modules
 * Interactive calculators, Ladder simulator, and specialized engineering tools.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState } from 'react';
import { EngineeringLabId, Language } from '../../types';
import { LABS_LIST } from '../../data/trainingData';
import { IndustrialPhysics } from '../../sim/physics';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  Zap, Cog, Cpu, Flame, Gauge, Car, Radio, Wrench, 
  AlertTriangle, Box, Play, RotateCcw, CheckCircle2, Calculator 
} from 'lucide-react';

interface Props {
  labId: EngineeringLabId;
  language: Language;
  onRewardXP: (xp: number) => void;
  onNavigateTab: (tab: '2d' | '3d' | 'thermal' | 'faults' | 'training') => void;
}

export const ModuleLabView: React.FC<Props> = ({
  labId,
  language,
  onRewardXP,
  onNavigateTab,
}) => {
  const t = i18n[language];
  const lab = LABS_LIST.find((l) => l.id === labId) || LABS_LIST[0];

  // --- 1. Electrical State ---
  const [elecVolts, setElecVolts] = useState<number>(400);
  const [elecAmps, setElecAmps] = useState<number>(25);
  const [elecCosPhi, setElecCosPhi] = useState<number>(0.85);

  // --- 2. Mechanical State ---
  const [gearDriver, setGearDriver] = useState<number>(18);
  const [gearDriven, setGearDriven] = useState<number>(72);
  const [motorRPM, setMotorRPM] = useState<number>(1450);
  const [motorKW, setMotorKW] = useState<number>(15);

  // --- 3. PLC Ladder State ---
  const [plcStartPressed, setPlcStartPressed] = useState<boolean>(false);
  const [plcStopPressed, setPlcStopPressed] = useState<boolean>(false);
  const [plcCoilQ0, setPlcCoilQ0] = useState<boolean>(false);
  const [plcTimerElapsed, setPlcTimerElapsed] = useState<number>(0);

  // --- 5. Hydraulics State ---
  const [hydPressure, setHydPressure] = useState<number>(160);
  const [hydBoreDia, setHydBoreDia] = useState<number>(80);
  const [hydRodDia, setHydRodDia] = useState<number>(45);

  // --- 6. Automotive OBD State ---
  const [obdCode, setObdCode] = useState<string>('P0300');

  // --- 8. Maintenance KPIs State ---
  const [operatingHours, setOperatingHours] = useState<number>(2400);
  const [breakdownCount, setBreakdownCount] = useState<number>(4);
  const [downtimeHours, setDowntimeHours] = useState<number>(18);

  // Run PLC Ladder simulation step
  const handlePlcStart = () => {
    sound.playRelayClick();
    setPlcStartPressed(true);
    setPlcCoilQ0(true);
    onRewardXP(10);
    setTimeout(() => setPlcStartPressed(false), 200);
  };

  const handlePlcStop = () => {
    sound.playRelayClick();
    setPlcStopPressed(true);
    setPlcCoilQ0(false);
    setTimeout(() => setPlcStopPressed(false), 200);
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 gap-4 overflow-y-auto">
      {/* Lab Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
            {labId === 'electrical' && <Zap className="w-5 h-5" />}
            {labId === 'mechanical' && <Cog className="w-5 h-5" />}
            {labId === 'plc' && <Cpu className="w-5 h-5" />}
            {labId === 'thermal' && <Flame className="w-5 h-5" />}
            {labId === 'hydraulics' && <Gauge className="w-5 h-5" />}
            {labId === 'automotive' && <Car className="w-5 h-5" />}
            {labId === 'electronics' && <Radio className="w-5 h-5" />}
            {labId === 'maintenance' && <Wrench className="w-5 h-5" />}
            {labId === 'faults' && <AlertTriangle className="w-5 h-5" />}
            {labId === 'sim3d' && <Box className="w-5 h-5" />}
          </div>
          <div>
            <h1 className="text-base font-bold text-white flex items-center gap-2">
              {lab.name[language]}
            </h1>
            <p className="text-xs text-slate-400">{lab.subtitle[language]}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {labId === 'sim3d' ? (
            <button
              onClick={() => onNavigateTab('3d')}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold transition-all shadow-md"
            >
              فتح مركز المحاكاة 3D
            </button>
          ) : labId === 'thermal' ? (
            <button
              onClick={() => onNavigateTab('thermal')}
              className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-black text-xs font-bold transition-all shadow-md"
            >
              فتح منظومة الزيت الحراري
            </button>
          ) : labId === 'faults' ? (
            <button
              onClick={() => onNavigateTab('faults')}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold transition-all shadow-md"
            >
              فتح مركز تشخيص الأعطال
            </button>
          ) : (
            <button
              onClick={() => onNavigateTab('2d')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-bold transition-all"
            >
              فتح لوحة المحاكاة 2D
            </button>
          )}
        </div>
      </div>

      {/* Lab Specific Interactive Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* 1. Electrical Lab Workbench */}
        {labId === 'electrical' && (
          <>
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
              <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                حاسبة القدرة ثلاثية الأطوار والبدء النجمي-المثلثي
              </h2>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>الجهد بين الأطوار (Line Voltage):</span>
                    <span className="font-mono text-cyan-400 font-bold">{elecVolts} V</span>
                  </div>
                  <input
                    type="range"
                    min="230"
                    max="690"
                    step="10"
                    value={elecVolts}
                    onChange={(e) => setElecVolts(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>التيار الاسمي (Rated Current):</span>
                    <span className="font-mono text-cyan-400 font-bold">{elecAmps} A</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="150"
                    value={elecAmps}
                    onChange={(e) => setElecAmps(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>معامل القدرة (Power Factor cos φ):</span>
                    <span className="font-mono text-cyan-400 font-bold">{elecCosPhi}</span>
                  </div>
                  <input
                    type="range"
                    min="0.6"
                    max="0.98"
                    step="0.02"
                    value={elecCosPhi}
                    onChange={(e) => setElecCosPhi(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-4">
              <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                نتائج الحسابات الكهروميكانيكية
              </h2>

              {(() => {
                const kw = IndustrialPhysics.electrical.threePhaseActivePower(elecVolts, elecAmps, elecCosPhi);
                const sd = IndustrialPhysics.electrical.starDeltaComparison(elecAmps);

                return (
                  <div className="space-y-3 font-mono text-xs">
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">القدرة الفعالة (Active Power P):</span>
                      <span className="text-base text-cyan-400 font-bold">{kw.toFixed(2)} kW</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">تيار البدء المباشر (DOL Inrush):</span>
                      <span className="text-rose-400 font-bold">{sd.directDeltaStartingAmps} A (~6x)</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">تيار البدء النجمي (Star Inrush):</span>
                      <span className="text-emerald-400 font-bold">{sd.starStartingAmps} A (-67%)</span>
                    </div>
                  </div>
                );
              })()}

              <div className="p-3 bg-cyan-950/30 border border-cyan-500/20 rounded-xl text-[11px] text-cyan-200">
                قاعدة: الإقلاع النجمي يقلل عزم المحرك أيضاً إلى الثلث، لذلك لا يجوز استخدامه مع الأحمال التي تتطلب عزم إقلاع عالٍ عند الصفر كالمكابس والمصاعد.
              </div>
            </div>
          </>
        )}

        {/* 2. Mechanical Lab Workbench */}
        {labId === 'mechanical' && (
          <>
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
              <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                حاسبة علب التروس (Gearbox) والعزم الميكانيكي
              </h2>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>أسنان الترس القائد (Driver Z1):</span>
                    <span className="font-mono text-cyan-400 font-bold">{gearDriver}</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="60"
                    value={gearDriver}
                    onChange={(e) => setGearDriver(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>أسنان الترس المقاد (Driven Z2):</span>
                    <span className="font-mono text-cyan-400 font-bold">{gearDriven}</span>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="180"
                    value={gearDriven}
                    onChange={(e) => setGearDriven(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>قدرة المحرك (Motor Power):</span>
                    <span className="font-mono text-cyan-400 font-bold">{motorKW} kW</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="75"
                    value={motorKW}
                    onChange={(e) => setMotorKW(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-4">
              <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                مخرجات علبة السرعة والعزم
              </h2>

              {(() => {
                const inTorque = IndustrialPhysics.mechanical.torqueFromPower(motorKW, motorRPM);
                const gb = IndustrialPhysics.mechanical.gearbox(gearDriver, gearDriven, motorRPM, inTorque);

                return (
                  <div className="space-y-3 font-mono text-xs">
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">نسبة التخفيض (Ratio i):</span>
                      <span className="text-cyan-400 font-bold">1 : {gb.ratio}</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">سرعة الخرج (Output Speed):</span>
                      <span className="text-amber-400 font-bold">{gb.outputSpeedRPM} RPM</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">عزم الخرج (Output Torque):</span>
                      <span className="text-emerald-400 font-bold">{gb.outputTorqueNm} N·m</span>
                    </div>
                  </div>
                );
              })()}

              <div className="p-3 bg-amber-950/30 border border-amber-500/20 rounded-xl text-[11px] text-amber-200">
                ملاحظة كراسي التحميل: خلوص C3 هو خلوص شعاعي ميكانيكي داخلي مخصص للتطبيقات ذات الحرارة العالية لمنع انحشار الكريات عند التمدد.
              </div>
            </div>
          </>
        )}

        {/* 3. PLC Ladder Logic Simulator */}
        {labId === 'plc' && (
          <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Cpu className="w-4 h-4" />
                محاكي منطق السلم التفاعلي (PLC Ladder Logic Simulator)
              </h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePlcStart}
                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md"
                >
                  START (I0.0)
                </button>
                <button
                  onClick={handlePlcStop}
                  className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md"
                >
                  STOP (I0.1)
                </button>
              </div>
            </div>

            {/* Ladder Rung Graphic */}
            <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 font-mono text-xs overflow-x-auto">
              <div className="flex items-center justify-between min-w-[500px] border-y border-slate-700 py-4 relative">
                {/* Left Power Rail */}
                <div className="w-2 h-16 bg-red-500 rounded" />

                {/* Stop Button NC Contact */}
                <div className="flex flex-col items-center">
                  <span className="text-[10px] text-slate-400">I0.1 (Stop NC)</span>
                  <div
                    className={`w-12 h-8 border-2 rounded flex items-center justify-center font-bold ${
                      !plcStopPressed ? 'border-emerald-400 text-emerald-400 bg-emerald-950/40' : 'border-rose-500 text-rose-500'
                    }`}
                  >
                    [/]
                  </div>
                </div>

                <div className="flex-1 h-0.5 bg-slate-600" />

                {/* Parallel Branch: Start NO Contact & Q0.0 Latch */}
                <div className="flex flex-col gap-2">
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-slate-400">I0.0 (Start NO)</span>
                    <div
                      className={`w-12 h-7 border-2 rounded flex items-center justify-center font-bold ${
                        plcStartPressed ? 'border-cyan-400 bg-cyan-950 text-cyan-300' : 'border-slate-600 text-slate-500'
                      }`}
                    >
                      [ ]
                    </div>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-slate-400">Q0.0 (Latch)</span>
                    <div
                      className={`w-12 h-7 border-2 rounded flex items-center justify-center font-bold ${
                        plcCoilQ0 ? 'border-cyan-400 bg-cyan-950 text-cyan-300' : 'border-slate-600 text-slate-500'
                      }`}
                    >
                      [ ]
                    </div>
                  </div>
                </div>

                <div className="flex-1 h-0.5 bg-slate-600" />

                {/* Output Coil Q0.0 */}
                <div className="flex flex-col items-center">
                  <span className="text-[10px] text-slate-400">Motor Coil Q0.0</span>
                  <div
                    className={`w-14 h-8 rounded-full border-2 flex items-center justify-center font-bold ${
                      plcCoilQ0 ? 'border-emerald-400 bg-emerald-500 text-black shadow-lg shadow-emerald-500/50' : 'border-slate-700 text-slate-600'
                    }`}
                  >
                    ( )
                  </div>
                </div>

                {/* Right Neutral Rail */}
                <div className="w-2 h-16 bg-blue-500 rounded" />
              </div>
            </div>
          </div>
        )}

        {/* 5. Hydraulics & Pneumatics Lab Workbench */}
        {labId === 'hydraulics' && (
          <>
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
              <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                حاسبة قوى الأسطوانة الهيدروليكية (قانون باسكال)
              </h2>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>ضغط الزيت الهيدروليكي:</span>
                    <span className="font-mono text-cyan-400 font-bold">{hydPressure} bar</span>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="350"
                    step="10"
                    value={hydPressure}
                    onChange={(e) => setHydPressure(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>قطر المكبس الداخلي (Bore Dia):</span>
                    <span className="font-mono text-cyan-400 font-bold">{hydBoreDia} mm</span>
                  </div>
                  <input
                    type="range"
                    min="25"
                    max="200"
                    value={hydBoreDia}
                    onChange={(e) => setHydBoreDia(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>قطر القضيب (Rod Dia):</span>
                    <span className="font-mono text-cyan-400 font-bold">{hydRodDia} mm</span>
                  </div>
                  <input
                    type="range"
                    min="15"
                    max="100"
                    value={hydRodDia}
                    onChange={(e) => setHydRodDia(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-4">
              <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                قوى الدفع والسحب الناتجة
              </h2>

              {(() => {
                const forces = IndustrialPhysics.hydraulics.cylinderForce(hydPressure, hydBoreDia, hydRodDia);

                return (
                  <div className="space-y-3 font-mono text-xs">
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">قوة الدفع في شوط الخروج (Push):</span>
                      <span className="text-cyan-400 font-bold">{forces.pushForceKN} kN ({(forces.pushForceKN * 0.102).toFixed(1)} طن)</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">قوة السحب في شوط الرجوع (Pull):</span>
                      <span className="text-indigo-400 font-bold">{forces.pullForceKN} kN ({(forces.pullForceKN * 0.102).toFixed(1)} طن)</span>
                    </div>
                  </div>
                );
              })()}

              <div className="p-3 bg-cyan-950/30 border border-cyan-500/20 rounded-xl text-[11px] text-cyan-200">
                ملاحظة: قوة شوط الرجوع تكون دائماً أصغر من قوة الخروج لأن مساحة القضيب (Rod Area) تقلل من مساحة الزيت الفعالة المؤثرة على المكبس.
              </div>
            </div>
          </>
        )}

        {/* 6. Automotive Diagnostics Lab */}
        {labId === 'automotive' && (
          <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Car className="w-4 h-4" />
              محلل رموز الأعطال OBD-II وقراءات شبكة CAN-Bus
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(['P0300', 'P0171', 'P0102', 'U0100', 'P0115', 'P0420'] as const).map((code) => (
                <button
                  key={code}
                  onClick={() => {
                    setObdCode(code);
                    sound.playBeep(850, 0.05);
                  }}
                  className={`p-3 rounded-xl border text-right transition-all font-mono ${
                    obdCode === code
                      ? 'bg-cyan-950/60 border-cyan-400 text-cyan-300 shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs text-white">{code}</div>
                  <div className="text-[10px] text-slate-400 truncate">
                    {code === 'P0300' && 'Random Cylinder Misfire Detected'}
                    {code === 'P0171' && 'System Too Lean (Bank 1)'}
                    {code === 'P0102' && 'Mass Air Flow (MAF) Circuit Low'}
                    {code === 'U0100' && 'Lost Communication With ECM/PCM'}
                    {code === 'P0115' && 'Engine Coolant Temp Circuit Malfunction'}
                    {code === 'P0420' && 'Catalyst System Efficiency Below Threshold'}
                  </div>
                </button>
              ))}
            </div>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono space-y-1">
              <span className="text-cyan-400 font-bold block">التشخيص المقترح لرمز {obdCode}:</span>
              <p className="text-slate-300">
                {obdCode === 'P0300' && 'تحقق من شمعات الإشعال (Spark Plugs)، كويلات الإشعال، وضغط الوقود في المسطرة.'}
                {obdCode === 'P0171' && 'فحص تسريب هواء الفاكيوم بعد حساس الـ MAF وتنظيف حواقن الوقود.'}
                {obdCode === 'P0102' && 'تنظيف سلك البلاتين الساخن داخل حساس MAF وفحص جهد التغذية 12V وسلك التأريض.'}
                {obdCode === 'U0100' && 'فحص خطوط CAN-High (2.5V - 3.5V) و CAN-Low (1.5V - 2.5V) ومقاومة الإنهاء 120 Ω.'}
                {obdCode === 'P0115' && 'قياس مقاومة NTC لحساس حرارة سائل التبريد بالملتيميتر عند درجات حرارة مختلفة.'}
                {obdCode === 'P0420' && 'مقارنة قراءات حساس الأكسجين العلوي O2 Upstream مع الحساس السفلي بعد دبة التلوث.'}
              </p>
            </div>
          </div>
        )}

        {/* 8. Maintenance Lab */}
        {labId === 'maintenance' && (
          <>
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
              <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                حاسبة مؤشرات الموثوقية الصناعية MTBF & MTTR
              </h2>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>ساعات التشغيل الكلية (Total Operating Hours):</span>
                    <span className="font-mono text-cyan-400 font-bold">{operatingHours} h</span>
                  </div>
                  <input
                    type="range"
                    min="500"
                    max="8000"
                    step="100"
                    value={operatingHours}
                    onChange={(e) => setOperatingHours(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>عدد التوقفات الطارئة (Number of Breakdowns):</span>
                    <span className="font-mono text-cyan-400 font-bold">{breakdownCount}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    value={breakdownCount}
                    onChange={(e) => setBreakdownCount(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>إجمالي ساعات التوقف للإصلاح (Downtime Hours):</span>
                    <span className="font-mono text-cyan-400 font-bold">{downtimeHours} h</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={downtimeHours}
                    onChange={(e) => setDowntimeHours(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-4">
              <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                مؤشرات الجاهزية التشغيلية (Availability)
              </h2>

              {(() => {
                const mtbf = Math.round((operatingHours - downtimeHours) / Math.max(1, breakdownCount));
                const mttr = (downtimeHours / Math.max(1, breakdownCount)).toFixed(1);
                const availability = (((operatingHours - downtimeHours) / operatingHours) * 100).toFixed(2);

                return (
                  <div className="space-y-3 font-mono text-xs">
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">متوسط الوقت بين الأعطال (MTBF):</span>
                      <span className="text-cyan-400 font-bold">{mtbf} ساعة</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">متوسط زمن الإصلاح (MTTR):</span>
                      <span className="text-amber-400 font-bold">{mttr} ساعة</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                      <span className="text-slate-400">نسبة الجاهزية (Plant Availability):</span>
                      <span className="text-emerald-400 font-bold">{availability}%</span>
                    </div>
                  </div>
                );
              })()}

              <div className="p-3 bg-emerald-950/30 border border-emerald-500/20 rounded-xl text-[11px] text-emerald-200">
                المعيار الذهبي للصناعة: المصانع الحديثة تسعى لنسبة توافر تفوق 95% عبر تطبيق الصيانة التنبؤية المعتمدة على الاهتزازات والتحليل الطيفي للزيوت.
              </div>
            </div>
          </>
        )}

        {/* 9. Pneumatics Lab */}
        {labId === 'pneumatics' && (
          <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Gauge className="w-4 h-4" />
              مختبر النيوماتيك الصناعي ووحدة تهيئة الهواء المضغوط FRL
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-300 block">وحدة معالجة الهواء FRL:</span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  فلترة الشوائب (5µm)، تنظيم الضغط (6.3 bar)، وحقن رذاذ الزيت لتزييت صمامات وأسطوانات الخط الآلي.
                </p>
                <div className="pt-2 text-[11px] font-mono text-cyan-400 font-bold">
                  P_reg: 6.3 bar • Dew Point: +3°C
                </div>
              </div>

              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-300 block">صمام توجيهي 5/2 Bistable:</span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  تحويل الهواء المضغوط بين منفذي العمل (2) و (4) لدفع ورجوع الأسطوانة مع منافذ تصريف (3) و (5).
                </p>
                <div className="pt-2 text-[11px] font-mono text-emerald-400 font-bold">
                  Solenoid 24VDC Y1/Y2
                </div>
              </div>

              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-300 block">أسطوانة الهواء مزدوجة المفعول:</span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  شوط 200 mm بسرعة تصل إلى 0.8 m/s مع كوابح وسائد هوائية (Pneumatic Cushioning) عند نهايتي الشوط.
                </p>
                <div className="pt-2 text-[11px] font-mono text-amber-400 font-bold">
                  Force Push: 1.26 kN (at 6.3 bar)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 10. Electronics Repair Lab */}
        {labId === 'electronics' && (
          <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Radio className="w-4 h-4" />
              مختبر فحص اللوحات الصناعية PCB والمكونات الإلكترونية
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1 font-mono text-xs">
                <span className="text-cyan-400 font-bold block">مكثف كيميائي 1000µF</span>
                <div className="text-slate-300">السعة: 980 µF</div>
                <div className="text-emerald-400">ESR: 0.04 Ω (سليم ممتاز)</div>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1 font-mono text-xs">
                <span className="text-cyan-400 font-bold block">ثنائي سيليكون 1N4007</span>
                <div className="text-slate-300">انحياز أمامي: 0.62 V</div>
                <div className="text-emerald-400">انحياز عكسي: ∞ O.L (سليم)</div>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1 font-mono text-xs">
                <span className="text-cyan-400 font-bold block">ترانزستور MOSFET IRF540</span>
                <div className="text-slate-300">V_th: 3.2 V</div>
                <div className="text-emerald-400">R_ds(on): 0.045 Ω (سليم)</div>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1 font-mono text-xs">
                <span className="text-rose-400 font-bold block">مكثف تالف (Short)</span>
                <div className="text-slate-300">السعة: 0 µF</div>
                <div className="text-rose-400">مقاومة: 0.2 Ω (قصر مباشر)</div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 leading-relaxed">
              طريقة كشف القصر الحراري: عند حقن جهد منخفض (1V - 2V) وتيار 2A عبر خط التغذية، يظهر المكثف التالف فوراً كنقطة ساخنة Hotspot على الكاميرا الحرارية بسبب تشتت القدرة $P = I^2 R$.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
