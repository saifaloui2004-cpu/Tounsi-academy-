/**
 * NEXUS WORKSHOP — Training System & Technical Quiz Bank
 * Modules curriculum, interactive quizzes, XP progression, and certificate trigger.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState } from 'react';
import { LABS_LIST, TECHNICAL_QUIZZES } from '../../data/trainingData';
import { EngineeringLabId, Language, QuizQuestion } from '../../types';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  BookOpen, Award, CheckCircle2, XCircle, ArrowRight, 
  HelpCircle, Sparkles, FileText, Zap, ChevronRight 
} from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
  answeredQuizIds: string[];
  onMarkQuizAnswered: (id: string) => void;
  onOpenCertificate: () => void;
  userXP: number;
}

export const TrainingCenter: React.FC<Props> = ({
  language,
  onRewardXP,
  answeredQuizIds,
  onMarkQuizAnswered,
  onOpenCertificate,
  userXP,
}) => {
  const t = i18n[language];
  const [selectedLabId, setSelectedLabId] = useState<EngineeringLabId>('electrical');
  const [activeTab, setActiveTab] = useState<'lessons' | 'quizzes'>('lessons');
  const [currentQuizIndex, setCurrentQuizIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  const activeLab = LABS_LIST.find((l) => l.id === selectedLabId) || LABS_LIST[0];
  const filteredQuizzes = TECHNICAL_QUIZZES.filter((q) => q.labId === selectedLabId);
  const currentQuiz: QuizQuestion | undefined = filteredQuizzes[currentQuizIndex] || TECHNICAL_QUIZZES[0];

  const handleSelectOption = (idx: number) => {
    if (!quizSubmitted) {
      setSelectedOption(idx);
      sound.playBeep(750, 0.04);
    }
  };

  const handleSubmitQuiz = () => {
    if (selectedOption === null || !currentQuiz) return;
    setQuizSubmitted(true);
    if (selectedOption === currentQuiz.correctIndex) {
      sound.playSuccess();
      onRewardXP(currentQuiz.xpReward);
      onMarkQuizAnswered(currentQuiz.id);
    } else {
      sound.playAlarm();
    }
  };

  const handleNextQuiz = () => {
    setSelectedOption(null);
    setQuizSubmitted(false);
    if (currentQuizIndex < filteredQuizzes.length - 1) {
      setCurrentQuizIndex((prev) => prev + 1);
    } else {
      setCurrentQuizIndex(0);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 gap-4 overflow-y-auto">
      {/* Top Banner with XP & Certificate Action */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3.5 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-950/80 border border-orange-500/40 text-orange-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-bold text-white flex items-center gap-2">
              {t.trainingTitle}
            </h1>
            <span className="text-[11px] text-slate-400 font-mono">
              Industrial Engineering Curricula • 10 Engineering Disciplines
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenCertificate}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black text-xs font-bold transition-all shadow-lg shadow-orange-500/25 active:scale-95"
          >
            <Award className="w-4 h-4" />
            {t.getCertificate}
          </button>
        </div>
      </div>

      {/* Lab Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {LABS_LIST.map((lab) => (
          <button
            key={lab.id}
            onClick={() => {
              setSelectedLabId(lab.id);
              setCurrentQuizIndex(0);
              setSelectedOption(null);
              setQuizSubmitted(false);
              sound.playRelayClick();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
              selectedLabId === lab.id
                ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-500/25 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {lab.name[language]}
          </button>
        ))}
      </div>

      {/* Main Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Lab Overview Card (Left 4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs font-mono text-cyan-400 uppercase font-bold">
              [{activeLab.category}]
            </span>
            <span className="text-xs font-mono text-orange-400 font-bold">
              +{activeLab.xpReward} XP Lab
            </span>
          </div>

          <div>
            <h2 className="text-base font-bold text-white mb-1">
              {activeLab.name[language]}
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              {activeLab.description[language]}
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="text-xs font-bold text-slate-300">محاور التكوين الأساسية:</span>
            <ul className="space-y-1.5">
              {activeLab.keyTopics[language].map((topic, idx) => (
                <li key={idx} className="flex items-center gap-2 text-xs text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  <span>{topic}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Tabbed Interactive Curriculum & Quiz (Right 8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
          {/* Subtabs */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('lessons')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'lessons'
                    ? 'bg-slate-800 text-cyan-400 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                {t.lessonsTab}
              </button>
              <button
                onClick={() => setActiveTab('quizzes')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'quizzes'
                    ? 'bg-slate-800 text-cyan-400 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                {t.quizTab} ({filteredQuizzes.length})
              </button>
            </div>

            <span className="text-[11px] font-mono text-slate-400">
              {userXP} XP الإجمالي
            </span>
          </div>

          {/* Lessons View */}
          {activeTab === 'lessons' && (
            <div className="space-y-4">
              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
                <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  الموجز الهندسي النظري والتطبيقي
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  يعتمد هذا المختبر على تكامل الحسابات الميدانية مع معايير السلامة الصناعية (NFPA / ISO / IEC). يتم تحفيز المتعلم على فهم المبادئ الفيزيائية الكامنة وراء تشغيل المعدات بدلاً من الحفظ المجرد.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-xs font-bold text-orange-400">التوصيف التقني:</span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    فهم المخططات الهندسية أحادية الخط (Single Line Diagram) ودوائر القدرة والتحكم والتوصيل الميكانيكي.
                  </p>
                </div>

                <div className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-xs font-bold text-emerald-400">الصيانة الوقائية:</span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    مراقبة درجات الحرارة والاهتزازات الدورية والتأكد من إحكام الربط لمنع النقاط الساخنة (Hotspots).
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActiveTab('quizzes')}
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black text-xs font-bold transition-all shadow-md"
              >
                <span>الانتقال إلى الاختبارات التقنية</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Quizzes View */}
          {activeTab === 'quizzes' && (
            <div className="space-y-4">
              {currentQuiz ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                    <span>سؤال {currentQuizIndex + 1} من {filteredQuizzes.length || 1}</span>
                    <span className="text-cyan-400 font-bold">+{currentQuiz.xpReward} XP</span>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-relaxed">
                    {currentQuiz.question[language]}
                  </h3>

                  {/* Options */}
                  <div className="space-y-2">
                    {currentQuiz.options[language].map((opt, idx) => {
                      const isSelected = selectedOption === idx;

                      return (
                        <div
                          key={idx}
                          onClick={() => handleSelectOption(idx)}
                          className={`p-3 rounded-xl border cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-cyan-950/60 border-cyan-400 text-white'
                              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-5 h-5 rounded-full border border-slate-600 flex items-center justify-center text-xs font-mono">
                              {String.fromCharCode(65 + idx)}
                            </span>
                            <span className="text-xs">{opt}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Submit / Next Button */}
                  {!quizSubmitted ? (
                    <button
                      onClick={handleSubmitQuiz}
                      disabled={selectedOption === null}
                      className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg ${
                        selectedOption !== null
                          ? 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-cyan-500/20'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {t.submitAnswer}
                    </button>
                  ) : (
                    <div className="space-y-3">
                      <div
                        className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-bold ${
                          selectedOption === currentQuiz.correctIndex
                            ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300'
                            : 'bg-rose-950/60 border-rose-500/60 text-rose-300'
                        }`}
                      >
                        {selectedOption === currentQuiz.correctIndex ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            <span>{t.correctAnswer}</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4 text-rose-400" />
                            <span>{t.wrongAnswer}</span>
                          </>
                        )}
                      </div>

                      <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
                        <span className="font-bold text-cyan-400 block mb-1">الشرح الهندسي:</span>
                        {currentQuiz.explanation[language]}
                      </div>

                      <button
                        onClick={handleNextQuiz}
                        className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all"
                      >
                        {t.nextQuestion}
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-400 text-xs font-mono">
                  لا توجد اختبارات إضافية لهذا التخصص حالياً.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
