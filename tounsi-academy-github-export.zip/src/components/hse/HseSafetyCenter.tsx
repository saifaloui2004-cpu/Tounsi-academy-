/**
 * NEXUS WORKSHOP — Occupational Health, Safety & Environment (HSE) Center
 * Focuses on LOTO protocols, PPE requirements, Arc Flash safety, and industrial hazard prevention.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState } from 'react';
import { Language } from '../../types';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  ShieldAlert, ShieldCheck, AlertTriangle, CheckCircle2, 
  Lock, HardHat, Glasses, Zap, Flame, Gauge, Wrench, Sparkles 
} from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
}

export const HseSafetyCenter: React.FC<Props> = ({ language, onRewardXP }) => {
  const t = i18n[language];
  const [lotoStepCompleted, setLotoStepCompleted] = useState<number[]>([]);
  const [quizAnswered, setQuizAnswered] = useState<boolean>(false);
  const [quizCorrect, setQuizCorrect] = useState<boolean | null>(null);

  const lotoSteps = [
    {
      id: 1,
      title: {
        ar: '1. الإشعار والتحضير (Preparation & Notification)',
        fr: '1. Notification et Préparation',
        en: '1. Preparation & Notification',
      },
      desc: {
        ar: 'إخطار جميع المشغلين وفنيي الإنتاج بقرار إيقاف المعدة وعزل الطاقة.',
        fr: 'Informer les opérateurs de l’arrêt imminent de la machine.',
        en: 'Notify affected operators and supervisors of upcoming energy isolation.',
      },
    },
    {
      id: 2,
      title: {
        ar: '2. إيقاف التشغيل النظامي (Normal Shutdown)',
        fr: '2. Arrêt Normal de l’Équipement',
        en: '2. Normal Equipment Shutdown',
      },
      desc: {
        ar: 'إيقاف المعدة عبر زر الإيقاف الطبيعي واتباع التسلسل الآمن.',
        fr: 'Arrêter l’équipement via les boutons de service normaux.',
        en: 'Shut down equipment using standard operating controls and switches.',
      },
    },
    {
      id: 3,
      title: {
        ar: '3. العزل الفعلي للطاقة (Energy Isolation)',
        fr: '3. Isolation des Sources d’Énergie',
        en: '3. Energy Source Isolation',
      },
      desc: {
        ar: 'فصل قواطع القوى الرئيسية الكهربائية وإغلاق صمامات الإمداد الهيدروليكي والغازي.',
        fr: 'Couper les sectionneurs électriques et fermer les vannes de fluides.',
        en: 'Disconnect main electrical breakers and close hydraulic/pneumatic supply valves.',
      },
    },
    {
      id: 4,
      title: {
        ar: '4. تطبيق القفل والوسم (Lockout / Tagout - LOTO)',
        fr: '4. Pose de Cadenas et Étiquettes (LOTO)',
        en: '4. Lockout / Tagout (LOTO) Application',
      },
      desc: {
        ar: 'تركيب القفل الشخصي وبطاقة التحذير على كل نقطة عزل لمنع إعادة التشغيل.',
        fr: 'Poser les cadenas personnels et étiquettes sur chaque organe d’isolation.',
        en: 'Attach personal safety padlocks and warning tags to all energy isolation points.',
      },
    },
    {
      id: 5,
      title: {
        ar: '5. تفريغ الطاقة المتبقية (Dissipation of Residual Energy)',
        fr: '5. Dissipation de l’Énergie Résiduelle',
        en: '5. Dissipation of Residual Energy',
      },
      desc: {
        ar: 'تفريغ الضغط في المجمعات الهيدروليكية، تصريف الشحنات المكثفة، وتأمين الأجزاء المعلقة.',
        fr: 'Purger les accumulateurs, décharger les condensateurs et caler les charges.',
        en: 'Bleed hydraulic pressure accumulators, discharge capacitors, and block raised mechanisms.',
      },
    },
    {
      id: 6,
      title: {
        ar: '6. التحقق من غياب الجهد (Verification / VAT)',
        fr: '6. Vérification d’Absence de Tension (VAT)',
        en: '6. Zero Energy State Verification',
      },
      desc: {
        ar: 'استخدام جهاز فحص الجهد المعتمد للتأكد التام من خلو المعدة من أي طاقة متبقية.',
        fr: 'Vérifier l’absence effective d’énergie (zéro tension, zéro pression).',
        en: 'Use certified test instruments to verify zero energy state prior to wrenching.',
      },
    },
  ];

  const handleToggleLotoStep = (id: number) => {
    if (lotoStepCompleted.includes(id)) {
      setLotoStepCompleted(lotoStepCompleted.filter((s) => s !== id));
    } else {
      const next = [...lotoStepCompleted, id];
      setLotoStepCompleted(next);
      sound.playBeep(900, 0.05);
      if (next.length === lotoSteps.length) {
        sound.playSuccess();
        onRewardXP(50);
      }
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 md:p-6 gap-6 overflow-y-auto">
      {/* HSE Header Banner */}
      <div className="rounded-2xl border border-emerald-500/30 bg-gradient-to-r from-slate-900 via-[#0a1818] to-slate-900 p-6 shadow-2xl bg-tech-grid space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold">
          <ShieldAlert className="w-4 h-4 text-emerald-400" />
          <span>OCCUPATIONAL HEALTH, SAFETY & ENVIRONMENT (HSE)</span>
        </div>
        <h1 className="text-xl md:text-3xl font-black text-white tracking-wide">
          مركز الصحة والسلامة المهنية وإجراءات LOTO
        </h1>
        <p className="text-xs md:text-sm text-slate-300 leading-relaxed max-w-3xl font-sans">
          السلامة أولاً وقبل كل تشغيل. يفرض مركز السلامة معايير العزل الصارمة LOTO، استخدام معدات الوقاية الشخصية (PPE)، وتجنب الأقواس الكهربائية وحوادث الحقن الهيدروليكي.
        </p>
        <div className="flex items-center gap-3 text-xs font-mono text-slate-400 pt-1">
          <span className="text-emerald-400 font-bold">ISO 45001 & NFPA 70E Standards</span>
          <span>•</span>
          <span className="text-orange-400 font-bold">By Saif Eddine Aloui — فلسطين في القلب 🇵🇸</span>
        </div>
      </div>

      {/* Main Grid: LOTO Protocol Checklist (Left) + PPE Matrix (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LOTO Interactive Protocol (Left 7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
              <Lock className="w-4 h-4 text-cyan-400" />
              بروتوكول القفل والوسم الإلزامي (LOTO 6-Step Protocol)
            </h2>
            <span className="text-xs font-mono text-cyan-400 font-bold">
              {lotoStepCompleted.length} / 6 خطوات
            </span>
          </div>

          <div className="space-y-2.5">
            {lotoSteps.map((step) => {
              const isDone = lotoStepCompleted.includes(step.id);

              return (
                <div
                  key={step.id}
                  onClick={() => handleToggleLotoStep(step.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isDone
                      ? 'bg-emerald-950/50 border-emerald-500/60 text-emerald-200'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <h3 className="text-xs font-bold text-white flex items-center gap-2">
                        {step.title[language]}
                      </h3>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                        {step.desc[language]}
                      </p>
                    </div>

                    <div
                      className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 ${
                        isDone ? 'bg-emerald-500 border-emerald-400 text-black' : 'border-slate-600'
                      }`}
                    >
                      {isDone && <CheckCircle2 className="w-4 h-4" />}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {lotoStepCompleted.length === lotoSteps.length && (
            <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-xs font-bold flex items-center gap-2 animate-pulse">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>أحسنت! لقد استكملت كافة خطوات القفل والوسم بنجاح (+50 XP). المعدة معزولة وآمنة للصيانة.</span>
            </div>
          )}
        </div>

        {/* PPE & Industrial Hazards Matrix (Right 5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <h2 className="text-sm font-bold text-white flex items-center gap-2 font-mono pb-3 border-b border-slate-800">
              <HardHat className="w-4 h-4 text-orange-400" />
              معدات الوقاية الشخصية (PPE Matrix)
            </h2>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-cyan-950 text-cyan-400">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block">مخاطر الأقواس الكهربائية (Arc Flash)</span>
                  <span className="text-[11px] text-slate-400">قفازات عازلة 1000V + خوذة وجه واقية ARC-Rated 40 cal/cm²</span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-950 text-orange-400">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block">مخاطر الزيت الحراري الساخن</span>
                  <span className="text-[11px] text-slate-400">ملابس مقاومة للحريق + نظارات واقية للوجه بالكامل</span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400">
                  <Gauge className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block">مخاطر الحقن الهيدروليكي (280 bar)</span>
                  <span className="text-[11px] text-slate-400">ممنوع لمس التسريبات باليد المجردة؛ استخدام الورق المقوى للفحص</span>
                </div>
              </div>
            </div>
          </div>

          {/* Safety Rule Card */}
          <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-4 text-xs text-amber-200/90 leading-relaxed space-y-1.5 shadow-lg">
            <span className="font-bold flex items-center gap-1.5 text-amber-400">
              <AlertTriangle className="w-4 h-4" />
              القاعدة الذهبية في NEXUS WORKSHOP:
            </span>
            لا توجد مهمة إنتاجية أو صيانة أسرع أو أهم من حياة الإنسان. أي تجاوز لإجراءات السلامة يعرض مرتكبه للفصل والمساءلة الفورية.
          </div>
        </div>
      </div>
    </div>
  );
};
