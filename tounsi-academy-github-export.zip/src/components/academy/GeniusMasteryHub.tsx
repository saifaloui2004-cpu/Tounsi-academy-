/**
 * NEXUS TOUNSI — Genius Mastery & Rapid Micro-Learning Hub
 * From Beginner to Genius: Simplified explanations, rapid memory anchors, and flashcards.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState } from 'react';
import { Language } from '../../types';
import { i18n } from '../../i18n/translations';
import { sound } from '../../utils/audio';
import { Sparkles, Zap, Award, BookOpen, Brain, CheckCircle2, ChevronRight, Flame, RotateCcw, Lightbulb } from 'lucide-react';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
}

interface MasteryLevel {
  id: string;
  levelNum: number;
  title: { ar: string; fr: string; en: string };
  badge: string;
  description: { ar: string; fr: string; en: string };
  goldenRule: { ar: string; fr: string; en: string };
  rapidFlashcards: {
    question: { ar: string; fr: string; en: string };
    answer: { ar: string; fr: string; en: string };
  }[];
}

const masteryLevels: MasteryLevel[] = [
  {
    id: 'tier_1',
    levelNum: 1,
    title: {
      ar: 'المستوى الأول: المبتدئ (The Foundation)',
      fr: 'Niveau 1: Débutant (Les Fondations)',
      en: 'Level 1: Beginner (The Foundation)',
    },
    badge: '🌱 مبتدئ ذكي',
    description: {
      ar: 'فهم المفاهيم الصناعية والكهربائية بأبسط تشبيهات الحياة اليومية لتثبيت الفكرة في العقل بلا تعقيد.',
      fr: 'Comprendre les bases industrielles avec des analogies simples de la vie quotidienne.',
      en: 'Understand industrial basics using simple, everyday analogies for effortless grasp.',
    },
    goldenRule: {
      ar: 'الكهرباء مثل تدفق ماء النهر: الفولت هو ضغط الماء، والأمبير هو كمية تدفق الماء.',
      fr: 'L’électricité est comme un débit d’eau: la tension est la pression, le courant est le débit.',
      en: 'Electricity is like water flow: Voltage is water pressure, Current is flow volume.',
    },
    rapidFlashcards: [
      {
        question: { ar: 'ما هو الفولت (Voltage) باختصار؟', fr: 'Qu’est-ce que la tension (Voltage)?', en: 'What is Voltage?' },
        answer: { ar: 'فرق الجهد أو ضغط الكهرباء الدافع للإلكترونات.', fr: 'La pression électrique poussant les électrons.', en: 'Electrical pressure pushing electrons through a circuit.' },
      },
      {
        question: { ar: 'ما هو الأمبير (Current) باختصار؟', fr: 'Qu’est-ce que l’intensité (Current)?', en: 'What is Electric Current?' },
        answer: { ar: 'كمية تدفق التيار الكهربائي عبر الموصل.', fr: 'La quantité de courant traversant le conducteur.', en: 'The volume rate of electrical flow through a conductor.' },
      },
    ],
  },
  {
    id: 'tier_2',
    levelNum: 2,
    title: {
      ar: 'المستوى الثاني: المتوسط (The Practitioner)',
      fr: 'Niveau 2: Praticien (Application)',
      en: 'Level 2: Intermediate (Practitioner)',
    },
    badge: '⚡ فني محترف',
    description: {
      ar: 'قراءة مخططات القوى والتحكم، فهم عمل القواطع والمرحلات والمحركات الحثية.',
      fr: 'Lecture des schémas de puissance et de commande, contacteurs et moteurs.',
      en: 'Reading power/control schematics, contactors, relays, and induction motors.',
    },
    goldenRule: {
      ar: 'إقلاع نجمي-مثلثي (Star-Delta) يخفض تيار البدء إلى 1/3 لئلا يحترق المحرك.',
      fr: 'Le démarrage Étoile-Triangle réduit le courant de démarrage à 1/3.',
      en: 'Star-Delta starting reduces inrush starting current to 1/3 of DOL current.',
    },
    rapidFlashcards: [
      {
        question: { ar: 'لماذا نستخدم المرحل الحراري (Thermal Overload)؟', fr: 'Pourquoi utiliser un relais thermique?', en: 'Why use a thermal overload relay?' },
        answer: { ar: 'لحماية محركات الحث من السخونة الزائدة الناتجة عن زيادة الحمل.', fr: 'Pour protéger les moteurs contre les surcharges thermiques.', en: 'To protect induction motors from overheating due to mechanical overload.' },
      },
    ],
  },
  {
    id: 'tier_3',
    levelNum: 3,
    title: {
      ar: 'المستوى الثالث: المتقدم (The Troubleshooter)',
      fr: 'Niveau 3: Avancé (Expert Diagnostic)',
      en: 'Level 3: Advanced (Troubleshooter)',
    },
    badge: '🔧 خبير تشخيص',
    description: {
      ar: 'القدرة على تشخيص الأعطال المعقدة في المصانع، حساب عزم الدوران، ومراقبة أنظمة الزيت الحراري.',
      fr: 'Diagnostic de pannes industrielles complexes et systèmes thermiques.',
      en: 'Diagnosing complex industrial breakdowns and thermal fluid systems.',
    },
    goldenRule: {
      ar: 'عند سماع صوت طنين وهبوط سرعة المحرك، فكر فوراً في فقدان أحد الأطوار (Single Phasing).',
      fr: 'Bourdonnement et chute de vitesse = penser immédiatement à une coupure de phase.',
      en: 'Humming and motor slowdown = immediately suspect single phasing (loss of phase).',
    },
    rapidFlashcards: [
      {
        question: { ar: 'ما هو المؤقت TON في برمجيات الـ PLC؟', fr: 'Qu’est-ce qu’un temporisateur TON en API?', en: 'What is a TON timer in PLC?' },
        answer: { ar: 'مؤقت التأخير عند التشغيل (Timer On-Delay).', fr: 'Temporisateur avec retard à l’enclenchement.', en: 'Timer On-Delay: delays output activation after input goes true.' },
      },
    ],
  },
  {
    id: 'tier_4',
    levelNum: 4,
    title: {
      ar: 'المستوى الرابع: العبقري والماستر (The Genius Master)',
      fr: 'Niveau 4: Maître & Génie (Innovation)',
      en: 'Level 4: Genius Master (Innovator)',
    },
    badge: '👑 عبقري الصناعة',
    description: {
      ar: 'إتقان هندسة الأتمتة الكاملة، تحسين كفاءة المصانع OEE، والابتكار الهندسي.',
      fr: 'Maîtrise de l’automatisation globale, optimisation OEE et innovation.',
      en: 'Complete automation mastery, OEE plant optimization, and engineering innovation.',
    },
    goldenRule: {
      ar: 'العبقرية في الصيانة هي منع العطل قبل وقوعه عبر الصيانة التنبؤية (Predictive Maintenance).',
      fr: 'Le génie de la maintenance réside dans la prévention par la maintenance prédictive.',
      en: 'Maintenance genius is preventing failure before it occurs via predictive vibration & thermal analysis.',
    },
    rapidFlashcards: [
      {
        question: { ar: 'ما هي معادلة كفاءة المعدات الإجمالية OEE؟', fr: 'Quelle est la formule du TRS (OEE)?', en: 'What is the OEE formula?' },
        answer: { ar: 'التوفر × الأداء × الجودة (Availability × Performance × Quality).', fr: 'Disponibilité × Performance × Qualité.', en: 'Availability × Performance × Quality.' },
      },
    ],
  },
];

export const GeniusMasteryHub: React.FC<Props> = ({ language, onRewardXP }) => {
  const t = i18n[language];
  const [revealedCards, setRevealedCards] = useState<Record<string, boolean>>({});

  const toggleReveal = (key: string) => {
    setRevealedCards((p) => {
      const nextState = { ...p, [key]: !p[key] };
      if (nextState[key]) {
        onRewardXP(10);
        sound.playSuccess();
      }
      return nextState;
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-5xl mx-auto px-4">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 border border-purple-500/30 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300 font-mono text-xs font-bold">
            <Brain className="w-4 h-4 text-purple-400" />
            <span>NEXUS GENIUS MASTERY • FROM BEGINNER TO GENIUS</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black text-white">
            {language === 'ar' ? 'سلم العبقرية والتعلّم السريع المبسط' : language === 'fr' ? 'Échelle de Maîtrise & Apprentissage Accéléré' : 'Genius Mastery Ladder & Rapid Learning'}
          </h2>
          <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
            {language === 'ar'
              ? 'مصمم خصيصاً ليأخذك من الصفر (المبتدئ) إلى قمة الإبداع (العبقري) بطريقة بسيطة جداً، مع قواعد ذهبية وبطاقات ذاكرة سريعة لتثبيت المعلومة للأبد.'
              : 'Designed to take you from absolute zero to genius mastery simply, with golden rules and flashcards for permanent memory.'}
          </p>
        </div>
      </div>

      {/* 4 Mastery Tiers */}
      <div className="space-y-6">
        {masteryLevels.map((tier) => (
          <div key={tier.id} className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-7 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-black font-black font-mono shadow-lg shadow-purple-500/25">
                  {tier.levelNum}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">{tier.title[language]}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{tier.description[language]}</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300 text-xs font-bold">
                {tier.badge}
              </span>
            </div>

            {/* Golden Rule Highlight */}
            <div className="p-4 bg-purple-950/30 border border-purple-500/40 rounded-2xl flex items-start gap-3">
              <Lightbulb className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-mono font-bold text-purple-300 block mb-1">
                  {language === 'ar' ? 'القاعدة الذهبية للحفظ السريع:' : 'Golden Rule for Rapid Memorization:'}
                </span>
                <p className="text-xs md:text-sm text-slate-200 font-medium leading-relaxed">{tier.goldenRule[language]}</p>
              </div>
            </div>

            {/* Flashcards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tier.rapidFlashcards.map((card, cIdx) => {
                const cardKey = `${tier.id}_${cIdx}`;
                const isRevealed = revealedCards[cardKey];

                return (
                  <div
                    key={cIdx}
                    onClick={() => toggleReveal(cardKey)}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                      isRevealed
                        ? 'bg-purple-950/20 border-purple-500/50 shadow-lg shadow-purple-500/10'
                        : 'bg-slate-950/80 hover:bg-slate-800 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-mono text-purple-400 font-bold uppercase">FLASHCARD #{cIdx + 1} (+10 XP)</span>
                      <span className="text-xs text-slate-400">{isRevealed ? 'انقر لإخفاء الإجابة' : 'انقر لكشف الإجابة 💡'}</span>
                    </div>
                    <p className="text-xs font-bold text-white mb-2">{card.question[language]}</p>
                    {isRevealed && (
                      <div className="pt-2 border-t border-purple-500/30 text-xs text-purple-200 font-medium animate-fadeIn leading-relaxed">
                        ✨ {card.answer[language]}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
