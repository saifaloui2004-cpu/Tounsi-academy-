/**
 * NEXUS TOUNSI — NEXUS ACADEMY
 * Comprehensive Educational Platform (10 Categories, Courses, Lessons, Search, Bookmarks, and Progress)
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

import React, { useState, useMemo } from 'react';
import { ACADEMY_CATEGORIES, ACADEMY_COURSES } from '../../data/academyData';
import { AcademyCategory, AcademyCourse, AcademyLesson, Language } from '../../types';
import { sound } from '../../utils/audio';
import { i18n } from '../../i18n/translations';
import { 
  GraduationCap, Search, Bookmark, BookmarkCheck, Clock, Award, 
  BookOpen, ChevronRight, CheckCircle2, Sparkles, Filter, X, ArrowUpRight, ShieldAlert, Brain 
} from 'lucide-react';
import { GeniusMasteryHub } from './GeniusMasteryHub';

interface Props {
  language: Language;
  onRewardXP: (xp: number) => void;
  bookmarkedCourses: string[];
  onToggleBookmark: (courseId: string) => void;
  completedLessons: string[];
  onMarkLessonCompleted: (lessonId: string) => void;
  onNavigateWorkbench?: (tab: string) => void;
}

export const NexusAcademy: React.FC<Props> = ({
  language,
  onRewardXP,
  bookmarkedCourses,
  onToggleBookmark,
  completedLessons,
  onMarkLessonCompleted,
  onNavigateWorkbench,
}) => {
  const t = i18n[language];
  const [academyTab, setAcademyTab] = useState<'courses' | 'genius'>('courses');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [activeCourse, setActiveCourse] = useState<AcademyCourse | null>(null);
  const [activeLesson, setActiveLesson] = useState<AcademyLesson | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, { selected: number; confirmed: boolean }>>({});

  // Filter courses based on search, category, and level
  const filteredCourses = useMemo(() => {
    return ACADEMY_COURSES.filter((course) => {
      const matchesCategory = selectedCategory === 'all' || course.categoryId === selectedCategory;
      const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;
      const matchesSearch =
        !searchQuery.trim() ||
        course.title[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.description[language].toLowerCase().includes(searchQuery.toLowerCase());

      return matchesCategory && matchesLevel && matchesSearch;
    });
  }, [selectedCategory, selectedLevel, searchQuery, language]);

  const handleOpenCourse = (course: AcademyCourse) => {
    setActiveCourse(course);
    setActiveLesson(course.lessons[0] || null);
    sound.playRelayClick();
  };

  const handleCompleteActiveLesson = (lesson: AcademyLesson) => {
    if (!completedLessons.includes(lesson.id)) {
      onMarkLessonCompleted(lesson.id);
      onRewardXP(50);
      sound.playSuccess();
    }
  };

  const handleAnswerLessonQuiz = (lesson: AcademyLesson, optionIdx: number) => {
    const q = lesson.quizQuestion;
    if (!q) return;
    if (quizAnswers[lesson.id]?.confirmed) return;

    const isCorrect = optionIdx === q.correctIndex;
    setQuizAnswers((prev) => ({ ...prev, [lesson.id]: { selected: optionIdx, confirmed: true } }));
    if (isCorrect) {
      onRewardXP(q.xpReward);
      sound.playSuccess();
    } else {
      sound.playAlarm();
    }
  };

  const isAr = language === 'ar';
  const isFr = language === 'fr';

  return (
    <div className="flex flex-col h-full bg-[#080d16] text-slate-100 p-4 md:p-6 gap-6 overflow-y-auto">
      {/* Academy Header Banner */}
      <div className="relative rounded-2xl border border-cyan-500/30 bg-gradient-to-r from-slate-900 via-[#0d1627] to-slate-900 p-6 shadow-2xl bg-tech-grid">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono text-xs font-bold">
              <GraduationCap className="w-4 h-4 text-cyan-400" />
              <span>TOUNSI ACADEMY — ACADEMIC & VOCATIONAL PLATFORM</span>
            </div>
            <h1 className="text-xl md:text-3xl font-black text-white tracking-wide">
              {isAr
                ? 'أكاديمية التعليم التقني والتكوين المهني الشامل'
                : isFr
                ? 'Académie d’Enseignement Technique et Formation Professionnelle'
                : 'Comprehensive Technical & Vocational Engineering Academy'}
            </h1>
            <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-sans">
              {isAr
                ? 'مسارات تكوين متدرجة من المبتدئ إلى العبقري في 10 تخصصات تقنية وهندسية، تجمع بين الفهم السريع والمحاكاة التطبيقية دون إنترنت.'
                : isFr
                ? 'Parcours progressifs du niveau débutant à expert dans 10 spécialités techniques, alliant mémorisation rapide et simulation hors-ligne.'
                : 'Progressive learning tracks from beginner to genius across 10 technical specialties combining rapid mastery with offline simulation.'}
            </p>
            <div className="flex items-center gap-3 text-xs font-mono text-slate-400 pt-1">
              <span className="text-orange-400 font-bold">By Saif Eddine Aloui</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">{t.palestineMotto}</span>
            </div>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl text-center">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">
                {isAr ? 'التخصصات' : isFr ? 'Spécialités' : 'Specialties'}
              </span>
              <span className="text-lg font-bold font-mono text-cyan-400">
                {isAr ? '10 مجالات' : isFr ? '10 Domaines' : '10 Fields'}
              </span>
            </div>
            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl text-center">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">
                {isAr ? 'المحفوظات' : isFr ? 'Favoris' : 'Bookmarks'}
              </span>
              <span className="text-lg font-bold font-mono text-amber-400">
                {bookmarkedCourses.length} {isAr ? 'دورة' : isFr ? 'Cours' : 'Courses'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Academy Sub-Tabs Switcher */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => { setAcademyTab('courses'); sound.playRelayClick(); }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
            academyTab === 'courses' ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/25' : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>{isAr ? 'الدورات الأكاديمية (10 تخصصات)' : isFr ? 'Cours Académiques (10 Domaines)' : 'Academic Courses (10 Specialties)'}</span>
        </button>
        <button
          onClick={() => { setAcademyTab('genius'); sound.playRelayClick(); }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
            academyTab === 'genius' ? 'bg-purple-500 text-black shadow-lg shadow-purple-500/25' : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <Brain className="w-4 h-4 text-purple-400" />
          <span>{isAr ? 'سلم العبقرية والتعلّم السريع (Flashcards)' : isFr ? 'Échelle de Maîtrise & Flashcards' : 'Genius Mastery & Fast Flashcards'}</span>
        </button>
      </div>

      {academyTab === 'genius' ? (
        <GeniusMasteryHub language={language} onRewardXP={onRewardXP} />
      ) : (
        <>
          {/* Search & Filter Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-md">
        {/* Search input */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 rtl:right-3 ltr:left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isAr
                ? 'ابحث عن دورة، درس، معادلة أو موضوع هندسي...'
                : isFr
                ? 'Rechercher un cours, une formule ou un thème...'
                : 'Search courses, lessons, formulas, or topics...'
            }
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-9 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>

        {/* Level filter */}
        <div className="flex flex-wrap items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
          {(['all', 'Beginner', 'Intermediate', 'Advanced', 'Expert'] as const).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setSelectedLevel(lvl)}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                selectedLevel === lvl
                  ? 'bg-cyan-500 text-black font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lvl === 'all' && (isAr ? 'الكل' : isFr ? 'Tous' : 'All')}
              {lvl === 'Beginner' && (isAr ? 'مبتدئ' : isFr ? 'Débutant' : 'Beginner')}
              {lvl === 'Intermediate' && (isAr ? 'متوسط' : isFr ? 'Intermédiaire' : 'Intermediate')}
              {lvl === 'Advanced' && (isAr ? 'متقدم' : isFr ? 'Avancé' : 'Advanced')}
              {lvl === 'Expert' && (isAr ? 'خبير' : isFr ? 'Expert' : 'Expert')}
            </button>
          ))}
        </div>
      </div>

      {/* Category Horizontal Scroll Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
            selectedCategory === 'all'
              ? 'bg-cyan-500 text-black border-cyan-400 shadow-md font-bold'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          {isAr ? 'جميع التخصصات (10)' : isFr ? 'Toutes les Spécialités (10)' : 'All Specialties (10)'}
        </button>

        {ACADEMY_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setSelectedCategory(cat.id);
              sound.playRelayClick();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
              selectedCategory === cat.id
                ? 'bg-cyan-500 text-black border-cyan-400 shadow-md font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat.name[language]}
          </button>
        ))}
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCourses.map((course) => {
          const isBookmarked = bookmarkedCourses.includes(course.id);

          return (
            <div
              key={course.id}
              onClick={() => handleOpenCourse(course)}
              className="bg-slate-900/80 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-4 flex flex-col justify-between space-y-3 cursor-pointer transition-all hover:bg-slate-850 hover:shadow-xl hover:shadow-cyan-950/20 group"
            >
              <div className="flex items-start justify-between">
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    course.level === 'Beginner'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : course.level === 'Intermediate'
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                      : 'bg-orange-950 text-orange-400 border border-orange-800'
                  }`}
                >
                  {course.level}
                </span>

                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-mono text-cyan-400 font-bold">
                    +{course.xpReward} XP
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleBookmark(course.id);
                      sound.playBeep(isBookmarked ? 450 : 850, 0.04);
                    }}
                    className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-amber-400 transition-colors"
                    title={isBookmarked ? (isAr ? 'إزالة من المحفوظات' : 'Remove bookmark') : (isAr ? 'حفظ في المفضلة' : 'Bookmark course')}
                  >
                    {isBookmarked ? (
                      <BookmarkCheck className="w-4 h-4 text-amber-400 fill-amber-400" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors mb-1.5 line-clamp-1">
                  {course.title[language]}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {course.description[language]}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 font-mono">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    {course.durationHours} {isAr ? 'س' : 'h'}
                  </span>
                  <span className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5 text-slate-500" />
                    {course.lessons.length} {isAr ? 'دروس' : isFr ? 'Leçons' : 'Lessons'}
                  </span>
                </div>
                <div className="text-cyan-400 flex items-center gap-1 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">
                  <span>{isAr ? 'بدء الدورة' : isFr ? 'Ouvrir' : 'Start'}</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Course Detail & Lesson Reader Modal */}
      {activeCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-4xl bg-[#090e18] border-2 border-cyan-500/60 rounded-2xl shadow-2xl p-6 text-slate-100 space-y-6 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
                    {activeCourse.level}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    +{activeCourse.xpReward} XP Course
                  </span>
                </div>
                <h2 className="text-base md:text-lg font-bold text-white mt-1">
                  {activeCourse.title[language]}
                </h2>
              </div>

              <button
                onClick={() => setActiveCourse(null)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content: Lessons List + Active Lesson View */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 flex-1 overflow-y-auto">
              {/* Lessons Nav List (Left 4 cols) */}
              <div className="md:col-span-4 space-y-2 border-b md:border-b-0 md:border-l rtl:md:border-l-0 rtl:md:border-r border-slate-800 pr-0 md:pr-2 rtl:md:pr-0 rtl:md:pl-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  {isAr ? 'قائمة الدروس' : isFr ? 'Liste des Leçons' : 'Lessons'} ({activeCourse.lessons.length})
                </span>

                <div className="space-y-1.5 max-h-72 overflow-y-auto">
                  {activeCourse.lessons.map((lesson) => {
                    const isSelected = activeLesson?.id === lesson.id;
                    const isCompleted = completedLessons.includes(lesson.id);

                    return (
                      <div
                        key={lesson.id}
                        onClick={() => {
                          setActiveLesson(lesson);
                          sound.playRelayClick();
                        }}
                        className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-cyan-950/60 border-cyan-400 text-white shadow-md'
                            : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold line-clamp-1">{lesson.title[language]}</span>
                          {isCompleted && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {lesson.durationMin} {isAr ? 'دقيقة' : 'min'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Active Lesson Content (Right 8 cols) */}
              <div className="md:col-span-8 space-y-4 overflow-y-auto pr-1">
                {activeLesson ? (
                  <div className="space-y-4">
                    <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                      <h3 className="text-sm font-bold text-cyan-300 mb-1">
                        {activeLesson.title[language]}
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {activeLesson.summary[language]}
                      </p>
                    </div>

                    {/* Lesson Sections */}
                    <div className="space-y-3">
                      {activeLesson.sections.map((sec, sIdx) => (
                        <div key={sIdx} className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800 space-y-2">
                          <h4 className="text-xs font-bold text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                            {sec.heading[language]}
                          </h4>
                          <p className="text-xs text-slate-300 leading-relaxed font-sans">
                            {sec.body[language]}
                          </p>

                          {/* Formulas if present */}
                          {sec.formulas && sec.formulas.length > 0 && (
                            <div className="bg-slate-900/90 p-2.5 rounded-lg border border-cyan-500/30 font-mono text-xs text-cyan-300 space-y-1">
                              <span className="text-[10px] text-slate-400 block font-sans">
                                {isAr ? 'المعادلة الفيزيائية:' : isFr ? 'Équation Technique :' : 'Engineering Formula:'}
                              </span>
                              {sec.formulas.map((f, fIdx) => (
                                <div key={fIdx} className="font-bold">{f}</div>
                              ))}
                            </div>
                          )}

                          {/* Key Rules if present */}
                          {sec.keyRules && sec.keyRules[language] && (
                            <div className="pt-1">
                              <span className="text-[11px] font-bold text-amber-400 block mb-1">
                                {isAr ? 'قواعد السلامة والمعايير:' : isFr ? 'Règles & Normes Clés :' : 'Safety Rules & Standards:'}
                              </span>
                              <ul className="space-y-1 text-xs text-slate-300">
                                {sec.keyRules[language].map((r, rIdx) => (
                                  <li key={rIdx} className="flex items-center gap-1.5">
                                    <span className="text-amber-400">✓</span>
                                    <span>{r}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Practical Exercise Box */}
                    {activeLesson.practicalExercise && (
                      <div className="bg-gradient-to-r from-cyan-950/60 to-slate-900 p-3.5 rounded-xl border border-cyan-500/40 space-y-2">
                        <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-cyan-400" />
                          {isAr ? 'التمرين العملي بالمختبر:' : isFr ? 'Exercice Pratique au Laboratoire :' : 'Hands-On Lab Exercise:'}
                        </span>
                        <p className="text-xs text-slate-200 leading-relaxed">
                          {activeLesson.practicalExercise[language]}
                        </p>
                      </div>
                    )}

                    {/* Interactive Mini Quiz Check */}
                    {activeLesson.quizQuestion && (
                      <div className="bg-slate-900/90 border border-purple-500/40 rounded-xl p-4 space-y-3">
                        <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                          <span className="flex items-center gap-1.5">
                            <Brain className="w-4 h-4 text-purple-400" />
                            {isAr ? 'اختبار الفهم السريع' : isFr ? 'Quiz Rapide de Compréhension' : 'Quick Mastery Check'}
                          </span>
                          <span className="font-mono text-amber-400">+{activeLesson.quizQuestion.xpReward} XP</span>
                        </div>
                        <p className="text-xs font-bold text-white leading-relaxed">
                          {activeLesson.quizQuestion.question[language]}
                        </p>
                        <div className="grid grid-cols-1 gap-2">
                          {activeLesson.quizQuestion.options[language].map((opt, oIdx) => {
                            const state = quizAnswers[activeLesson.id];
                            const isSelected = state?.selected === oIdx;
                            const isCorrectOpt = oIdx === activeLesson.quizQuestion!.correctIndex;
                            let btnStyle = 'bg-slate-950 border-slate-800 hover:border-purple-400/50 text-slate-200';
                            if (state?.confirmed) {
                              if (isCorrectOpt) {
                                btnStyle = 'bg-emerald-950/70 border-emerald-500 text-emerald-300 font-bold';
                              } else if (isSelected) {
                                btnStyle = 'bg-rose-950/70 border-rose-500 text-rose-300';
                              }
                            }
                            return (
                              <button
                                key={oIdx}
                                onClick={() => handleAnswerLessonQuiz(activeLesson, oIdx)}
                                className={`text-start p-2.5 rounded-lg border text-xs transition-all ${btnStyle}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                        {quizAnswers[activeLesson.id]?.confirmed && (
                          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-cyan-200 leading-relaxed">
                            {activeLesson.quizQuestion.explanation[language]}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Completion Action */}
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-xs text-slate-400 font-mono">
                        {completedLessons.includes(activeLesson.id)
                          ? (isAr ? 'تم إتمام هذا الدرس' : isFr ? 'Leçon terminée' : 'Lesson completed')
                          : (isAr ? '+50 XP عند الإتمام' : '+50 XP on completion')}
                      </span>
                      <button
                        onClick={() => handleCompleteActiveLesson(activeLesson)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                          completedLessons.includes(activeLesson.id)
                            ? 'bg-emerald-600 text-white'
                            : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-cyan-500/25 active:scale-95'
                        }`}
                      >
                        {completedLessons.includes(activeLesson.id)
                          ? (isAr ? 'مكتمل ✓' : isFr ? 'Terminé ✓' : 'Completed ✓')
                          : (isAr ? 'إتمام الدرس وحفظ التقدم' : isFr ? 'Valider la Leçon' : 'Complete Lesson')}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-slate-400 text-xs font-mono">
                    {isAr ? 'اختر درساً من القائمة لبدء القراءة والمحاكاة.' : isFr ? 'Sélectionnez une leçon dans la liste.' : 'Select a lesson from the list to begin.'}
                  </div>
                )}
              </div>
            </div>

            {/* Unofficial Disclaimer */}
            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400 text-center font-mono">
              {t.certificateNotice}
            </div>
          </div>
        </div>
      )}
      </>
      )}
    </div>
  );
};
