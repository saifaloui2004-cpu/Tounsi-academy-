/**
 * NEXUS WORKSHOP — ADVANCED SIMULATION CENTER
 * Platform Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 * Main Application Orchestrator
 */

import React, { useState, useEffect } from 'react';
import { Capacitor } from '@capacitor/core';
import { App as CapacitorApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { EngineeringLabId, Language, UserProgress } from './types';
import { loadUserProgress, saveUserProgress, DEFAULT_USER_PROGRESS, calculateLevel } from './utils/storage';
import { sound } from './utils/audio';
import { Header } from './components/layout/Header';
import { Navigation, MainTab } from './components/layout/Navigation';
import { WorkshopHub } from './components/overview/WorkshopHub';
import { CircuitCanvas2D } from './components/sim2d/CircuitCanvas2D';
import { Industrial3DViewer } from './components/sim3d/Industrial3DViewer';
import { ThermalOilSimulator } from './components/thermal/ThermalOilSimulator';
import { FaultDiagnosisCenter } from './components/faults/FaultDiagnosisCenter';
import { TrainingCenter } from './components/training/TrainingCenter';
import { NexusAcademy } from './components/academy/NexusAcademy';
import { NexusAITechnician } from './components/ai/NexusAITechnician';
import { HseSafetyCenter } from './components/hse/HseSafetyCenter';
import { PlcSimulator } from './components/sim_plc/PlcSimulator';
import { ScadaDashboard } from './components/scada/ScadaDashboard';
import { EngineeringChallenge } from './components/challenge/EngineeringChallenge';
import { ModuleLabView } from './components/labs/ModuleLabView';
import { CertificateModal } from './components/common/CertificateModal';
import { AboutPrivacyModal } from './components/common/AboutPrivacyModal';

export default function App() {
  const [progress, setProgress] = useState<UserProgress>(() => loadUserProgress());
  const [activeTab, setActiveTab] = useState<MainTab>('overview');
  const [selectedLabId, setSelectedLabId] = useState<EngineeringLabId>('electrical');
  const [certificateOpen, setCertificateOpen] = useState<boolean>(false);
  const [aboutOpen, setAboutOpen] = useState<boolean>(false);
  const [resetConfirmOpen, setResetConfirmOpen] = useState<boolean>(false);

  // Sync sound settings with synthesizer
  useEffect(() => {
    sound.setEnabled(progress.soundEnabled);
  }, [progress.soundEnabled]);

  // Save progress changes
  useEffect(() => {
    saveUserProgress(progress);
  }, [progress]);

  // Set document title and RTL direction
  useEffect(() => {
    document.documentElement.dir = progress.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = progress.language;
  }, [progress.language]);

  // Configure Capacitor Android StatusBar and Hardware Back Button safely
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
    StatusBar.setBackgroundColor({ color: '#070b14' }).catch(() => {});

    const listenerPromise = CapacitorApp.addListener('backButton', () => {
      if (certificateOpen) {
        setCertificateOpen(false);
      } else if (aboutOpen) {
        setAboutOpen(false);
      } else if (resetConfirmOpen) {
        setResetConfirmOpen(false);
      } else if (activeTab !== 'overview') {
        setActiveTab('overview');
      } else {
        CapacitorApp.exitApp();
      }
    });

    return () => {
      listenerPromise.then((handle) => handle.remove()).catch(() => {});
    };
  }, [activeTab, certificateOpen, aboutOpen, resetConfirmOpen]);

  // XP Reward Handler
  const handleRewardXP = (amount: number) => {
    setProgress((prev) => {
      const nextXP = prev.xp + amount;
      const prevLvl = calculateLevel(prev.xp).level;
      const nextLvl = calculateLevel(nextXP).level;

      if (nextLvl > prevLvl) {
        sound.playSuccess();
      }
      return {
        ...prev,
        xp: nextXP,
        level: nextLvl,
      };
    });
  };

  // Language & Dialect Change
  const handleLanguageChange = (lang: Language, dialect?: string) => {
    setProgress((prev) => ({ ...prev, language: lang, dialect: dialect }));
    sound.playRelayClick();
  };

  // Sound Toggle
  const handleToggleSound = () => {
    setProgress((prev) => {
      const nextVal = !prev.soundEnabled;
      sound.setEnabled(nextVal);
      return { ...prev, soundEnabled: nextVal };
    });
  };

  // Lite Mode Toggle
  const handleToggleLiteMode = () => {
    setProgress((prev) => {
      sound.playRelayClick();
      return { ...prev, liteMode: !prev.liteMode };
    });
  };

  // Mark Fault Solved
  const handleMarkFaultSolved = (faultId: string) => {
    setProgress((prev) => {
      if (prev.solvedFaults.includes(faultId)) return prev;
      return {
        ...prev,
        solvedFaults: [...prev.solvedFaults, faultId],
      };
    });
  };

  // Mark Quiz Answered
  const handleMarkQuizAnswered = (quizId: string) => {
    setProgress((prev) => {
      if (prev.answeredQuizzes.includes(quizId)) return prev;
      return {
        ...prev,
        answeredQuizzes: [...prev.answeredQuizzes, quizId],
      };
    });
  };

  // Confirm Reset Progress (In-app modal instead of window.confirm)
  const handleConfirmResetProgress = () => {
    setProgress(DEFAULT_USER_PROGRESS);
    setResetConfirmOpen(false);
    sound.playRelayClick();
  };

  // Update User Name
  const handleUpdateUserName = (name: string) => {
    setProgress((prev) => ({ ...prev, userName: name }));
  };

  // Navigate to a specific lab
  const handleSelectLab = (id: EngineeringLabId) => {
    setSelectedLabId(id);
    if (id === 'sim3d') {
      setActiveTab('3d');
    } else if (id === 'thermal') {
      setActiveTab('thermal');
    } else if (id === 'faults') {
      setActiveTab('faults');
    } else {
      setActiveTab('lab_detail');
    }
  };

  return (
    <div
      dir={progress.language === 'ar' ? 'rtl' : 'ltr'}
      className="min-h-screen flex flex-col bg-[#080d16] text-slate-100 font-sans"
    >
      {/* Global Futuristic Technical Header */}
      <Header
        language={progress.language}
        dialect={progress.dialect}
        onLanguageChange={handleLanguageChange}
        userXP={progress.xp}
        soundEnabled={progress.soundEnabled}
        onToggleSound={handleToggleSound}
        liteMode={progress.liteMode}
        onToggleLiteMode={handleToggleLiteMode}
        onOpenCertificate={() => setCertificateOpen(true)}
        onOpenAbout={() => setAboutOpen(true)}
        onResetProgress={() => setResetConfirmOpen(true)}
      />

      {/* Primary Navigation Bar */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        language={progress.language}
        selectedLabId={selectedLabId}
        onSelectLabId={handleSelectLab}
      />

      {/* Active View Router */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {activeTab === 'overview' && (
          <WorkshopHub
            language={progress.language}
            dialect={progress.dialect}
            onSelectTab={setActiveTab}
            onSelectLab={handleSelectLab}
            userXP={progress.xp}
            solvedFaultCount={progress.solvedFaults.length}
          />
        )}

        {activeTab === '2d' && (
          <CircuitCanvas2D
            language={progress.language}
            onRewardXP={handleRewardXP}
          />
        )}

        {activeTab === '3d' && (
          <Industrial3DViewer
            language={progress.language}
            liteMode={progress.liteMode}
            onRewardXP={handleRewardXP}
          />
        )}

        {activeTab === 'thermal' && (
          <ThermalOilSimulator
            language={progress.language}
            onRewardXP={handleRewardXP}
          />
        )}

        {activeTab === 'faults' && (
          <FaultDiagnosisCenter
            language={progress.language}
            onRewardXP={handleRewardXP}
            solvedFaultIds={progress.solvedFaults}
            onMarkFaultSolved={handleMarkFaultSolved}
          />
        )}

        {activeTab === 'training' && (
          <TrainingCenter
            language={progress.language}
            onRewardXP={handleRewardXP}
            answeredQuizIds={progress.answeredQuizzes}
            onMarkQuizAnswered={handleMarkQuizAnswered}
            onOpenCertificate={() => setCertificateOpen(true)}
            userXP={progress.xp}
          />
        )}

        {activeTab === 'academy' && (
          <NexusAcademy
            language={progress.language}
            onRewardXP={handleRewardXP}
            bookmarkedCourses={progress.bookmarkedCourses || []}
            onToggleBookmark={(courseId) => {
              setProgress((prev) => {
                const bms = prev.bookmarkedCourses || [];
                const nextBms = bms.includes(courseId) ? bms.filter((id) => id !== courseId) : [...bms, courseId];
                return { ...prev, bookmarkedCourses: nextBms };
              });
            }}
            completedLessons={progress.completedLessons || []}
            onMarkLessonCompleted={(lessonId) => {
              setProgress((prev) => {
                const cls = prev.completedLessons || [];
                if (cls.includes(lessonId)) return prev;
                return { ...prev, completedLessons: [...cls, lessonId] };
              });
            }}
          />
        )}

        {activeTab === 'ai_tech' && (
          <NexusAITechnician
            language={progress.language}
            onRewardXP={handleRewardXP}
          />
        )}

        {activeTab === 'hse' && (
          <HseSafetyCenter
            language={progress.language}
            onRewardXP={handleRewardXP}
          />
        )}

        {activeTab === 'plc_studio' && (
          <PlcSimulator
            language={progress.language}
          />
        )}

        {activeTab === 'scada' && (
          <ScadaDashboard
            language={progress.language}
          />
        )}

        {activeTab === 'challenge' && (
          <EngineeringChallenge
            language={progress.language}
            onRewardXP={handleRewardXP}
          />
        )}

        {activeTab === 'lab_detail' && (
          <ModuleLabView
            labId={selectedLabId}
            language={progress.language}
            onRewardXP={handleRewardXP}
            onNavigateTab={(tab) => {
              if (tab === '2d') setActiveTab('2d');
              else if (tab === '3d') setActiveTab('3d');
              else if (tab === 'thermal') setActiveTab('thermal');
              else if (tab === 'faults') setActiveTab('faults');
              else if (tab === 'training') setActiveTab('training');
            }}
          />
        )}
      </main>

      {/* Educational Certificate Modal */}
      <CertificateModal
        isOpen={certificateOpen}
        onClose={() => setCertificateOpen(false)}
        language={progress.language}
        userName={progress.userName}
        onUpdateUserName={handleUpdateUserName}
        userXP={progress.xp}
        userLevel={progress.level}
      />

      {/* About, Privacy & Legal Modal (Uptodown compliance) */}
      <AboutPrivacyModal
        isOpen={aboutOpen}
        onClose={() => setAboutOpen(false)}
        language={progress.language}
      />

      {/* In-app Progress Reset Confirmation Modal (WebView safe) */}
      {resetConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#090e18] border border-rose-500/50 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">
              {progress.language === 'ar'
                ? 'إعادة ضبط التقدم ونقاط الخبرة'
                : progress.language === 'fr'
                ? 'Réinitialiser la progression ?'
                : 'Reset Progress & XP?'}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {progress.language === 'ar'
                ? 'هل أنت متأكد من تصفير نقاط XP والدروس المكتملة وإرجاع الإعدادات الافتراضية؟'
                : progress.language === 'fr'
                ? 'Voulez-vous vraiment remettre à zéro vos points XP et leçons complétées ?'
                : 'Are you sure you want to reset your XP, completed lessons, and local progress?'}
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setResetConfirmOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
              >
                {progress.language === 'ar' ? 'إلغاء' : progress.language === 'fr' ? 'Annuler' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmResetProgress}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                {progress.language === 'ar' ? 'تأكيد التصفير' : progress.language === 'fr' ? 'Confirmer' : 'Confirm Reset'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
