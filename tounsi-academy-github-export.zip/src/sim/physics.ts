/**
 * NEXUS WORKSHOP — Physics & Engineering Simulation Engine
 * Rigorous educational calculations for Electrical, Mechanical, Hydraulic, and Thermal systems.
 * Founder: Saif Eddine Aloui — فلسطين في القلب 🇵🇸
 */

export const IndustrialPhysics = {
  // --- ELECTRICAL LAB ---
  electrical: {
    // 3-Phase Active Power (kW)
    threePhaseActivePower(voltageL_L: number, currentA: number, powerFactor: number = 0.85): number {
      return (Math.sqrt(3) * voltageL_L * currentA * powerFactor) / 1000;
    },

    // Motor Synchronous Speed (RPM)
    syncSpeed(frequencyHz: number, poles: number): number {
      if (poles <= 0) return 0;
      return (120 * frequencyHz) / poles;
    },

    // Rotor Slip
    motorSlip(syncSpeedRPM: number, actualSpeedRPM: number): number {
      if (syncSpeedRPM <= 0) return 0;
      return (syncSpeedRPM - actualSpeedRPM) / syncSpeedRPM;
    },

    // Star-Delta Current Comparison
    starDeltaComparison(deltaNominalAmps: number) {
      const starStartingAmps = deltaNominalAmps * 2; // ~2x rated in star
      const directDeltaStartingAmps = deltaNominalAmps * 6; // ~6x rated in DOL delta
      const starTorqueRatio = 1 / 3;
      return {
        starStartingAmps: Math.round(starStartingAmps * 10) / 10,
        directDeltaStartingAmps: Math.round(directDeltaStartingAmps * 10) / 10,
        starTorqueRatio,
        reductionPercent: 67, // 1/3 starting current reduction
      };
    },

    // Approximate cable voltage drop (Volts)
    cableVoltageDrop(lengthMeters: number, currentA: number, cableSectionMM2: number, copperResistivity = 0.0175): number {
      if (cableSectionMM2 <= 0) return 0;
      // 3-Phase drop = sqrt(3) * I * (rho * L / S) * cosPhi
      const resistance = (copperResistivity * lengthMeters) / cableSectionMM2;
      return Math.sqrt(3) * currentA * resistance * 0.85;
    },
  },

  // --- MECHANICAL LAB ---
  mechanical: {
    // Gear Ratio & Output Speed
    gearbox(driverTeeth: number, drivenTeeth: number, inputSpeedRPM: number, inputTorqueNm: number) {
      if (driverTeeth <= 0 || drivenTeeth <= 0) return { ratio: 1, outputSpeedRPM: 0, outputTorqueNm: 0 };
      const ratio = drivenTeeth / driverTeeth;
      const efficiency = 0.96; // typical spur/helical gear stage
      const outputSpeedRPM = inputSpeedRPM / ratio;
      const outputTorqueNm = inputTorqueNm * ratio * efficiency;
      return {
        ratio: Math.round(ratio * 100) / 100,
        outputSpeedRPM: Math.round(outputSpeedRPM),
        outputTorqueNm: Math.round(outputTorqueNm * 10) / 10,
      };
    },

    // Torque from Power & RPM
    torqueFromPower(powerKW: number, speedRPM: number): number {
      if (speedRPM <= 0) return 0;
      return (9550 * powerKW) / speedRPM;
    },

    // Bearing L10 Life Estimation (Hours)
    bearingLifeHours(dynamicLoadRatingC_kN: number, equivalentLoadP_kN: number, rpm: number, isBallBearing = true): number {
      if (equivalentLoadP_kN <= 0 || rpm <= 0) return 100000;
      const p = isBallBearing ? 3 : 10 / 3; // exponent: 3 for ball, 3.33 for roller
      const l10RevolutionsMillions = Math.pow(dynamicLoadRatingC_kN / equivalentLoadP_kN, p);
      return Math.round((1000000 * l10RevolutionsMillions) / (60 * rpm));
    },
  },

  // --- HYDRAULICS & PNEUMATICS ---
  hydraulics: {
    // Cylinder Force (kN) - Push & Pull
    cylinderForce(pressureBar: number, boreDiaMM: number, rodDiaMM: number) {
      const pressurePascal = pressureBar * 1e5;
      const pistonAreaM2 = Math.PI * Math.pow((boreDiaMM / 1000) / 2, 2);
      const rodAreaM2 = Math.PI * Math.pow((rodDiaMM / 1000) / 2, 2);
      const pushAreaM2 = pistonAreaM2;
      const pullAreaM2 = Math.max(0, pistonAreaM2 - rodAreaM2);

      const pushForceKN = (pressurePascal * pushAreaM2) / 1000;
      const pullForceKN = (pressurePascal * pullAreaM2) / 1000;

      return {
        pushForceKN: Math.round(pushForceKN * 10) / 10,
        pullForceKN: Math.round(pullForceKN * 10) / 10,
      };
    },

    // Flow Velocity in Pipe (m/s)
    flowVelocity(flowLitersPerMin: number, internalDiaMM: number): number {
      if (internalDiaMM <= 0) return 0;
      const flowM3s = (flowLitersPerMin / 60) / 1000;
      const areaM2 = Math.PI * Math.pow((internalDiaMM / 1000) / 2, 2);
      return Math.round((flowM3s / areaM2) * 100) / 100;
    },
  },

  // --- THERMAL SYSTEMS & THERMAL OIL ---
  thermal: {
    // Thermal Oil Properties (typical synthetic/mineral oil e.g. Mobiltherm / Therminol 66)
    oilDensity(tempC: number): number {
      // Density decreases linearly with temperature: ~875 kg/m3 at 20°C to ~720 kg/m3 at 300°C
      return Math.max(680, 875 - 0.65 * (tempC - 20));
    },

    oilSpecificHeat(tempC: number): number {
      // Specific heat capacity increases with temperature: ~1.85 kJ/kg·K at 20°C to ~2.65 kJ/kg·K at 300°C
      return 1.85 + 0.0028 * tempC;
    },

    // Heat duty Q = mass_flow * Cp * deltaT (kW)
    heatTransferKW(flowM3h: number, tempInC: number, tempOutC: number): number {
      const avgTemp = (tempInC + tempOutC) / 2;
      const rho = this.oilDensity(avgTemp); // kg/m3
      const cp = this.oilSpecificHeat(avgTemp); // kJ/kg·K
      const massFlowKgS = (flowM3h * rho) / 3600; // kg/s
      const deltaT = Math.abs(tempOutC - tempInC);
      return Math.round(massFlowKgS * cp * deltaT * 10) / 10;
    },

    // Expansion Tank volume expansion calculation (Liters)
    expansionVolume(totalSystemLiters: number, initialTempC: number, maxOperatingTempC: number): number {
      const beta = 0.00085; // thermal expansion coefficient per °C
      const deltaT = Math.max(0, maxOperatingTempC - initialTempC);
      return Math.round(totalSystemLiters * beta * deltaT);
    },

    // Vapor Pressure & Cavitation margin
    cavitationRisk(tempOutC: number, inletPressureBar: number): { risk: 'safe' | 'warning' | 'critical'; marginBar: number } {
      // Vapor pressure of thermal oil starts rising fast if moisture/light ends are present or temp > 280°C
      const vaporPressureBar = 0.05 + Math.pow(Math.max(0, tempOutC - 150) / 120, 3.2) * 0.45;
      const marginBar = inletPressureBar - vaporPressureBar;
      if (marginBar < 0.2) return { risk: 'critical', marginBar: Math.round(marginBar * 100) / 100 };
      if (marginBar < 0.6) return { risk: 'warning', marginBar: Math.round(marginBar * 100) / 100 };
      return { risk: 'safe', marginBar: Math.round(marginBar * 100) / 100 };
    },
  },
};
